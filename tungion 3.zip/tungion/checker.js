/* TUNGION live answer checker.
   Checks any typed answer in real time against Wikipedia + Wikidata:
     1. finds the page the player means (exact title, redirects, search, and names in other
        languages through Wikidata, e.g. "pamplemousse" -> Grapefruit). No spelling correction.
     2. checks that page against the prompt's rules (is it really a fruit / a city in Japan / ...),
     3. scores rarity from how many people read that page in the last 30 days.
   No API key needed. Wikipedia and Wikidata allow browser requests with origin=*. */
window.TungionChecker = (() => {
  'use strict';
  const WP = 'https://en.wikipedia.org/w/api.php';
  const WD = 'https://www.wikidata.org/w/api.php';
  const TIMEOUT_MS = 9000;
  const cache = new Map();
  const compiledRules = new WeakMap();

  /* ---------- text helpers ---------- */
  const fold = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const norm = s => fold(s).replace(/&/g, ' and ').trim().replace(/^(the|a|an)\s+/, '').replace(/[^a-z0-9]/g, '');
  const words = s => fold(s).replace(/&/g, ' and ').replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(Boolean);
  const GENERIC = new Set(['the', 'a', 'an', 'of', 'and', 'de', 'la', 'le', 'mount', 'mt', 'mountain', 'lake', 'river', 'island', 'isle',
    'county', 'city', 'film', 'movie', 'song', 'album', 'novel', 'band', 'shark', 'fish', 'tree', 'plant', 'bird', 'dog', 'cat', 'breed',
    'national', 'park', 'state', 'province', 'soup', 'cheese', 'cocktail', 'pasta', 'sauce', 'language', 'video', 'game', 'series', 'tv', 'show']);


  // Different spellings of a page name worth comparing against
  function nameForms(title) {
    if (!title) return [];
    const base = title.replace(/\s*\([^)]*\)\s*/g, ' ').replace(/\s+/g, ' ').trim();
    const comma = base.split(',')[0].trim();
    return [...new Set([title, base, comma])].filter(Boolean);
  }

  /* How close is what the player typed to a name?
     0 = same name, 1 = clearly the same thing (all the important words), -1 = no.
     There is no spelling correction: a misspelled answer doesn't match. */
  function simScore(input, name) {
    const a = norm(input), b = norm(name);
    if (!a || !b) return -1;
    const sing = x => x.endsWith('ies') ? x.slice(0, -3) + 'y' : x.endsWith('es') && !x.endsWith('ses') ? x.slice(0, -2) : x.endsWith('s') ? x.slice(0, -1) : x;
    if (a === b || sing(a) === sing(b) || sing(a) === b || a === sing(b)) return 0;
    const wa = words(input).filter(w => !GENERIC.has(w)), wb = words(name).filter(w => !GENERIC.has(w));
    if (wa.length && wb.length) {
      const sa = wa.join(''), sb = wb.join('');
      if (sa === sb) return 0;
      // player typed every important word of the name (e.g. "Love Story Taylor Swift" -> "Love Story")
      if (wb.every(w => wa.includes(w)) && sb.length >= 3 && sb.length / sa.length >= 0.4) return 1;
      // name contains everything the player typed and the player's words are most of it ("bullfrog" -> "American bullfrog")
      if (wa.every(w => wb.includes(w)) && sa.length >= 4 && sa.length / sb.length >= 0.5 && !(sa.length < 6 && wb.length > 1)) return 1;
    }
    return -1;
  }
  function bestSim(input, names) {
    let best = null;
    for (const n of names) {
      for (const f of nameForms(n)) {
        const s = simScore(input, f);
        if (s >= 0 && (!best || s < best.s)) best = { s, name: f };
      }
    }
    return best;
  }

  /* ---------- network ---------- */
  async function api(base, params, signal) {
    const u = new URL(base);
    const all = Object.assign({ format: 'json', formatversion: '2', origin: '*' }, params);
    Object.keys(all).forEach(k => u.searchParams.set(k, all[k]));
    const r = await fetch(u.toString(), { signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }
  async function search(q, signal) {
    const j = await api(WP, {
      action: 'query', list: 'search', srsearch: q, srlimit: '7', srnamespace: '0',
      srprop: 'redirecttitle'
    }, signal);
    const qi = j.query || {};
    return {
      hits: (qi.search || []).map(h => ({
        title: h.title,
        redirect: typeof h.redirecttitle === 'string' ? h.redirecttitle : (h.redirecttitle && (h.redirecttitle.mainText || h.redirecttitle.title)) || null
      }))
    };
  }
  async function details(titles, signal) {
    const list = [...new Set(titles)].slice(0, 12);
    if (!list.length) return { byTitle: new Map(), resolve: t => t };
    const j = await api(WP, {
      action: 'query', titles: list.join('|'), redirects: '1',
      prop: 'description|categories|extracts|pageviews|pageprops',
      cllimit: 'max', clshow: '!hidden', exintro: '1', explaintext: '1', exsentences: '3', exlimit: 'max',
      pvipdays: '30', ppprop: 'disambiguation'
    }, signal);
    const q = j.query || {};
    const map = new Map();
    (q.normalized || []).forEach(n => map.set(n.from, n.to));
    const redir = new Map();
    (q.redirects || []).forEach(r => redir.set(r.from, r.to));
    const resolve = t => { let x = map.get(t) || t; let guard = 0; while (redir.has(x) && guard++ < 5) x = redir.get(x); return x; };
    const byTitle = new Map();
    (q.pages || []).forEach(p => byTitle.set(p.title, p));
    return { byTitle, resolve };
  }
  async function wikidataTitles(term, signal) {
    const langs = ['en', 'fr', 'es', 'de', 'it', 'pt', 'nl'];
    const results = await Promise.all(langs.map(l =>
      api(WD, { action: 'wbsearchentities', search: term, language: l, uselang: 'en', type: 'item', limit: '5' }, signal).catch(() => null)));
    const found = new Map();
    results.forEach(r => (r && r.search || []).forEach(h => {
      const said = (h.match && h.match.text) || h.label || '';
      const s = simScore(term, said);
      if (s >= 0 && !found.has(h.id)) found.set(h.id, { via: said, s });
    }));
    if (!found.size) return [];
    const ids = [...found.keys()].slice(0, 10);
    const j = await api(WD, { action: 'wbgetentities', ids: ids.join('|'), props: 'sitelinks', sitefilter: 'enwiki' }, signal);
    const out = [];
    ids.forEach(id => {
      const e = j.entities && j.entities[id];
      const t = e && e.sitelinks && e.sitelinks.enwiki && e.sitelinks.enwiki.title;
      if (t) out.push({ title: t, via: found.get(id).via, s: found.get(id).s });
    });
    return out;
  }

  /* ---------- prompt rules ---------- */
  function rules(prompt) {
    let r = compiledRules.get(prompt);
    if (r) return r;
    const rx = s => s ? new RegExp(s, 'i') : null;
    // words of the prompt itself can't be the answer ("Name a fruit" -> "Fruit" doesn't count)
    const qWords = words(prompt.q.replace(/\(.*?\)/g, '')).filter(w => w.length > 2 && !['name', 'from', 'that', 'with', 'released', 'directed', 'starring', 'premiered'].includes(w));
    const banned = new Set(qWords);
    for (let i = 0; i < qWords.length; i++) for (let k = 2; k <= 3 && i + k <= qWords.length; k++) banned.add(qWords.slice(i, i + k).join(''));
    r = {
      type: rx(prompt.type), cat: rx(prompt.cat), title: rx(prompt.title), not: rx(prompt.not),
      where: (prompt.where || []).filter(Boolean).map(w => new RegExp(w, 'i')), banned
    };
    compiledRules.set(prompt, r);
    return r;
  }
  function firstSentence(text) {
    if (!text) return '';
    let s = text.replace(/\s*\([^()]*(\([^()]*\)[^()]*)*\)/g, '').replace(/\s+/g, ' ').trim();
    const m = s.match(/^(.{20,}?[.!?])(\s+[A-Z"“]|$)/);
    if (m) s = m[1];
    return s;
  }
  function fits(page, prompt) {
    const r = rules(prompt);
    const cats = (page.categories || []).map(c => String(c.title || '').replace(/^Category:/, ''));
    const desc = page.description || '';
    const first = firstSentence(page.extract || '');
    const typeText = [desc, first, cats.join(' | ')].join(' \n ');
    const full = [page.title, desc, cats.join(' | '), page.extract || ''].join(' \n ');
    if (r.title && !r.title.test(page.title)) return false;
    if (r.not && r.not.test(desc + ' \n ' + first)) return false;
    if (r.cat && cats.some(c => r.cat.test(c))) return true;
    if (!r.type) return false;
    return r.type.test(typeText) && r.where.every(w => w.test(full));
  }
  function usable(page, prompt) {
    if (!page || page.missing || page.invalid) return false;
    if (page.pageprops && 'disambiguation' in page.pageprops) return false;
    if (/^(list|lists|outline|index|glossary|timeline|history|bibliography|discography|filmography) of\b/i.test(page.title)) return false;
    const n = norm(nameForms(page.title)[1] || page.title);
    if (rules(prompt).banned.has(n)) return false;
    return true;
  }
  const views = page => {
    const pv = page.pageviews || {};
    return Object.keys(pv).reduce((s, k) => s + (typeof pv[k] === 'number' ? pv[k] : 0), 0);
  };

  /* ---------- the check ---------- */
  async function tryCandidates(cands, prompt, signal) {
    if (!cands.length) return null;
    cands.sort((x, y) => x.s - y.s);
    const d = await details(cands.map(c => c.title), signal);
    for (const c of cands) {
      const page = d.byTitle.get(d.resolve(c.title));
      if (!usable(page, prompt)) continue;
      if (fits(page, prompt)) {
        const display = nameForms(page.title)[1] || page.title;
        return {
          ok: true, title: page.title, display, views: views(page),
          fact: firstSentence(page.extract || '') || page.description || '',
          said: c.via,
          url: 'https://en.wikipedia.org/wiki/' + encodeURIComponent(page.title.replace(/ /g, '_'))
        };
      }
    }
    return null;
  }
  const titleCase = s => s.trim().replace(/\s+/g, ' ').replace(/^./, c => c.toUpperCase());

  function candidatesFrom(term, hits) {
    const out = [{ title: titleCase(term), via: term, s: 0 }];
    hits.forEach(h => {
      const b = bestSim(term, [h.title, h.redirect].filter(Boolean));
      if (b) out.push({ title: h.title, via: b.name, s: b.s });
    });
    return out;
  }

  async function run(prompt, input, signal) {
    const hint = prompt.hint || '';
    // Round 1: exact title / redirect + plain search + search with the prompt's context words
    const [s1, s2] = await Promise.all([search(input, signal), hint ? search(input + ' ' + hint, signal) : Promise.resolve({ hits: [] })]);
    let res = await tryCandidates(candidatesFrom(input, s1.hits.concat(s2.hits)), prompt, signal);
    if (res) return res;

    // Round 2: names in other languages (Wikidata labels and aliases), e.g. "pamplemousse" -> Grapefruit
    const wd = await wikidataTitles(input, signal);
    if (wd.length) {
      res = await tryCandidates(wd.map(w => ({ title: w.title, via: w.via, s: w.s })), prompt, signal);
      if (res) return res;
    }
    return { ok: false };
  }

  function check(prompt, input) {
    const key = prompt.id + '|' + norm(input);
    if (cache.has(key)) return cache.get(key);
    const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => ctl && ctl.abort(), TIMEOUT_MS);
    const p = run(prompt, input, ctl ? ctl.signal : undefined)
      .finally(() => clearTimeout(timer));
    cache.set(key, p);
    p.catch(() => cache.delete(key));
    return p;
  }

  // One-line fact for answers matched from the built-in charts
  async function fact(title) {
    try {
      const j = await api(WP, { action: 'query', titles: title, redirects: '1', prop: 'extracts|description', exintro: '1', explaintext: '1', exsentences: '2' });
      const p = (j.query && j.query.pages || [])[0];
      if (!p || p.missing || (p.pageprops && 'disambiguation' in p.pageprops)) return '';
      const f = firstSentence(p.extract || '');
      return /may refer to/i.test(f) ? '' : f;
    } catch (e) { return ''; }
  }

  // Rarity from 30-day Wikipedia readership: fewer readers = rarer answer
  function tierFromViews(v) {
    if (v >= 50000) return 0;   // Plankton
    if (v >= 12000) return 2;   // Schooler
    if (v >= 2500) return 3;    // Rare
    if (v >= 300) return 4;     // Deep Cut
    return 5;                   // One in a Tungion
  }

  return { check, fact, tierFromViews, simScore, fits, usable, firstSentence, norm, _rules: rules };
})();
