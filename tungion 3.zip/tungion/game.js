/* TUNGION · The Daily Dive
   Plain JavaScript, no build step. Answers are checked live by checker.js. */
(() => {
'use strict';

/* ================= CONFIG ================= */
const SECONDS_PER_PROMPT = 15;
const DESCENT_SECONDS    = 3;              // countdown before each prompt's clock starts
const PROMPTS_PER_DIVE   = 7;
const UNLIMITED_AIR      = 45;             // seconds, drains only while answering
const METERS_PER_POINT   = 10;
const LAUNCH_UTC         = Date.UTC(2026, 9, 25); // Oct 25 2026 = Dive #1
const STORE_PREFIX       = 'tungion:v2:';

const TIERS = [
  { key: 'plankton', name: 'PLANKTON',         pts: 10,  color: '#9ad1ff', emoji: '🟦', desc: 'The answer everyone blurts out.' },
  { key: 'clever',   name: 'TOO CLEVER',       pts: 15,  color: '#c7a6ff', emoji: '🟪', desc: 'The famous "obscure" pick. Everyone thought of it.' },
  { key: 'schooler', name: 'SCHOOLER',         pts: 30,  color: '#5fe3c0', emoji: '🟩', desc: 'Solid, swims with the pack.' },
  { key: 'rare',     name: 'RARE',             pts: 60,  color: '#ffd35c', emoji: '🟨', desc: 'Uncommon but recognizable.' },
  { key: 'deep',     name: 'DEEP CUT',         pts: 85,  color: '#ff9f4a', emoji: '🟧', desc: 'Specialist knowledge. Very few go here.' },
  { key: 'gem',      name: 'ONE IN A TUNGION', pts: 100, color: '#ff4f7b', emoji: '🟥', desc: 'The rarest catch of all. Never revealed.' }
];
const MISS = { name: 'OUT OF AIR', color: '#6c7f93', emoji: '⬛' };
const BANDS = [[450, 5], [375, 4], [300, 3], [225, 2], [151, 1], [0, 0]];   // dive rating by total points

const CURATED = window.TUNGION_PROMPTS || [];
const PROMPTS = CURATED.concat(window.TUNGION_BANK || []);
const PACKS   = window.TUNGION_PACKS || [];
const Checker = window.TungionChecker;

const $ = s => document.querySelector(s);

/* ================= STORAGE (safe) ================= */
const store = {
  get(k) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
};

/* ================= BUILT-IN CHARTS (curated prompts) ================= */
const DISPLAY = {
  'capn crunch': "Cap'n Crunch", 'reeses puffs': "Reese's Puffs", 'zaatar': "Za'atar", 'dark n stormy': "Dark 'n' Stormy",
  'bees knees': "Bee's Knees", 'widows kiss': "Widow's Kiss", 'ivory coast': 'Ivory Coast', 'sao tome and principe': 'São Tomé and Príncipe',
  'comte': 'Comté', 'gruyere': 'Gruyère', 'tete de moine': 'Tête de Moine', 'epoisses': 'Époisses', 'pina colada': 'Piña Colada',
  'vieux carre': 'Vieux Carré', 'reykjavik': 'Reykjavík', 'torshavn': 'Tórshavn', 'chisinau': 'Chișinău', 'oreo os': "Oreo O's",
  'urkel os': "Urkel-O's", 'ohs': "OH!s", 'mr t': 'Mr. T', 't rex': 'Tyrannosaurus', 'yi qi': 'Yi qi', 'mei long': 'Mei long',
  'hiiaka': 'Hiʻiaka', 'popocatepetl': 'Popocatépetl', 'huascaran': 'Huascarán', 'bodhran': 'Bodhrán',
  'portuguese man o war': "Portuguese man o' war", 'cock a leekie': 'Cock-a-leekie', 'hurdy gurdy': 'Hurdy-gurdy',
  'guinea bissau': 'Guinea-Bissau', 'pac man': 'Pac-Man', 'st helens': 'Mount St. Helens', 'k2': 'K2',
  'democratic republic of the congo': 'DR Congo', 'american sign language': 'American Sign Language', 'pho': 'Phở',
  'mont blanc': 'Mont Blanc', 'su filindeu': 'Su filindeu', 'ninja lanternshark': 'Ninja lanternshark', 'moon': 'Moon'
};
const SMALL = new Set(['of', 'and', 'the', 'de', 'del', 'la', 'di', 'on', 'a']);
function display(s) {
  if (DISPLAY[s]) return DISPLAY[s];
  return s.split(' ').map((w, i) => (i > 0 && SMALL.has(w)) ? w : w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
  .replace(/&/g, ' and ').trim().replace(/^(the|a|an)\s+/, '').replace(/[^a-z0-9]/g, '');
function strip(n, p) {
  for (const s of (p.pre || [])) { const k = norm(s); if (n.startsWith(k) && n.length > k.length + 1) { n = n.slice(k.length); break; } }
  for (const s of (p.suf || [])) { const k = norm(s); if (n.endsWith(k) && n.length > k.length + 1) { n = n.slice(0, -k.length); break; } }
  return n;
}
function buildIndex(p) {
  if (p._map || !p.t) return;
  const map = new Map();
  TIERS.forEach((tier, ti) => {
    const raw = p.t[tier.key];
    if (!raw) return;
    raw.split(',').forEach(item => {
      const aliases = item.split('|').map(a => a.trim()).filter(Boolean);
      if (!aliases.length) return;
      const e = { name: aliases[0], tier: ti };
      aliases.forEach(a => { const k = strip(norm(a), p); if (k && !map.has(k)) map.set(k, e); });
    });
  });
  for (const [k, e] of [...map]) {
    if (k.length > 3 && k.endsWith('s')) { const d = k.slice(0, -1); if (!map.has(d)) map.set(d, e); }
  }
  p._map = map;
}
// -> { entry, dist: 0 } for an exact name or alias, or null
function lookupLocal(p, input) {
  if (!p.t) return null;
  buildIndex(p);
  const n = norm(input);
  if (!n) return null;
  const cands = [n];
  if (n.endsWith('ies')) cands.push(n.slice(0, -3) + 'y');
  if (n.endsWith('es')) cands.push(n.slice(0, -2));
  if (n.endsWith('s')) cands.push(n.slice(0, -1));
  for (const c of cands) { const k = strip(c, p); if (p._map.has(k)) return { entry: p._map.get(k), dist: 0 }; }
  return null;   // no spelling correction
}

/* ================= DAILY ================= */
function diveNumber(date = new Date()) {
  const today = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  return Math.max(1, Math.floor((today - LAUNCH_UTC) / 864e5) + 1);
}
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function shuffle(arr, rnd = Math.random) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
// Same 7 prompts for everyone on a given day, each from a different family
function dailyPrompts(n) {
  const fams = new Set(), out = [];
  for (const p of shuffle(PROMPTS, mulberry32(n * 9973 + 17))) {
    if (p.niche || fams.has(p.fam)) continue;
    fams.add(p.fam); out.push(p);
    if (out.length === PROMPTS_PER_DIVE) break;
  }
  return out;
}
const dailyKey = n => STORE_PREFIX + 'dive:' + n;

function zoneFor(m) {
  if (m < 200)  return 'SUNLIGHT ZONE';
  if (m < 1000) return 'TWILIGHT ZONE';
  if (m < 4000) return 'MIDNIGHT ZONE';
  if (m < 6000) return 'ABYSSAL ZONE';
  return 'HADAL ZONE';
}

/* ================= SOUND ================= */
const Sound = {
  on: store.get('tungion:sound') === true,
  ac: null,
  init() {
    if (!this.ac) { const AC = window.AudioContext || window.webkitAudioContext; if (AC) this.ac = new AC(); }
    if (this.ac && this.ac.state === 'suspended') this.ac.resume();
  },
  tone(f, d = 0.08, type = 'square', v = 0.04, f2 = 0, delay = 0) {
    if (!this.on) return;
    this.init();
    const ac = this.ac; if (!ac) return;
    const t = ac.currentTime + delay;
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(v, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(ac.destination);
    o.start(t); o.stop(t + d + 0.03);
  },
  click() { this.tone(700, 0.04, 'square', 0.03); },
  ping()  { this.tone(1250, 0.9, 'sine', 0.07, 1180); this.tone(1250, 0.6, 'sine', 0.025, 1200, 0.45); },
  count() { this.tone(520, 0.08, 'square', 0.035); },
  go()    { this.tone(880, 0.15, 'square', 0.04); },
  wrong() { this.tone(170, 0.2, 'square', 0.045, 100); },
  tick()  { this.tone(990, 0.03, 'square', 0.025); },
  miss()  { this.tone(300, 0.5, 'triangle', 0.05, 80); },
  tier(i) {
    const notes = [262, 294, 330, 392, 523, 659, 784, 1047];
    for (let k = 0; k <= i + 1; k++) this.tone(notes[k], 0.12, 'square', 0.035, 0, k * 0.07);
    this.tone(500, 0.6, 'triangle', 0.03, 90, 0.15);
  }
};
function paintSound() {
  $('#waves').style.display = Sound.on ? '' : 'none';
  $('#mute').style.display = Sound.on ? 'none' : '';
  $('#soundBtn').setAttribute('aria-pressed', String(Sound.on));
}

/* ================= SCENE (canvas) ================= */
const Scene = (() => {
  const cv = $('#sea'), ctx = cv.getContext('2d');
  let W = 0, H = 0, P = 4, t = 0;
  const M2PX = 0.8;                 // screen px per meter
  let mode = 'home', camY = null, shown = 0, target = 0;
  let tiers = null;                 // { base, hit } while an answer drops past the tier lines
  const krill = { x: 0, angle: 0, frame: 0 };
  let bubbles = [], ents = [], bubbleClock = 0;

  const BOAT = [
    '......krr.........', '......krrr........', '......krr.........', '......k...........', '......k...........',
    '....kkkkkk........', '....kwkkwk........', '..kkkkkkkkkkk..k..', 'kkkkkkkkkkkkkkkkkk', '.kkkkkkkkkkkkkkkk.', '..kkkkkkkkkkkkkk..'
  ];
  const BOAT_PAL = { k: '#1a2333', w: '#bfe0f2', r: '#ec4b63' };
  // Krill, facing left. Body + four leg/tail frames for the swimming paddle.
  const K_HEAD = ['..a..............', '.a.a.............', 'a...a............', '....rrrrrrr......', '...rrrrrrrrrrr...'];
  const K_TAIL_DOWN = ['..rwkrrrrrrrrrrr.', '..rrrrrrrrrrrrrrt', '...rrrrrrrrrrrrtt'];
  const K_TAIL_UP   = ['..rwkrrrrrrrrrrtt', '..rrrrrrrrrrrrrrt', '...rrrrrrrrrrrrr.'];
  const K_LEGS = [
    ['....l.l.l.l.l....', '...l.l.l.l.l.....'],
    ['....l.l.l.l.l....', '....l.l.l.l.l....'],
    ['....l.l.l.l.l....', '.....l.l.l.l.l...'],
    ['....l.l.l.l.l....', '....l.l.l.l.l....']
  ];
  const KRILL_FRAMES = K_LEGS.map((legs, i) => K_HEAD.concat(i % 2 ? K_TAIL_UP : K_TAIL_DOWN, legs));
  const KRILL_PAL = { r: '#ff3b5c', a: '#ff8aa0', l: '#ff8aa0', t: '#ff6b85', w: '#ffffff', k: '#14070a' };
  const CLOUDS = [
    ['........wwwwww..............', '.....wwwwwwwwwww.....www....', '...wwwwwwwwwwwwwwwwwwwwwww..', '.wwwwwwwwwwwwwwwwwwwwwwwwwww', 'gggggggggggggggggggggggggggg'],
    ['......wwwww.........', '...wwwwwwwwww.wwww..', '.wwwwwwwwwwwwwwwwwww', 'gggggggggggggggggggg'],
    ['....wwww.....', '.wwwwwwwwww..', 'wwwwwwwwwwwww', 'ggggggggggggg']
  ];
  const CLOUD_PAL = { w: '#ffffff', g: '#d8e8f2' };
  const FISH = ['..ff....', '.ffffff.f', 'fefffffff', '.ffffff.f', '..ff....'];
  const JELLY = ['.jjjj.', 'jjjjjj', 'jjjjjj', 'j.j.j.', '.j.j.j', 'j.j.j.', '.j...j'];
  const ANGLER = ['.......l', '......k.', '...kkkk.', '.kkkkkkk', 'kekkkkkk', 'kkwkwkkk', '.kkkkkk.', '...kk...'];
  const WRECK = [
    '.........ss..ss..ss..ss.........', '........ssssssssssssssssss......', '....hhhhhhhhhhhhhhhhhhhhhhhhhh..',
    'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '.hhhhhhwhhhwhhhwhhhwhhhwhhhhhhh.', '..hhhhhhhhhhhhhhhhhhhhhhhhhhhh..', '....hhhhhhhhhhhhhhhhhhhhhhhh....'
  ];
  const LANDMARKS = [[200, 'SUNLIGHT FADES'], [332, 'DEEPEST SCUBA DIVE'], [1000, 'MIDNIGHT ZONE'], [3800, 'TITANIC WRECK'],
    [4000, 'ABYSSAL ZONE'], [6000, 'HADAL ZONE'], [7000, 'TRENCH FLOOR · PERFECT DIVE'], [10935, 'CHALLENGER DEEP']];
  const FLOOR_M = 10935;

  const cloudSlots = [
    { x: 0.03, y: 0.93, s: 0 }, { x: 0.36, y: 0.68, s: 1 }, { x: 0.79, y: 0.38, s: 0 },
    { x: 0.58, y: 0.86, s: 2 }, { x: 0.14, y: 0.42, s: 2 }
  ];

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    P = Math.max(3, Math.min(6, Math.round(W / 220)));
    if (camY === null) camY = homeCam();
  }
  const homeCam = () => -H * 0.62;
  const krillY = m => H * 0.14 + m * M2PX;

  function sprite(rows, pal, x, y, p = P, flip = false) {
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      for (let c = 0; c < row.length; c++) {
        const ch = row[flip ? row.length - 1 - c : c];
        if (ch === '.' || !pal[ch]) continue;
        ctx.fillStyle = pal[ch];
        ctx.fillRect(Math.round(x + c * p), Math.round(y + r * p), p, p);
      }
    }
  }

  const STOPS = [[0, [46, 97, 152]], [25, [35, 77, 128]], [120, [22, 50, 95]], [300, [12, 26, 56]],
                 [1000, [8, 17, 41]], [3000, [5, 11, 29]], [7000, [2, 4, 13]], [11000, [1, 2, 7]]];
  function waterAt(m) {
    if (m <= 0) return STOPS[0][1];
    for (let i = 1; i < STOPS.length; i++) {
      if (m <= STOPS[i][0]) {
        const [m0, c0] = STOPS[i - 1], [m1, c1] = STOPS[i], f = (m - m0) / (m1 - m0);
        return c0.map((v, k) => Math.round(v + (c1[k] - v) * f));
      }
    }
    return STOPS[STOPS.length - 1][1];
  }
  const rgb = c => `rgb(${c[0]},${c[1]},${c[2]})`;

  function makeEnts() {
    const rnd = mulberry32(4242);
    ents = [];
    for (let i = 0; i < 16; i++) ents.push({ type: 'fish', m: 260 + rnd() * 380, x: rnd(), v: (0.012 + rnd() * 0.02) * (rnd() < 0.5 ? -1 : 1), s: rnd() < 0.3 ? 2 : 1 });
    for (let i = 0; i < 14; i++) ents.push({ type: 'jelly', m: 350 + rnd() * 2800, x: rnd(), v: 0.004 * (rnd() < 0.5 ? -1 : 1), ph: rnd() * 6 });
    for (let i = 0; i < 14; i++) ents.push({ type: 'angler', m: 1800 + rnd() * 8800, x: rnd(), v: (0.005 + rnd() * 0.006) * (rnd() < 0.5 ? -1 : 1), ph: rnd() * 6 });
  }
  function hash(a, b) { let h = (a * 374761393 + b * 668265263) | 0; h = (h ^ (h >>> 13)) * 1274126177; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }

  function draw(dt) {
    t += dt;
    const diff = target - shown;
    const sinking = diff > 2;
    if (Math.abs(diff) < 0.5) shown = target;
    else shown += Math.sign(diff) * Math.max(Math.abs(diff) * Math.min(1, dt * 1.4), Math.min(Math.abs(diff), 160 * dt));

    const want = mode === 'home' ? homeCam() : Math.max(homeCam(), krillY(shown) - H * 0.72);
    camY += (want - camY) * Math.min(1, dt * 3);
    const sY = y => y - camY;

    /* sky */
    if (camY < 0) {
      const top = sY(homeCam()), bot = sY(0);
      const g = ctx.createLinearGradient(0, top, 0, bot);
      g.addColorStop(0, '#8fcbea'); g.addColorStop(1, '#d9eef7');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, Math.min(H, bot) + 1);
      const sr = Math.max(44, Math.round(W * 0.055));
      const sx = W - sr * 1.9, sy = sY(homeCam()) - sr * 0.15, b = P * 2;
      for (let yy = -sr - b; yy <= sr + b; yy += b) for (let xx = -sr - b; xx <= sr + b; xx += b) {
        const d = Math.hypot(xx + b / 2, yy + b / 2);
        if (d <= sr) { ctx.fillStyle = d < sr * 0.7 ? '#ffd65a' : '#ffdf73'; ctx.fillRect(Math.round(sx + xx), Math.round(sy + yy), b, b); }
        else if (d <= sr + b) { ctx.fillStyle = 'rgba(255,240,170,.75)'; ctx.fillRect(Math.round(sx + xx), Math.round(sy + yy), b, b); }
      }
      cloudSlots.forEach((c, i) => {
        const rows = CLOUDS[c.s], w = rows[0].length * P;
        const x = ((c.x * W + t * (3 + i)) % (W + w * 2)) - w;
        sprite(rows, CLOUD_PAL, x, sY(homeCam() + (1 - c.y) * -homeCam()));
      });
    }

    /* water */
    const waterTop = Math.max(0, sY(0));
    if (waterTop < H) {
      const m0 = Math.max(0, (camY + waterTop - H * 0.14) / M2PX), m1 = (camY + H - H * 0.14) / M2PX;
      const g = ctx.createLinearGradient(0, waterTop, 0, H);
      for (let i = 0; i <= 8; i++) g.addColorStop(i / 8, rgb(waterAt(m0 + (m1 - m0) * i / 8)));
      ctx.fillStyle = g; ctx.fillRect(0, waterTop, W, H - waterTop + 1);

      if (camY < 400) {
        ctx.fillStyle = 'rgba(160,210,255,0.035)';
        for (let i = 0; i < 5; i++) {
          const x0 = ((i * 0.23 + 0.05) * W + Math.sin(t * 0.2 + i) * 20);
          ctx.beginPath(); ctx.moveTo(x0, sY(0)); ctx.lineTo(x0 + 40, sY(0)); ctx.lineTo(x0 + 160, sY(420)); ctx.lineTo(x0 + 80, sY(420)); ctx.fill();
        }
      }

      // marine snow
      const cell = 90, cy0 = Math.floor(Math.max(camY, 150) / cell), cy1 = Math.floor((camY + H) / cell);
      ctx.fillStyle = 'rgba(200,225,255,0.22)';
      for (let cy = cy0; cy <= cy1; cy++) for (let cx = 0; cx <= Math.ceil(W / cell); cx++) {
        const r = hash(cx, cy);
        if (r > 0.55) continue;
        const x = cx * cell + (r * cell * 1.7) % cell, y = cy * cell + ((hash(cy, cx) * cell + t * 6) % cell);
        if (y >= 150) ctx.fillRect(Math.round(x), Math.round(sY(y)), 2, 2);
      }

      // creatures
      ents.forEach(e => {
        e.x += e.v * dt; if (e.x > 1.1) e.x = -0.1; if (e.x < -0.1) e.x = 1.1;
        const y = sY(krillY(e.m));
        if (y < -60 || y > H + 60) return;
        const x = e.x * W;
        if (e.type === 'fish') {
          const pal = { f: 'rgba(150,200,235,.45)', e: 'rgba(20,40,70,.6)' }, ps = Math.max(2, P - 2);
          sprite(FISH, pal, x, y, ps * e.s, e.v < 0);
          if (e.s === 1) { sprite(FISH, pal, x + 22, y + 10, ps, e.v < 0); sprite(FISH, pal, x - 18, y + 14, ps, e.v < 0); }
        } else if (e.type === 'jelly') {
          const yy = y + Math.sin(t * 1.3 + e.ph) * 8;
          ctx.fillStyle = 'rgba(120,230,255,.08)'; ctx.beginPath(); ctx.arc(x + 9, yy + 8, 22, 0, 7); ctx.fill();
          sprite(JELLY, { j: 'rgba(130,230,255,.55)' }, x, yy, 3);
        } else {
          const glow = 0.5 + 0.5 * Math.sin(t * 2 + e.ph), p = 3, lx = e.v < 0 ? x : x + 7 * p;
          ctx.fillStyle = `rgba(255,240,140,${0.12 + glow * 0.12})`; ctx.beginPath(); ctx.arc(lx + 1.5, y + 1.5, 16, 0, 7); ctx.fill();
          sprite(ANGLER, { k: 'rgba(40,58,90,.85)', e: 'rgba(200,240,255,.7)', w: 'rgba(220,230,240,.8)', l: '#ffe98a' }, x, y, p, e.v < 0);
        }
      });

      // Titanic wreck at 3,800 m
      const wy = sY(krillY(3800));
      if (wy > -80 && wy < H + 40) sprite(WRECK, { h: 'rgba(96,70,58,.85)', s: 'rgba(70,52,44,.85)', w: 'rgba(255,220,150,.25)' }, W * 0.1, wy - WRECK.length * 3 - 4, 3);

      // sea floor at Challenger Deep
      const fy = sY(krillY(FLOOR_M));
      if (fy < H + 10) {
        ctx.fillStyle = '#0b0d14'; ctx.fillRect(0, Math.max(0, fy), W, H);
        ctx.fillStyle = '#141824';
        for (let x = 0; x < W; x += P * 3) { const h = Math.round(hash(x, 7) * 4) * P; ctx.fillRect(x, fy - h, P * 3, h + P); }
      }

      // landmarks (left)
      ctx.font = '10px Silkscreen, monospace';
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      LANDMARKS.forEach(([m, label]) => {
        const y = Math.round(sY(krillY(m)));
        if (y < waterTop - 10 || y > H + 10) return;
        ctx.fillStyle = 'rgba(160,190,220,.3)';
        ctx.fillRect(16, y, 40, 1);
        ctx.fillText(`${label} · ${m.toLocaleString()} m`, 62, y);
      });

      // depth gauge (right edge)
      ctx.textAlign = 'right';
      const mTop = Math.max(0, Math.floor(((camY + waterTop) - H * 0.14) / M2PX / 50) * 50);
      const mBot = (camY + H - H * 0.14) / M2PX;
      for (let m = mTop; m <= mBot; m += 50) {
        const y = Math.round(sY(krillY(m)));
        if (y < waterTop + 4) continue;
        const major = m % 500 === 0;
        ctx.fillStyle = major ? 'rgba(190,215,240,.45)' : 'rgba(190,215,240,.22)';
        ctx.fillRect(W - (major ? 16 : 9), y, major ? 12 : 5, 1);
        if (major && m > 0) ctx.fillText(m.toLocaleString() + 'm', W - 20, y);
      }

      // tier lines the answer drops past
      if (tiers) {
        TIERS.forEach((tr, i) => {
          const y = Math.round(sY(krillY(tiers.base + tr.pts * METERS_PER_POINT)));
          if (y < -10 || y > H + 10) return;
          const hit = tiers.hit === i, reached = shown >= tiers.base + tr.pts * METERS_PER_POINT - 1;
          ctx.globalAlpha = hit ? 1 : reached ? 0.55 : 0.35;
          ctx.fillStyle = tr.color;
          for (let x = W * 0.3; x < W * 0.86; x += 12) ctx.fillRect(Math.round(x), y, 6, hit ? 2 : 1);
          ctx.textAlign = 'right';
          ctx.fillText(`${tr.name} +${tr.pts}`, Math.round(W * 0.86) - 4, y - 8);
          ctx.globalAlpha = 1;
        });
      }
      ctx.textAlign = 'left';
    }

    /* surface + boat */
    const surf = sY(0);
    if (surf > -20 && surf < H + 20) {
      ctx.fillStyle = 'rgba(140,190,230,.55)';
      ctx.fillRect(0, Math.round(surf), W, Math.max(2, P / 2));
      ctx.fillStyle = 'rgba(255,255,255,.55)';
      for (let i = 0; i < 18; i++) {
        const x = ((i * 137 + t * (12 + (i % 3) * 6)) % (W + 60)) - 30;
        ctx.fillRect(Math.round(x), Math.round(surf + 4 + (i % 4) * P * 1.5), P * (2 + (i % 3)), 2);
      }
      const bw = BOAT[0].length * P, bx = W * 0.27 - bw / 2;
      sprite(BOAT, BOAT_PAL, bx, surf - (BOAT.length - 2) * P + Math.round(Math.sin(t * 1.4) * 1.5));
    }

    /* krill: paddles its legs, flicks its tail, tips head-down while sinking */
    const kp = Math.max(2, P - 1), kw = KRILL_FRAMES[0][0].length * kp, kh = KRILL_FRAMES[0].length * kp;
    const targetX = mode === 'home' ? W * 0.72 : W * 0.5 - kw / 2;
    if (!krill.x) krill.x = targetX;
    krill.x += (targetX - krill.x) * Math.min(1, dt * 1.5);
    krill.frame += dt * (sinking ? 14 : 5);
    const wantAngle = sinking ? -0.5 : Math.sin(t * 1.3) * 0.08;
    krill.angle += (wantAngle - krill.angle) * Math.min(1, dt * 6);
    const kx = krill.x + (sinking ? 0 : Math.sin(t * 0.9) * 6);
    const ky = sY(krillY(shown)) + (sinking ? 0 : Math.sin(t * 1.7) * 4);
    const cxk = kx + kw / 2, cyk = ky + kh / 2;
    const kg = ctx.createRadialGradient(cxk, cyk, 2, cxk, cyk, kw);
    kg.addColorStop(0, 'rgba(255,70,110,.25)'); kg.addColorStop(1, 'rgba(255,70,110,0)');
    ctx.fillStyle = kg; ctx.fillRect(cxk - kw, cyk - kw, kw * 2, kw * 2);
    ctx.save();
    ctx.translate(Math.round(cxk), Math.round(cyk));
    ctx.rotate(krill.angle);
    sprite(KRILL_FRAMES[(Math.floor(Math.abs(krill.frame)) || 0) % KRILL_FRAMES.length], KRILL_PAL, -kw / 2, -kh / 2, kp);
    ctx.restore();

    /* bubbles */
    bubbleClock += dt;
    if (bubbleClock > (sinking ? 0.04 : 0.9)) {
      bubbleClock = 0;
      bubbles.push({ x: cxk + (Math.random() - 0.5) * 16, y: krillY(shown) + kh * 0.3, r: Math.random() < 0.3 ? 2 : 1, vy: 30 + Math.random() * 40, life: 0 });
    }
    bubbles = bubbles.filter(b => (b.life += dt) < 6 && b.y > 2);
    bubbles.forEach(b => {
      b.y -= b.vy * dt; b.x += Math.sin(b.life * 4 + b.vy) * 0.3;
      const s = b.r * P;
      ctx.strokeStyle = 'rgba(200,235,255,.6)'; ctx.lineWidth = 1;
      ctx.strokeRect(Math.round(b.x) + 0.5, Math.round(sY(b.y)) + 0.5, s, s);
    });
  }

  let last = performance.now();
  function loop(now) {
    const dt = Math.max(0, Math.min(0.05, (now - last) / 1000)); last = now;
    ctx.clearRect(0, 0, W, H);
    draw(dt);
    requestAnimationFrame(loop);
  }
  window.addEventListener('resize', resize);
  resize(); makeEnts();
  requestAnimationFrame(loop);

  return {
    setMode(m) { mode = m; },
    setDepth(m, instant) { target = Math.max(0, m); if (instant) shown = target; },
    showTiers(base, hit) { tiers = { base, hit }; },
    hideTiers() { tiers = null; },
    depth() { return shown; }
  };
})();

/* ================= GAME ================= */
const G = {
  mode: null, n: 0, packId: null, prompts: [], queue: [], i: 0, results: [], points: 0,
  phase: 'idle', deadline: 0, air: 0, lastTick: 0, timer: null, token: 0, lastWhole: null,
  pending: null, checkTok: 0, timeUp: false, countdownTimer: null
};

const el = {
  home: $('#home'), play: $('#play'), results: $('#results'),
  pNum: $('#pNum'), pTimer: $('#pTimer'), ring: $('#ringFg'), ringBox: $('#ring'), pText: $('#pText'),
  form: $('#ansForm'), ans: $('#ans'), ansBtn: $('#ansBtn'), msg: $('#msg'), card: $('#card'),
  reveal: $('#reveal'), rTier: $('#rTier'), rAns: $('#rAns'), rPts: $('#rPts'), rFact: $('#rFact'), next: $('#nextBtn'),
  skip: $('#skipBtn'), hudDepth: $('#hudDepth'), hudPts: $('#hudPts'), hudMode: $('#hudMode'), quit: $('#quitBtn'), begin: $('#beginBtn')
};

function show(screen) { ['home', 'play', 'results'].forEach(s => el[s].classList.toggle('hidden', s !== screen)); }
function toast(text) {
  const t = $('#toast'); t.textContent = text; t.classList.remove('hidden');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add('hidden'), 2200);
}
function setMsg(text, kind) { el.msg.textContent = text; el.msg.className = 'msg' + (kind ? ' ' + kind : ''); }
function refreshHome() {
  const n = diveNumber();
  $('#diveNo').textContent = 'DIVE #' + n;
  const saved = store.get(dailyKey(n));
  el.begin.textContent = saved && saved.done ? '▼ REVIEW YOUR DIVE ▼' : '▼ BEGIN DESCENT ▼';
}

/* ---- starting modes ---- */
function beginDaily() {
  const n = diveNumber();
  const saved = store.get(dailyKey(n));
  if (saved && saved.done) {
    const pts = saved.results.reduce((s, r) => s + r.pts, 0);
    Scene.setMode('dive'); Scene.setDepth(pts * METERS_PER_POINT);
    showResults({ mode: 'daily', n, results: saved.results });
    return;
  }
  Object.assign(G, { mode: 'daily', n, packId: null, prompts: dailyPrompts(n), results: [], points: 0 });
  if (saved && Array.isArray(saved.results)) {
    G.results = saved.results.slice();
    // a prompt that was started but never answered counts as out of air (no second chances)
    if (saved.started === G.results.length && G.results.length < PROMPTS_PER_DIVE) {
      const p = G.prompts[G.results.length];
      G.results.push({ q: p.q, id: p.id, input: '', name: null, tier: -1, pts: 0 });
    }
    G.points = G.results.reduce((s, r) => s + r.pts, 0);
  }
  G.i = G.results.length;
  saveDaily();
  if (G.i >= PROMPTS_PER_DIVE) { finishDive(); return; }
  startPlay();
}
function beginPack(id) {
  const list = PROMPTS.filter(p => p.pack === id);
  Object.assign(G, { mode: 'pack', packId: id, prompts: shuffle(list).slice(0, PROMPTS_PER_DIVE), results: [], points: 0, i: 0 });
  closeModals();
  startPlay();
}
function beginUnlimited() {
  Object.assign(G, { mode: 'unlimited', packId: null, prompts: [], queue: shuffle(PROMPTS), results: [], points: 0, i: 0, air: UNLIMITED_AIR });
  startPlay();
}
function startPlay() {
  Sound.ping();
  Scene.setMode('dive');
  Scene.hideTiers();
  Scene.setDepth(G.points * METERS_PER_POINT);
  el.quit.classList.toggle('hidden', G.mode === 'daily');
  el.hudMode.textContent = G.mode === 'daily' ? 'DIVE #' + G.n
    : G.mode === 'pack' ? (PACKS.find(p => p.id === G.packId) || {}).name || 'PACK' : 'UNLIMITED ∞';
  updateHud();
  show('play');
  showPrompt();
}
function currentPrompt() {
  if (G.mode === 'unlimited') {
    if (!G.queue.length) G.queue = shuffle(PROMPTS);
    if (!G.prompts[G.i]) G.prompts[G.i] = G.queue.shift();
  }
  return G.prompts[G.i];
}

/* ---- one prompt: 3-second descent, then the clock ---- */
function showPrompt() {
  const p = currentPrompt();
  G.token++; G.checkTok++;
  G.pending = null; G.timeUp = false;
  Scene.hideTiers();
  el.pText.textContent = p.q;
  el.pNum.textContent = G.mode === 'unlimited' ? `PROMPT ${G.i + 1}` : `PROMPT ${G.i + 1} / ${G.prompts.length}`;
  el.form.classList.remove('hidden');
  el.reveal.classList.add('hidden');
  el.skip.classList.toggle('hidden', G.mode !== 'unlimited');
  setMsg('');
  el.ans.value = ''; el.ans.disabled = true; el.ansBtn.disabled = true;
  if (G.mode === 'daily') store.set(dailyKey(G.n), { results: G.results, started: G.i, done: false });

  clearInterval(G.timer); clearInterval(G.countdownTimer);
  G.phase = 'countdown';
  let c = DESCENT_SECONDS;
  const tok = G.token;
  const paintCount = () => {
    el.pTimer.textContent = String(c);
    el.pTimer.classList.remove('low');
    el.ringBox.classList.add('counting');
    el.ring.style.strokeDashoffset = '0';
    setMsg('DESCENDING…', 'check');
    Sound.count();
  };
  paintCount();
  G.countdownTimer = setInterval(() => {
    if (G.token !== tok) { clearInterval(G.countdownTimer); return; }
    c--;
    if (c > 0) { paintCount(); return; }
    clearInterval(G.countdownTimer);
    el.ringBox.classList.remove('counting');
    Sound.go();
    G.phase = 'answer';
    setMsg('');
    el.ans.disabled = false; el.ansBtn.disabled = false;
    el.ans.focus({ preventScroll: true });
    if (G.mode !== 'unlimited') G.deadline = performance.now() + SECONDS_PER_PROMPT * 1000;
    G.lastTick = performance.now();
    G.lastWhole = null;
    G.timer = setInterval(tick, 100);
    tick();
  }, 1000);
}

const ANSWERING = ['answer', 'checking'];
function tick() {
  const now = performance.now();
  let left, total;
  if (G.mode === 'unlimited') {
    if (ANSWERING.includes(G.phase)) G.air = Math.max(0, G.air - (now - G.lastTick) / 1000);
    G.lastTick = now;
    left = G.air; total = UNLIMITED_AIR;
  } else {
    left = Math.max(0, (G.deadline - now) / 1000); total = SECONDS_PER_PROMPT;
  }
  const whole = Math.ceil(left);
  el.pTimer.textContent = G.mode === 'unlimited' ? String(whole) : String(whole);
  const low = left <= 5 && ANSWERING.includes(G.phase);
  el.pTimer.classList.toggle('low', low);
  el.ringBox.classList.toggle('low', left <= 5);
  el.ring.style.strokeDashoffset = String(100 - (left / total) * 100);
  if (low && whole !== G.lastWhole && whole > 0) Sound.tick();
  G.lastWhole = whole;

  if (left <= 0 && !G.timeUp && ANSWERING.includes(G.phase)) {
    G.timeUp = true;
    if (G.mode === 'unlimited') { clearInterval(G.timer); G.phase = 'over'; G.checkTok++; Sound.miss(); finishDive(); return; }
    clearInterval(G.timer);
    if (G.phase === 'answer') {
      const v = el.ans.value.trim();
      if (v) checkAnswer(v, true);       // an answer still in the box is submitted for you
      else resolve(null, '');
    }
    // phase 'checking': the running check finishes the prompt
  }
}

function submit(e) {
  e.preventDefault();
  if (G.phase !== 'answer') return;
  const val = el.ans.value.trim();
  if (!val) return;
  checkAnswer(val, false);
}

function tierFor(p, r) {
  if (p.t) {
    const loc = lookupLocal(p, r.display) || lookupLocal(p, r.title) || (r.said ? lookupLocal(p, r.said) : null);
    if (loc && loc.dist === 0) return loc.entry.tier;
  }
  return Checker.tierFromViews(r.views);
}

async function checkAnswer(val, auto) {
  const p = currentPrompt();
  const tok = ++G.checkTok;
  G.phase = 'checking'; G.pending = null;
  el.ansBtn.disabled = true;
  setMsg('CHECKING…', 'check');

  // Built-in chart first: instant, and gives hand-picked tiers
  const loc = lookupLocal(p, val);
  if (loc && loc.dist === 0) {
    resolve({ ok: true, display: display(loc.entry.name), title: loc.entry.name, tier: loc.entry.tier, fact: '', local: true }, val);
    return;
  }
  let result = null, offline = false;
  try {
    const r = await Checker.check(p, val);
    if (r && r.ok) result = Object.assign({}, r, { tier: tierFor(p, r) });
  } catch (err) { offline = true; }
  if (tok !== G.checkTok || G.phase !== 'checking') return;   // the prompt moved on
  if (result) { resolve(result, val); return; }
  if (G.timeUp || auto) { resolve(null, val); return; }
  G.phase = 'answer';
  el.ansBtn.disabled = false;
  setMsg(offline ? "CAN'T REACH THE ANSWER CHECKER. CHECK YOUR CONNECTION AND TRY AGAIN." : 'NOT A VALID ANSWER. TRY ANOTHER.', 'bad');
  el.card.classList.remove('shake'); void el.card.offsetWidth; el.card.classList.add('shake');
  Sound.wrong();
  el.ans.select();
}

function resolve(result, input) {
  if (!ANSWERING.includes(G.phase)) return;
  G.phase = 'reveal';
  G.checkTok++;
  G.pending = null;
  clearInterval(G.timer);
  if (G.mode !== 'unlimited') tick();
  const p = currentPrompt();
  const tier = result ? TIERS[result.tier] : null;
  const pts = tier ? tier.pts : 0;
  const base = G.points * METERS_PER_POINT;
  const rec = { q: p.q, id: p.id, input, name: result ? result.display : null, tier: result ? result.tier : -1, pts, fact: result ? result.fact || '' : '' };
  G.results.push(rec);
  G.points += pts;
  Scene.showTiers(base, result ? result.tier : -1);
  Scene.setDepth(G.points * METERS_PER_POINT);
  updateHud();
  const isLast = G.mode !== 'unlimited' && G.i + 1 >= G.prompts.length;
  if (G.mode === 'daily') saveDaily(isLast);

  el.ans.disabled = true; el.ansBtn.disabled = true;
  el.form.classList.add('hidden');
  setMsg('');
  el.reveal.classList.remove('hidden');
  el.rTier.textContent = tier ? tier.name : MISS.name;
  el.rTier.style.color = tier ? tier.color : MISS.color;
  el.rAns.textContent = result ? result.display : (input ? `“${input}” didn't count` : 'No answer');
  el.rPts.textContent = tier ? `+${pts} PTS · ▼ SINK ${(pts * METERS_PER_POINT).toLocaleString()} m` : '+0 PTS';
  el.rFact.textContent = rec.fact;
  if (result && !rec.fact) {
    const tok = G.token;
    Checker.fact(result.title || result.display).then(f => {
      if (!f) return;
      rec.fact = f;
      if (G.token === tok) el.rFact.textContent = f;
      if (G.mode === 'daily') saveDaily(isLast);
    });
  }
  el.next.textContent = isLast ? 'SEE YOUR DIVE ▼' : 'NEXT PROMPT ▼';
  if (tier) Sound.tier(result.tier); else Sound.miss();

  el.skip.classList.add('hidden');
  if (G.mode === 'unlimited' && tier) {
    const tok = G.token;
    el.next.classList.add('hidden');
    setTimeout(() => { if (G.token === tok && G.phase === 'reveal') next(); }, 2200);   // correct answers continue automatically
  } else {
    el.next.classList.remove('hidden');
    setTimeout(() => el.next.focus({ preventScroll: true }), 30);
  }
}

function next() {
  if (G.phase !== 'reveal') return;
  Sound.click();
  G.i++;
  if (G.mode !== 'unlimited' && G.i >= G.prompts.length) { finishDive(); return; }
  if (G.mode === 'unlimited' && G.air <= 0) { finishDive(); return; }
  showPrompt();
}
// Unlimited: skipped prompts go straight to the next one (air keeps draining while you answer, not while you skip)
function skip() {
  if (G.mode !== 'unlimited' || !ANSWERING.includes(G.phase)) return;
  Sound.click();
  G.phase = 'reveal'; G.checkTok++; G.pending = null;
  clearInterval(G.timer);
  G.prompts.splice(G.i, 1);
  G.phase = 'reveal';
  showPrompt();
}
function saveDaily(done) {
  store.set(dailyKey(G.n), { results: G.results, started: -1, done: !!done || G.results.length >= PROMPTS_PER_DIVE });
}
function updateHud() { el.hudPts.textContent = G.points.toLocaleString(); }
setInterval(() => { el.hudDepth.textContent = Math.round(Scene.depth()).toLocaleString() + ' m'; }, 80);

function finishDive() {
  clearInterval(G.timer); clearInterval(G.countdownTimer);
  G.phase = 'over'; G.token++; G.checkTok++;
  Scene.hideTiers();
  if (G.mode === 'daily') saveDaily(true);
  if (G.mode === 'unlimited') {
    const best = store.get(STORE_PREFIX + 'unlimited:best') || 0;
    if (G.points > best) store.set(STORE_PREFIX + 'unlimited:best', G.points);
  }
  showResults({ mode: G.mode, n: G.n, packId: G.packId, results: G.results });
}

/* ---- results ---- */
let countdownTimer = null, lastShare = '';
function showResults(r) {
  const pts = r.results.reduce((s, x) => s + x.pts, 0);
  const depth = pts * METERS_PER_POINT;
  const zone = zoneFor(depth);
  const grid = r.results.map(x => x.tier >= 0 ? TIERS[x.tier].emoji : MISS.emoji).join('');
  const pack = PACKS.find(p => p.id === r.packId);
  const band = TIERS[BANDS.find(b => pts >= b[0])[1]];

  $('#resTitle').textContent = r.mode === 'daily' ? `DIVE #${r.n} COMPLETE` : r.mode === 'pack' ? `${pack ? pack.name : 'PACK'} COMPLETE` : 'OUT OF AIR';
  $('#resMode').textContent = r.mode === 'unlimited' ? 'UNLIMITED ∞' : '';
  $('#resDepth').textContent = depth.toLocaleString() + ' m';
  $('#resZone').textContent = zone;
  const rb = $('#resBand'); rb.textContent = `RATING: ${band.name}`; rb.style.color = band.color;
  if (r.mode === 'unlimited') {
    const best = Math.max(store.get(STORE_PREFIX + 'unlimited:best') || 0, pts);
    $('#resPts').textContent = `${pts} PTS · ${r.results.filter(x => x.tier >= 0).length} ANSWERS · BEST ${(best * METERS_PER_POINT).toLocaleString()} m`;
  } else {
    $('#resPts').textContent = `${pts} / ${r.results.length * 100} PTS`;
  }
  $('#resGrid').textContent = grid;

  const list = $('#resList'); list.innerHTML = '';
  r.results.forEach(x => {
    const li = document.createElement('li');
    const q = document.createElement('span'); q.className = 'q'; q.textContent = x.q;
    const a = document.createElement('span'); a.className = 'a';
    a.textContent = x.name ? x.name : (x.input ? `“${x.input}” ✕` : '—');
    const tg = document.createElement('span'); tg.className = 't';
    const tier = x.tier >= 0 ? TIERS[x.tier] : MISS;
    tg.textContent = `${tier.name} +${x.pts}`; tg.style.color = tier.color;
    li.append(q, tg, a); list.append(li);
  });

  const head = r.mode === 'daily' ? `TUNGION #${r.n} 🦐` : r.mode === 'pack' ? `TUNGION · ${pack ? pack.name : 'PACK'} 🦐` : 'TUNGION ∞ UNLIMITED 🦐';
  lastShare = `${head}\n${depth.toLocaleString()} m · ${zone}\n${grid}\nRarer answers sink deeper.`;

  clearInterval(countdownTimer);
  const nx = $('#resNext');
  if (r.mode === 'daily') {
    const upd = () => {
      const now = new Date(), mid = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      let s = Math.max(0, Math.floor((mid - now) / 1000));
      const h = Math.floor(s / 3600); s %= 3600; const m = Math.floor(s / 60); s %= 60;
      nx.textContent = `NEXT DIVE IN ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    };
    upd(); countdownTimer = setInterval(upd, 1000);
  } else nx.textContent = 'PLAY AGAIN FROM THE SURFACE';

  show('results');
  setTimeout(() => $('#shareBtn').focus({ preventScroll: true }), 50);
}

async function share() {
  Sound.click();
  let ok = false;
  try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(lastShare); ok = true; } } catch (e) { ok = false; }
  if (!ok) {
    const ta = document.createElement('textarea');
    ta.value = lastShare; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.append(ta); ta.select();
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
  }
  toast(ok ? 'COPIED TO CLIPBOARD' : 'COPY FAILED. SELECT THE GRID TO SHARE');
}

function goHome() {
  Sound.click();
  clearInterval(G.timer); clearInterval(countdownTimer); clearInterval(G.countdownTimer);
  G.phase = 'idle'; G.token++; G.checkTok++;
  Scene.hideTiers();
  Scene.setMode('home'); Scene.setDepth(0);
  refreshHome();
  show('home');
}

/* ---- modals ---- */
function openModal(id) { Sound.click(); $(id).classList.remove('hidden'); const x = $(id).querySelector('[data-close]'); if (x) x.focus(); }
function closeModals() { document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden')); }

function buildStatic() {
  const tbl = $('#tierTable');
  TIERS.forEach(t => {
    const tr = document.createElement('tr');
    const a = document.createElement('td'); a.textContent = t.name; a.style.color = t.color;
    const b = document.createElement('td'); b.textContent = t.desc;
    const c = document.createElement('td'); c.className = 'num'; c.textContent = `${t.pts} · ${(t.pts * METERS_PER_POINT).toLocaleString()}m`;
    tr.append(a, b, c); tbl.append(tr);
  });
  $('#promptCount').textContent = PROMPTS.length.toLocaleString();
  const pl = $('#packList');
  PACKS.forEach(pk => {
    const n = PROMPTS.filter(p => p.pack === pk.id).length;
    if (!n) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'pack';
    b.innerHTML = '<span><div class="pn"></div><div class="pb"></div></span><span class="go">DIVE ▼</span>';
    b.querySelector('.pn').textContent = pk.name;
    b.querySelector('.pb').textContent = `${pk.blurb} ${n.toLocaleString()} prompts.`;
    b.addEventListener('click', () => beginPack(pk.id));
    pl.append(b);
  });
}

/* ---- wiring ---- */
el.form.addEventListener('submit', submit);
el.next.addEventListener('click', next);
el.skip.addEventListener('click', skip);
el.begin.addEventListener('click', () => { Sound.click(); beginDaily(); });
$('#howBtn').addEventListener('click', () => openModal('#howModal'));
$('#packsBtn').addEventListener('click', () => openModal('#packsModal'));
$('#unlBtn').addEventListener('click', () => { Sound.click(); beginUnlimited(); });
$('#shareBtn').addEventListener('click', share);
$('#homeBtn').addEventListener('click', goHome);
el.quit.addEventListener('click', goHome);
$('#soundBtn').addEventListener('click', () => {
  Sound.on = !Sound.on; store.set('tungion:sound', Sound.on); paintSound();
  if (Sound.on) { Sound.init(); Sound.click(); }
});
document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m || e.target.closest('[data-close]')) closeModals(); });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModals();
  if (e.key === 'Enter' && !e.repeat && G.phase === 'reveal' && !el.play.classList.contains('hidden') && document.activeElement !== el.next) {
    e.preventDefault(); next();
  }
});

buildStatic();
paintSound();
refreshHome();
setInterval(() => { if (!el.home.classList.contains('hidden')) refreshHome(); }, 30000);

// for testing
window.TUNGION = { lookupLocal, diveNumber, dailyPrompts, PROMPTS, G };
})();
