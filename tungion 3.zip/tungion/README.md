# TUNGION · The Daily Dive

7 prompts · 15 seconds each · rarer answers sink deeper.

A daily trivia game where obvious answers barely count. There are 750+ everyday prompts, and any real
answer counts: answers are checked **live** against Wikipedia and Wikidata, not against a fixed list.
The rarer your answer, the deeper your krill sinks. Every point is 10 m, and a perfect dive
(700 pts) reaches 7,000 m.

How answers are judged:
- **Is it valid?** The game finds the Wikipedia page you mean (titles, redirects, search, and names
  in other languages through Wikidata, so "pamplemousse" finds Grapefruit) and checks it against
  the prompt's rule (e.g. it must be a fruit, or a city in Japan).
- **No autocorrect.** Spelling counts. Capitals, accents, plurals and a leading "the" don't matter.
- **How rare?** Rarity comes from how many people read that page in the last 30 days. Fewer readers
  means a deeper tier. Twenty-one hand-made prompts also have built-in charts with hand-picked tiers.
- The One in a Tungion answer is never revealed.

Live checking needs an internet connection (Codespaces has one).

| Tier | Points | Depth |
|---|---|---|
| Plankton | 10 | 100 m |
| Too Clever | 15 | 150 m |
| Schooler | 30 | 300 m |
| Rare | 60 | 600 m |
| Deep Cut | 85 | 850 m |
| One in a Tungion | 100 | 1,000 m |

Modes: **Daily Dive** (one per day, same 7 prompts for everyone, resets at local midnight),
**Themed Packs** (7 prompts from one theme, replayable) and **Unlimited** (one 45-second
air tank that drains only while you're answering).

## Run it in GitHub Codespaces

1. Create a new GitHub repository and upload every file in this folder
   (keep the hidden `.devcontainer` folder).
2. On the repo page click **Code → Codespaces → Create codespace on main**.
3. When the codespace opens, the game server starts on its own and the
   game opens in a new browser tab. If the tab doesn't appear, open the
   **Ports** panel and click the globe icon next to port **8080**.

If the server isn't running for any reason, type this in the terminal:

```
python3 -m http.server 8080
```

## Run it anywhere else

It's a static site with no build step: open `index.html` in a browser, or serve the
folder with any static server.

## Editing the game

- `prompts.js` – the prompt bank and each prompt's checking rule (explained at the top of the file).
- `checker.js` – live answer checking, spelling correction and rarity.
- `data.js` – the 21 hand-made prompts with built-in tier charts, and the themed pack list.
- `game.js` – game logic and the pixel-art ocean. Timer length, air tank and launch date
  are at the top.
- `style.css` – look and feel.
