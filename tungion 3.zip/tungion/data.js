/* TUNGION answer charts.
   Each prompt lists accepted answers by tier. Commas separate answers,
   pipes separate aliases of the same answer (first alias is the display name).
   pre / suf: words stripped from the start / end before matching
   (so "Mount Everest" = "Everest", "Mako shark" = "Mako"). */

window.TUNGION_PACKS = [
  { id: 'galley',    name: 'THE GALLEY',       blurb: 'Food, drink and things you can taste.' },
  { id: 'creatures', name: 'CREATURE FEATURE', blurb: 'Beasts, breeds, bugs and blooms.' },
  { id: 'atlas',     name: 'THE ATLAS',        blurb: 'Cities, rivers, peaks and places.' },
  { id: 'screen',    name: 'SILVER SCREEN',    blurb: 'Films, directors and TV series.' },
  { id: 'sound',     name: 'DEEP CUTS',        blurb: 'Songs, albums and musicians.' },
  { id: 'shelf',     name: 'THE SHELF',        blurb: 'Books, writers and art.' },
  { id: 'arcade',    name: 'ARCADE',           blurb: 'Video games and game nights.' },
  { id: 'lab',       name: 'THE LAB',          blurb: 'Science, space and technology.' },
  { id: 'pantheon',  name: 'PANTHEON',         blurb: 'Rulers, legends, gods and icons.' },
  { id: 'arena',     name: 'THE ARENA',        blurb: 'Teams, sports and games people play.' },
  { id: 'grabbag',   name: 'GRAB BAG',         blurb: 'Anything that washed up on deck.' }
];

window.TUNGION_PROMPTS = [
  /* ---------------- THE GALLEY ---------------- */
  { id: 'pasta', pack: 'galley', q: 'Name a pasta shape', suf: ['pasta'], t: {
    plankton: 'spaghetti, penne, macaroni|mac, lasagna|lasagne, fettuccine|fettucine|fettuccini',
    clever:   'orzo, farfalle|bow tie|bowtie|bow ties',
    schooler: 'rigatoni, linguine|linguini, fusilli, ravioli, tortellini, ziti, rotini, angel hair|capellini, tagliatelle, pappardelle, bucatini, cavatappi, conchiglie|shells|shell, gnocchi, rotelle|wagon wheels',
    rare:     'orecchiette, cavatelli, campanelle, gemelli, radiatori, paccheri, mafaldine|mafalde, ditalini, trofie, strozzapreti, vermicelli, manicotti, cannelloni, agnolotti, fregola|fregula',
    deep:     'casarecce, lumache, anelli, corzetti, garganelli, scialatielli, bigoli, pici, sorprese, lorighittas, cappelletti, stelline, acini di pepe, tortiglioni, calamarata',
    gem:      'su filindeu|filindeu'
  }},
  { id: 'cheese', pack: 'galley', q: 'Name a cheese', suf: ['cheese'], t: {
    plankton: 'cheddar, mozzarella, swiss, parmesan|parmigiano reggiano|parmigiano, american',
    clever:   'casu marzu, limburger, roquefort',
    schooler: 'brie, gouda, feta, provolone, ricotta, monterey jack|jack, pepper jack, colby, gruyere, blue cheese|blue|bleu, camembert, goat cheese|goat|chevre, havarti, muenster|munster, cottage cheese|cottage, cream cheese|cream, pecorino|pecorino romano, manchego, halloumi, mascarpone, emmental|emmentaler',
    rare:     'taleggio, fontina, asiago, gorgonzola, burrata, paneer, queso fresco, comte, edam, jarlsberg, stilton, raclette, reblochon, oaxaca|quesillo, cotija, wensleydale, gjetost|brunost, boursin, epoisses, colby jack',
    deep:     'tete de moine, mimolette, caciocavallo, vacherin, morbier, beaufort, saint agur, cabrales, idiazabal, leyden, castelmagno, bryndza, sulguni, kashkaval, telemea, abondance, cantal, salers, ossau iraty, langres',
    gem:      'pule|donkey cheese|donkey milk cheese'
  }},
  { id: 'fruit', pack: 'galley', q: 'Name a fruit', t: {
    plankton: 'apple, banana, orange, strawberry, grape',
    clever:   'dragon fruit|dragonfruit|pitaya, durian, starfruit|star fruit|carambola, tomato',
    schooler: 'pear, peach, cherry, mango, pineapple, watermelon, blueberry, raspberry, lemon, lime, plum, kiwi|kiwifruit, grapefruit, cantaloupe, apricot, blackberry, pomegranate, coconut, papaya, nectarine, fig, cranberry, avocado, honeydew, tangerine, clementine',
    rare:     'lychee|litchi, passion fruit|passionfruit, guava, persimmon, jackfruit, quince, kumquat, gooseberry, rambutan, mangosteen, elderberry, mulberry, date, boysenberry, plantain, tamarind, loquat, yuzu, pomelo, huckleberry, currant|blackcurrant|redcurrant',
    deep:     'pawpaw, cherimoya, salak|snake fruit, longan, feijoa, sapodilla, soursop|guanabana, jabuticaba, ackee|akee, medlar, cloudberry, lingonberry, marionberry, physalis|ground cherry, ugli fruit|ugli, rambai, santol, bilberry, sea buckthorn, horned melon|kiwano',
    gem:      'miracle fruit|miracle berry'
  }},
  { id: 'cereal', pack: 'galley', q: 'Name a breakfast cereal', suf: ['cereal'], t: {
    plankton: 'cheerios, frosted flakes, corn flakes|cornflakes, froot loops|fruit loops, lucky charms',
    clever:   'grape nuts',
    schooler: 'cinnamon toast crunch, rice krispies|rice crispies, cocoa puffs, raisin bran, special k, honey nut cheerios, capn crunch|captain crunch, trix, apple jacks, cocoa pebbles, fruity pebbles, frosted mini wheats|mini wheats, honey bunches of oats, golden grahams, kix, chex, life, reeses puffs, corn pops, wheaties, count chocula',
    rare:     'shredded wheat, honey smacks, golden crisp, cookie crisp, crispix, franken berry, boo berry, alpha bits, total, basic 4, cracklin oat bran, quisp, oatmeal crisp, weetabix, muesli, granola, cocoa krispies, krave, puffins, crunch berries',
    deep:     'kaboom, waffle crisp, oreo os, french toast crunch, mr t, sir grapefellow, freakies, pac man, nerds, ice cream cones, cinnamon mini buns, smurf berry crunch, product 19, ohs|oh s, fruity yummy mummy|yummy mummy',
    gem:      'urkel os|urkelos'
  }},
  { id: 'spice', pack: 'galley', q: 'Name a spice or herb', t: {
    plankton: 'pepper|black pepper, cinnamon, garlic, oregano, basil',
    clever:   'saffron',
    schooler: 'paprika, cumin, nutmeg, ginger, thyme, rosemary, parsley, cilantro|coriander, turmeric, chili powder|chilli powder, cayenne|cayenne pepper, dill, mint, sage, bay leaf|bay leaves|bay, cloves|clove, chives, allspice, red pepper flakes|chili flakes',
    rare:     'cardamom, fennel, tarragon, star anise, marjoram, sumac, fenugreek, mustard seed|mustard, lemongrass, caraway, chervil, anise|aniseed, mace, lavender, zaatar, juniper|juniper berries, sichuan pepper|szechuan pepper, vanilla, galangal',
    deep:     'asafoetida|hing, grains of paradise, nigella|kalonji, ajwain, epazote, long pepper, mahleb|mahlab, annatto|achiote, lovage, sorrel, savory, hyssop, culantro, kaffir lime leaf|makrut lime leaf|lime leaf, amchur|amchoor, kokum, shiso|perilla, file powder|file|gumbo file, borage',
    gem:      'grains of selim'
  }},
  { id: 'soup', pack: 'galley', q: 'Name a soup', suf: ['soup'], t: {
    plankton: 'chicken noodle, tomato, minestrone, french onion, clam chowder',
    clever:   'gazpacho, borscht|borsch',
    schooler: 'chowder, pho, ramen, miso, lentil, split pea, broccoli cheddar, potato leek|leek and potato, lobster bisque, bisque, wonton, egg drop, hot and sour, tortilla, gumbo, matzo ball|matzah ball, butternut squash, vegetable, mushroom|cream of mushroom, corn chowder',
    rare:     'mulligatawny, avgolemono, vichyssoise, tom yum, tom kha|tom kha gai, menudo, pozole|posole, caldo verde, ribollita, bouillabaisse, cock a leekie, laksa, cullen skink, harira, solyanka, shchi, sopa de lima, italian wedding|wedding, oxtail, scotch broth',
    deep:     'callaloo, sinigang, tinola, okroshka, cioppino, caldo de siete mares, ajiaco, sancocho, pasulj, kharcho, zurek, frittatensuppe, ezogelin, garbure, waterzooi, soto ayam|soto, sayur asem, shorba, chupe de camarones, kartoffelsuppe',
    gem:      'fanesca'
  }},
  { id: 'cocktail', pack: 'galley', q: 'Name a cocktail', suf: ['cocktail'], t: {
    plankton: 'margarita, martini, mojito, old fashioned, pina colada',
    clever:   'negroni, aperol spritz|spritz',
    schooler: 'cosmopolitan|cosmo, manhattan, daiquiri, mai tai, long island iced tea|long island, whiskey sour|whisky sour, bloody mary, moscow mule, mimosa, tequila sunrise, gin and tonic|g and t, white russian, screwdriver, sex on the beach, mint julep, paloma, tom collins, espresso martini, bellini, sidecar',
    rare:     'sazerac, gimlet, french 75, dark n stormy|dark and stormy, hurricane, zombie, mudslide, caipirinha, pisco sour, aviation, boulevardier, last word, corpse reviver|corpse reviver 2|corpse reviver no 2, rob roy, grasshopper, singapore sling, kir royale|kir, americano, black russian, brandy alexander',
    deep:     'ramos gin fizz|ramos fizz, vieux carre, bees knees, hanky panky, paper plane, jungle bird, clover club, martinez, penicillin, bramble, el presidente, mary pickford, hemingway daiquiri, naked and famous, toronto, scofflaw, jack rose, blood and sand, widows kiss, gold rush',
    gem:      'chartreuse swizzle'
  }},

  /* ---------------- CREATURE FEATURE ---------------- */
  { id: 'shark', pack: 'creatures', q: 'Name a type of shark', suf: ['shark'], t: {
    plankton: 'great white|white, hammerhead|great hammerhead, tiger shark|tiger, whale shark|whale, bull shark|bull',
    clever:   'megalodon|meg, goblin shark|goblin',
    schooler: 'mako|shortfin mako, nurse shark|nurse, basking shark|basking, lemon shark|lemon, blue shark|blue, reef shark|reef, blacktip|blacktip reef, whitetip|whitetip reef, thresher, greenland shark|greenland, sand tiger, leopard shark|leopard, oceanic whitetip, dogfish|spiny dogfish, angel shark|angel',
    rare:     'wobbegong, frilled shark|frilled, cookiecutter|cookie cutter, megamouth, sixgill|bluntnose sixgill, sevengill, porbeagle, silky shark|silky, salmon shark|salmon, zebra shark|zebra, horn shark|horn, port jackson, bonnethead, epaulette, catshark|cat shark|cat, carpet shark|carpet, spinner shark|spinner, dusky shark|dusky, sleeper shark|sleeper, sawshark|saw',
    deep:     'pocket shark|pocket, lanternshark|lantern, tasselled wobbegong|tasseled wobbegong, crocodile shark|crocodile, bramble shark|bramble, kitefin, pyjama shark|pajama shark|pyjama|pajama, swell shark|swell, galapagos shark|galapagos, blacknose, bigeye thresher, gulper shark|gulper, viper dogfish|viper shark, prickly shark|prickly, daggernose, winghead, smalltooth sand tiger, shortnose sawshark, velvet belly, pygmy shark|pygmy',
    gem:      'ninja lanternshark|ninja lantern shark|ninja'
  }},
  { id: 'dog', pack: 'creatures', q: 'Name a dog breed', suf: ['dog'], t: {
    plankton: 'labrador|labrador retriever|lab, golden retriever|golden, german shepherd|alsatian, poodle, bulldog|english bulldog',
    clever:   'shiba inu|shiba, corgi|welsh corgi|pembroke welsh corgi',
    schooler: 'beagle, husky|siberian husky, chihuahua, dachshund|wiener dog|sausage dog, boxer, rottweiler, pug, great dane, doberman|doberman pinscher, border collie, shih tzu, yorkshire terrier|yorkie, pomeranian, french bulldog|frenchie, cocker spaniel, australian shepherd|aussie, maltese, pit bull|pitbull|american pit bull terrier, labradoodle, bernese mountain dog|bernese, saint bernard|st bernard, greyhound, dalmatian, mastiff, akita',
    rare:     'basenji, vizsla, weimaraner, whippet, samoyed, shar pei, chow chow|chow, newfoundland, bichon frise|bichon, papillon, rhodesian ridgeback, malamute|alaskan malamute, bloodhound, basset hound|basset, airedale|airedale terrier, schnauzer, borzoi, saluki, afghan hound|afghan, keeshond, bull terrier',
    deep:     'xoloitzcuintli|xolo|mexican hairless, lagotto romagnolo|lagotto, kooikerhondje, azawakh, mudi, puli, komondor, otterhound, sloughi, catahoula|catahoula leopard dog, bergamasco, chinook, finnish spitz, cesky terrier, sealyham terrier|sealyham, dandie dinmont terrier|dandie dinmont, glen of imaal terrier, peruvian inca orchid, thai ridgeback, norwegian elkhound',
    gem:      'norwegian lundehund|lundehund'
  }},
  { id: 'bird', pack: 'creatures', q: 'Name a bird', t: {
    plankton: 'eagle, robin, cardinal, blue jay|bluejay, crow, pigeon',
    clever:   'dodo, shoebill',
    schooler: 'owl, hawk, falcon, parrot, penguin, flamingo, ostrich, sparrow, seagull|gull, duck, swan, hummingbird, woodpecker, pelican, peacock|peafowl, turkey, chicken, goose, raven, vulture, emu, toucan, bald eagle, magpie, finch, canary, heron, stork, kiwi, bluebird, parakeet|budgie',
    rare:     'kakapo, cassowary, puffin, albatross, kingfisher, roadrunner, oriole, cockatoo, macaw, ibis, egret, osprey, condor, starling, wren, nightingale, lyrebird, bird of paradise, quetzal, hoopoe, tern, cormorant',
    deep:     'potoo, kagu, oilbird, sunbittern, frogmouth|tawny frogmouth, bowerbird, secretarybird|secretary bird, jacana, turaco, motmot, dipper, wallcreeper, takahe, kea, hornbill, nightjar, limpkin, bushtit, phainopepla, ovenbird',
    gem:      'hoatzin|stinkbird'
  }},
  { id: 'insect', pack: 'creatures', q: 'Name an insect', t: {
    plankton: 'ant, bee, butterfly, fly|housefly|house fly, mosquito, ladybug|ladybird',
    clever:   'cicada, praying mantis|mantis',
    schooler: 'beetle, grasshopper, cockroach|roach, dragonfly, wasp, moth, cricket, termite, firefly|lightning bug, flea, hornet, louse|lice, gnat, aphid, stink bug, bumblebee, honeybee|honey bee, earwig, stick insect|walking stick, june bug|june beetle, yellowjacket|yellow jacket, fruit fly',
    rare:     'katydid, weevil, silverfish, mayfly, damselfly, lacewing, scarab, dung beetle, stag beetle, caddisfly, horsefly, firebrat, leafhopper, thrips, mealybug, assassin bug, water strider, antlion, locust, cicada killer, hercules beetle',
    deep:     'hellgrammite, dobsonfly, scorpionfly, snakefly, webspinner, zorapteran|angel insect, stonefly, bombardier beetle, treehopper, botfly, sawfly, cochineal, robber fly, tsetse fly|tsetse, velvet ant, giraffe weevil, rhinoceros beetle, goliath beetle, owlfly, twisted wing parasite|strepsiptera',
    gem:      'tree lobster|lord howe island stick insect'
  }},
  { id: 'dino', pack: 'creatures', q: 'Name a dinosaur', t: {
    plankton: 't rex|trex|tyrannosaurus|tyrannosaurus rex, triceratops, velociraptor, stegosaurus, brontosaurus',
    clever:   'spinosaurus, archaeopteryx',
    schooler: 'brachiosaurus, ankylosaurus, diplodocus, allosaurus, parasaurolophus, pachycephalosaurus, iguanodon, apatosaurus, dilophosaurus, raptor, carnotaurus, giganotosaurus, utahraptor, deinonychus, compsognathus, gallimimus, argentinosaurus, maiasaura',
    rare:     'therizinosaurus, microraptor, oviraptor, troodon, protoceratops, styracosaurus, corythosaurus, edmontosaurus, baryonyx, kentrosaurus, plateosaurus, coelophysis, herrerasaurus, mamenchisaurus, ouranosaurus, dreadnoughtus, suchomimus, amargasaurus, sauropelta, pentaceratops',
    deep:     'nigersaurus, kosmoceratops, yi qi, irritator, mei long, borealopelta, halszkaia, masiakasaurus, mononykus, deinocheirus, minmi, zuul, eoraptor, sinosauropteryx, anchiornis, citipati, qianzhousaurus, tsintaosaurus, stygimoloch, nothronychus',
    gem:      'micropachycephalosaurus'
  }},
  { id: 'marsupial', pack: 'creatures', q: 'Name a marsupial', t: {
    plankton: 'kangaroo, koala, opossum, wallaby',
    clever:   'tasmanian devil',
    schooler: 'wombat, sugar glider, possum, quokka, tasmanian tiger|thylacine, bandicoot, wallaroo, red kangaroo, grey kangaroo|gray kangaroo',
    rare:     'numbat, bilby, quoll, cuscus, tree kangaroo, potoroo, bettong, pademelon, dunnart, antechinus, phascogale, rock wallaby, greater glider, ringtail possum, brushtail possum, feathertail glider',
    deep:     'monito del monte, kultarr, ningaui, planigale, marsupial mole, honey possum|noolbenger, kowari, mulgara, shrew opossum, marsupial lion|thylacoleo, diprotodon, bridled nailtail wallaby, mountain pygmy possum, scaly tailed possum',
    gem:      'yapok|water opossum'
  }},
  { id: 'seacreature', pack: 'creatures', q: 'Name a sea creature', t: {
    plankton: 'dolphin, whale, shark, octopus, jellyfish|jelly, fish',
    clever:   'krill, giant squid',
    schooler: 'starfish|sea star, crab, lobster, seahorse|sea horse, sea turtle|turtle, squid, stingray, manta ray|manta, eel, clam, oyster, shrimp|prawn, sea urchin|urchin, orca|killer whale, narwhal, seal, sea lion, walrus, coral, sea anemone|anemone, pufferfish|puffer fish|blowfish, barracuda, swordfish, tuna, clownfish|clown fish, blue whale, humpback whale|humpback, beluga, sea cucumber, manatee, sea otter|otter',
    rare:     'nudibranch, cuttlefish, nautilus, anglerfish|angler fish|angler, moray eel|moray, dugong, mantis shrimp, hermit crab, barnacle, sea slug, lionfish, blobfish, oarfish, sunfish|mola mola|mola|ocean sunfish, sea pig, sea spider, horseshoe crab, sand dollar, sea sponge|sponge, portuguese man o war|man o war, hagfish, lamprey, leafy sea dragon|leafy seadragon|sea dragon, coelacanth',
    deep:     'vampire squid, dumbo octopus, siphonophore, salp, pyrosome, giant isopod, yeti crab, gulper eel|pelican eel, fangtooth, viperfish, frilled shark, sea butterfly|pteropod, copepod, comb jelly|ctenophore, larvacean, sea angel, bobbit worm, christmas tree worm, feather star|crinoid, sea toad',
    gem:      'barreleye|barreleye fish|spookfish'
  }},

  /* ---------------- THE ATLAS ---------------- */
  { id: 'africa', pack: 'atlas', q: 'Name a country in Africa', t: {
    plankton: 'egypt, south africa, nigeria, kenya, morocco',
    clever:   'madagascar',
    schooler: 'ethiopia, ghana, algeria, tanzania, uganda, zimbabwe, somalia, sudan, libya, tunisia, senegal, cameroon, democratic republic of the congo|drc|dr congo|congo|congo kinshasa, angola, mozambique, zambia, namibia, botswana, rwanda, mali, ivory coast|cote divoire',
    rare:     'niger, chad, liberia, sierra leone, guinea, burkina faso, malawi, eritrea, south sudan, gabon, benin, togo, mauritania, central african republic|car, lesotho, eswatini|swaziland, burundi, djibouti, gambia|the gambia, mauritius, republic of the congo|congo brazzaville',
    deep:     'comoros, equatorial guinea, guinea bissau, cape verde|cabo verde, seychelles',
    gem:      'sao tome and principe|sao tome|sao tome principe'
  }},
  { id: 'statecap', pack: 'atlas', q: 'Name a U.S. state capital', t: {
    plankton: 'sacramento, austin, boston, atlanta, denver',
    clever:   'montpelier',
    schooler: 'phoenix, nashville, honolulu, indianapolis, columbus, richmond, salt lake city|salt lake, albany, tallahassee, raleigh, springfield, lansing, madison, saint paul|st paul, oklahoma city, baton rouge, providence, hartford, annapolis, little rock, santa fe, boise, juneau, des moines',
    rare:     'olympia, salem, carson city, cheyenne, lincoln, topeka, montgomery, jackson, harrisburg, trenton, concord, charleston, columbia',
    deep:     'frankfort, jefferson city, bismarck, helena, dover, augusta',
    gem:      'pierre'
  }},
  { id: 'eurocap', pack: 'atlas', q: 'Name a European capital city', t: {
    plankton: 'paris, london, rome, berlin, madrid',
    clever:   'vatican city|vatican',
    schooler: 'amsterdam, athens, vienna, dublin, lisbon, brussels, prague, stockholm, oslo, copenhagen, warsaw, budapest, moscow, helsinki, bern|berne, kyiv|kiev, reykjavik, monaco',
    rare:     'bucharest, sofia, belgrade, zagreb, bratislava, ljubljana, tallinn, riga, vilnius, minsk, luxembourg|luxembourg city, valletta, andorra la vella, san marino, tirana, sarajevo, skopje, podgorica, chisinau, nicosia, ankara, edinburgh, cardiff, belfast',
    deep:     'pristina, tbilisi, yerevan, baku, torshavn',
    gem:      'vaduz'
  }},
  { id: 'mountain', pack: 'atlas', q: 'Name a mountain', pre: ['mount', 'mt'], t: {
    plankton: 'everest|mount everest, kilimanjaro, fuji|mount fuji|fujisan, k2, matterhorn',
    clever:   'mont blanc, denali|mckinley',
    schooler: 'rainier, st helens|saint helens, aconcagua, elbrus, pikes peak, whitney, hood, vesuvius, etna, kangchenjunga|kanchenjunga, annapurna, ben nevis, olympus, sinai, kosciuszko|kosciusko, rushmore, shasta',
    rare:     'lhotse, makalu, cho oyu, nanga parbat, dhaulagiri, manaslu, eiger, jungfrau, zugspitze, popocatepetl, chimborazo, cotopaxi, cook|aoraki, kenya, ararat, logan, washington, mauna kea, mauna loa, table mountain, half dome',
    deep:     'gasherbrum, broad peak, shishapangma, ama dablam, fitz roy|cerro fitz roy|fitzroy, cerro torre, vinson|vinson massif, puncak jaya|carstensz|carstensz pyramid, huascaran, ojos del salado, rwenzori|margherita peak, ras dashen, erebus, kailash, damavand, triglav, musala, gerlach, grossglockner, monte rosa',
    gem:      'olympus mons'
  }},
  { id: 'instrument', pack: 'atlas', q: 'Name a musical instrument', t: {
    plankton: 'piano, guitar, drums|drum|drum kit|drum set, violin, trumpet',
    clever:   'theremin, kazoo',
    schooler: 'flute, saxophone|sax, clarinet, cello, harp, trombone, tuba, bass|bass guitar, ukulele, banjo, harmonica, oboe, bassoon, french horn|horn, xylophone, accordion, viola, keyboard, organ, tambourine, triangle, bagpipes, recorder, cymbals|cymbal, double bass|upright bass|contrabass, piccolo, synthesizer|synth, mandolin',
    rare:     'sitar, didgeridoo, marimba, glockenspiel, harpsichord, bongos, conga|congas, steel drum|steel pan|steelpan, lute, dulcimer, zither, ocarina, euphonium, cornet, celesta, vibraphone, timpani, bodhran, castanets, koto, shamisen, balalaika, kalimba',
    deep:     'hurdy gurdy, sackbut, crumhorn, serpent, ondes martenot, erhu, guzheng, pipa, oud, kora, mbira, sarangi, shakuhachi, duduk, handpan|hang drum|hang, glass harmonica|glass armonica, theorbo, cimbalom, bandoneon, tromba marina',
    gem:      'nyckelharpa'
  }},
  { id: 'moon', pack: 'atlas', q: 'Name a moon in our solar system', t: {
    plankton: 'moon|the moon|luna, titan, europa',
    clever:   'charon',
    schooler: 'io, ganymede, callisto, phobos, deimos, enceladus, triton',
    rare:     'mimas, iapetus, rhea, dione, tethys, miranda, oberon, titania, umbriel, ariel, hyperion, nereid, amalthea',
    deep:     'pan, daphnis, atlas, prometheus, pandora, janus, epimetheus, phoebe, himalia, metis, adrastea, thebe, proteus, larissa, galatea, puck, cordelia, ophelia, dysnomia, nix, hydra, kerberos, styx, hiiaka, namaka',
    gem:      'mab'
  }},
  { id: 'language', pack: 'atlas', q: 'Name a language', suf: ['language'], t: {
    plankton: 'english, spanish, french, chinese|mandarin|mandarin chinese, german',
    clever:   'klingon, esperanto, latin',
    schooler: 'japanese, italian, portuguese, russian, arabic, hindi, korean, cantonese, greek, dutch, swedish, polish, turkish, hebrew, vietnamese, thai, tagalog|filipino, swahili, urdu, bengali|bangla, persian|farsi, norwegian, danish, finnish, irish|irish gaelic|gaelic, american sign language|asl|sign language, sanskrit',
    rare:     'welsh, icelandic, hungarian, czech, romanian, ukrainian, punjabi, tamil, telugu, marathi, gujarati, malay, indonesian, amharic, yoruba, zulu, xhosa, hausa, igbo, navajo, cherokee, basque, catalan, quechua, maori, hawaiian, khmer, lao, burmese, mongolian, tibetan, yiddish, afrikaans, estonian, latvian, lithuanian, slovak, serbian, croatian, bulgarian, albanian, armenian, georgian, kurdish, pashto, nepali, sinhala, somali, scottish gaelic',
    deep:     'ainu, sami, faroese, frisian, breton, cornish, manx, romansh, sorbian, ladino, aramaic, coptic, tok pisin, guarani, aymara, nahuatl, inuktitut, ojibwe, lakota, chamorro, tuvan, chechen, ossetian, livonian, wolof, tigrinya',
    gem:      'silbo gomero|silbo'
  }}
];

/* Live-check rules for the curated prompts (see prompts.js for how rules work). */
(function () {
  const EUROPE = '\\b(albania|andorra|armenia|austria|azerbaijan|belarus|belgium|bosnia|bulgaria|croatia|cyprus|czech|denmark|estonia|finland|france|georgia|germany|greece|hungary|iceland|ireland|italy|kosovo|latvia|liechtenstein|lithuania|luxembourg|malta|moldova|monaco|montenegro|netherlands|macedonia|norway|poland|portugal|romania|russia|san marino|serbia|slovakia|slovenia|spain|sweden|switzerland|turkey|ukraine|united kingdom|england|scotland|wales|northern ireland|vatican|faroe|europe)';
  const US = '\\b(united states|u\\.s\\.|us state|state of)\\b|\\b(alabama|alaska|arizona|arkansas|california|colorado|connecticut|delaware|florida|georgia|hawaii|idaho|illinois|indiana|iowa|kansas|kentucky|louisiana|maine|maryland|massachusetts|michigan|minnesota|mississippi|missouri|montana|nebraska|nevada|new hampshire|new jersey|new mexico|new york|north carolina|north dakota|ohio|oklahoma|oregon|pennsylvania|rhode island|south carolina|south dakota|tennessee|texas|utah|vermont|virginia|washington|west virginia|wisconsin|wyoming)\\b';
  const R = {
    pasta:      { fam: 'food', hint: 'pasta', type: '\\b(pasta|noodle|noodles|dumpling|gnocchi)\\b' },
    cheese:     { fam: 'food', hint: 'cheese', type: '\\bcheeses?\\b' },
    fruit:      { fam: 'food', hint: 'fruit', type: '\\b(fruit|fruits|berry|berries|citrus|drupe|pome|melon|cultivar)\\b' },
    cereal:     { fam: 'food', hint: 'breakfast cereal', type: '\\b(breakfast cereal|cereal|cereals)\\b' },
    spice:      { fam: 'food', hint: 'spice herb', type: '\\b(spice|spices|herb|herbs|seasoning|condiment|flavou?ring|culinary)\\b' },
    soup:       { fam: 'food', hint: 'soup', type: '\\b(soup|soups|broth|stew|chowder|bisque|consomm[eé]|potage|gumbo|pottage)\\b' },
    cocktail:   { fam: 'food', hint: 'cocktail', type: '\\b(cocktail|cocktails|mixed drink|highball|punch)\\b' },
    shark:      { fam: 'animals', hint: 'shark', type: '\\bsharks?\\b' },
    dog:        { fam: 'animals', hint: 'dog breed', type: '\\b(dog breed|breed of dog|dog|terrier|hound|spaniel|retriever|sheepdog|collie)\\b', where: ['\\bbreed'] },
    bird:       { fam: 'animals', hint: 'bird', type: '\\b(bird|birds|species of bird|passerine|songbird|seabird|waterfowl|raptor|parrot|owl|duck|penguin|hummingbird)\\b' },
    insect:     { fam: 'animals', hint: 'insect', type: '\\b(insect|insects|beetle|butterfly|moth|fly|bee|wasp|ant|bug|cricket|grasshopper|dragonfly|damselfly|cicada|mantis|termite|flea|louse|aphid|mayfly|stick insect|earwig|cockroach|weevil|hornet)\\b', not: '\\b(spider|scorpion|mite|tick|crustacean|arachnid)\\b' },
    dino:       { fam: 'animals', hint: 'dinosaur', type: '\\b(dinosaur|dinosaurs|genus|sauropod|theropod|ornithopod|ceratopsian|hadrosaur|ankylosaur|stegosaur)\\b', where: ['dinosaur|sauropod|theropod|ornithischian|saurischian|ornithopod|ceratopsian'] },
    marsupial:  { fam: 'animals', hint: 'marsupial', type: '\\b(marsupial|species|mammal|genus)\\b', where: ['marsupial'] },
    seacreature:{ fam: 'animals', hint: 'marine animal', type: '\\b(species|animal|fish|mammal|invertebrate|crustacean|mollusc|mollusk|cnidarian|echinoderm|whale|shark|ray|squid|octopus|jellyfish|coral|crab|eel|cetacean|pinniped)\\b', where: ['\\b(marine|sea|seas|ocean|oceans|oceanic|reef|coastal|saltwater|deep-sea|pelagic|benthic)\\b'] },
    africa:     { fam: 'geo', hint: 'country Africa', type: '\\b(country|sovereign state|nation|republic|kingdom|island country|landlocked)\\b', where: ['\\bafric'] },
    statecap:   { fam: 'usa', hint: 'state capital', type: '\\bcapital\\b', where: [US] },
    eurocap:    { fam: 'geo', hint: 'capital Europe', type: '\\bcapital\\b', where: [EUROPE] },
    mountain:   { fam: 'geo', hint: 'mountain', type: '\\b(mountain|peak|volcano|stratovolcano|massif|summit|hill|mount|mons)\\b' },
    instrument: { fam: 'music', hint: 'musical instrument', type: '\\b(musical instrument|instrument|instruments|drum|flute|guitar|lute|zither|horn|percussion|keyboard|aerophone|chordophone|idiophone|membranophone|electrophone)\\b' },
    moon:       { fam: 'science', hint: 'moon', type: '\\b(moon|moons|natural satellite|satellite)\\b' },
    language:   { fam: 'misc', hint: 'language', type: '\\b(language|languages|dialect|sign language|creole|pidgin|conlang)\\b', not: '\\bprogramming\\b' }
  };
  window.TUNGION_PROMPTS.forEach(p => Object.assign(p, R[p.id] || {}));
})();
