/* TUNGION prompt bank (~1,000 prompts).
   Every prompt is checked live against Wikipedia/Wikidata by rules:
     type  – regex the page's short description / first sentence / categories must match ("what kind of thing")
     where – regexes that must ALL appear somewhere on the page summary ("which one")
     cat   – regex matched against Wikipedia category names; a match alone is enough
     title – regex the article title must match
     not   – regex that rejects the page if found in its description / first sentence
     hint  – extra words added to a second search to find the right page faster
   Regexes are written as strings and compiled case-insensitively. */
(function () {
  'use strict';
  const out = [];
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const FAM_PACK = {
    food: 'galley', animals: 'creatures', plants: 'creatures', geo: 'atlas', usa: 'atlas',
    film: 'screen', tv: 'screen', music: 'sound', books: 'shelf', art: 'shelf', games: 'arcade',
    science: 'lab', people: 'pantheon', myth: 'pantheon', sports: 'arena', misc: 'grabbag'
  };
  let seq = 0;
  function add(fam, q, o) {
    out.push(Object.assign({ id: fam + '-' + (seq++).toString(36), fam, pack: FAM_PACK[fam], q }, o));
  }

  /* ---------------- shared type regexes ---------------- */
  const CITY = '\\b(city|cities|town|capital|municipality|commune|village|metropolis|borough|urban|settlement|port|county seat|seat of|suburb|conurbation)\\b';
  const RIVER = '\\b(river|tributary|stream|creek|waterway)\\b';
  const MOUNTAIN = '\\b(mountain|peak|volcano|stratovolcano|massif|summit|hill|mount|mountains|fell|ben)\\b';
  const ISLAND = '\\b(island|islands|atoll|islet|archipelago|isle)\\b';
  const LAKE = '\\b(lake|loch|lough|reservoir|lagoon)\\b';
  const FOOD = '\\b(dish|dishes|food|soup|stew|bread|cake|pastry|pastries|dessert|sweet|snack|dumpling|noodles?|sauce|salad|curry|confection|confectionery|beverage|drink|cuisine|porridge|pancake|sausage|cheese|condiment|biscuit|cookie|pie|rice|meal|delicacy|street food|flatbread|bun|stir.fry|casserole|sandwich|fritter|tart|pudding|jam|spread|paste|liquor|spirit|wine|beer|tea|coffee|cured|ham|fish|meat|kebab|skewer|pickle|candy|chocolate|cracker|wrap|taco|roll|omelette|grill|barbecue|roast|broth|ingredient|cookery|cooking)\\b';
  const SONG = '\\b(song|songs|single|singles|track|anthem|ballad|hymn)\\b';
  const ALBUM = '\\b(album|albums|ep|mixtape|soundtrack|record)\\b';
  const FILM = '\\b(film|films|movie|motion picture|documentary|animated feature)\\b';
  const GAME = '\\b(video game|video games|game|games)\\b';
  const TVS = '\\b(television|tv|series|sitcom|show|programme|program|miniseries|soap opera|anime|cartoon)\\b';
  const BOOK = '\\b(novel|novels|novella|book|books|story|stories|series)\\b';
  const PAINTING = '\\b(painting|paintings|portrait|fresco|mural|triptych|artwork|woodblock|print|altarpiece|canvas|panel|oil|tempera|watercolou?r|drawing|series)\\b';
  const PERSON = '\\b(born|was an?|is an?|died|\\(\\d{4})';

  /* ---------------- GEOGRAPHY: countries ---------------- */
  // [display name, where-regex, flags: c=cities r=rivers m=mountains i=islands l=lakes]
  const COUNTRIES = [
    ['Canada', '\\bcanad', 'crmil'], ['Mexico', '(?<!new )\\bmexic', 'crm'], ['Brazil', '\\bbrazil', 'cri'],
    ['Argentina', '\\bargentin', 'crml'], ['Chile', '\\bchile(an)?\\b', 'crmil'], ['Peru', '\\bperu(vian)?\\b', 'crm'],
    ['Colombia', '\\bcolombia', 'crm'], ['Venezuela', '\\bvenezuela', 'cr'], ['Cuba', '\\bcuba(n)?\\b', 'ci'],
    ['Bolivia', '\\bbolivia', 'cm'], ['Ecuador', '\\becuador', 'cm'],
    ['the United Kingdom', '\\b(united kingdom|england|english|scotland|scottish|wales|welsh|northern ireland|uk|british|britain)\\b', 'crmil'],
    ['England', '\\b(england|english)\\b', 'cri'], ['Scotland', '\\b(scotland|scottish)\\b', 'crmil'], ['Wales', '\\b(wales|welsh)\\b', 'crm'],
    ['Ireland', '\\b(ireland|irish)\\b', 'crmil'], ['France', '\\b(france|french)\\b', 'crmil'], ['Spain', '\\b(spain|spanish)\\b', 'crmi'],
    ['Portugal', '\\bportug', 'cri'], ['Italy', '\\bital(y|ian)\\b', 'crmil'], ['Germany', '\\bgerman', 'crmil'],
    ['Austria', '\\baustria', 'crml'], ['Switzerland', '\\b(switzerland|swiss)\\b', 'crml'], ['the Netherlands', '\\b(netherlands|dutch|holland)\\b', 'cri'],
    ['Belgium', '\\bbelgi', 'cr'], ['Denmark', '\\b(denmark|danish)\\b', 'ci'], ['Norway', '\\bnorw', 'crmil'], ['Sweden', '\\bswed', 'crmil'],
    ['Finland', '\\b(finland|finnish)\\b', 'crl'], ['Iceland', '\\biceland', 'm'], ['Poland', '\\b(poland|polish)\\b', 'crm'], ['the Czech Republic', '\\bczech', 'cr'],
    ['Hungary', '\\bhungar', 'cr'], ['Romania', '\\bromania', 'crm'], ['Bulgaria', '\\bbulgaria', 'cm'], ['Greece', '\\b(greece|greek)\\b', 'crmi'],
    ['Turkey', '\\b(turkey|türkiye|turkiye|turkish)\\b', 'crm'], ['Russia', '\\brussia', 'crmil'], ['Ukraine', '\\bukrain', 'cr'],
    ['Serbia', '\\bserbia', 'c'], ['Croatia', '\\bcroatia', 'ci'], ['Slovakia', '\\bslovak', 'cm'], ['Slovenia', '\\bsloven', 'm'],
    ['Egypt', '\\begypt', 'c'], ['Morocco', '\\bmorocc', 'cm'], ['Algeria', '\\balgeria', 'c'], ['Nigeria', '\\bnigeria', 'cr'],
    ['Ghana', '\\bghana', 'c'], ['Kenya', '\\bkenya', 'cm'], ['Ethiopia', '\\bethiopia', 'cm'], ['South Africa', '\\bsouth africa', 'crm'],
    ['Tanzania', '\\btanzania', 'cm'], ['Israel', '\\bisrael', 'c'], ['Saudi Arabia', '\\bsaudi', 'c'], ['Iran', '\\biran(ian)?\\b', 'crm'],
    ['Iraq', '\\biraq', 'c'], ['Pakistan', '\\bpakistan', 'crm'], ['India', '\\bindia(n)?\\b', 'crmil'], ['Bangladesh', '\\bbangladesh', 'cr'],
    ['Sri Lanka', '\\bsri lanka', 'c'], ['Nepal', '\\bnepal', 'cm'], ['China', '\\b(china|chinese)\\b', 'crmil'], ['Japan', '\\bjapan', 'crmil'],
    ['South Korea', '\\b(south korea|korea)', 'cmi'], ['Taiwan', '\\btaiwan', 'cm'], ['the Philippines', '\\bphilippin', 'cmi'],
    ['Vietnam', '\\b(vietnam|viet nam)\\b', 'cr'], ['Thailand', '\\bthai(land)?\\b', 'cri'], ['Malaysia', '\\bmalaysia', 'cmi'],
    ['Indonesia', '\\bindonesia', 'cmi'], ['Australia', '\\baustralia', 'crmil'], ['New Zealand', '\\bnew zealand', 'crmil'],
    ['Kazakhstan', '\\bkazakh', 'c'], ['Uzbekistan', '\\buzbek', 'c'], ['Syria', '\\bsyria', 'c'], ['Afghanistan', '\\bafghan', 'c']
  ];
  const plain = n => n.replace(/^the /, '');
  COUNTRIES.forEach(([name, w, f]) => {
    const bigC = ['Canada','Mexico','Brazil','the United Kingdom','England','France','Spain','Italy','Germany','Japan','China','India','Russia','Australia','the Netherlands','Poland','Turkey','South Korea','Argentina','Egypt','Greece','Portugal','Ireland','Scotland','Sweden','Norway'].includes(name);
    if (f.includes('c')) add('geo', `Name a city in ${name}`, { niche: !bigC, type: CITY, where: [w], hint: `city ${plain(name)}` });
    if (f.includes('r')) add('geo', `Name a river in ${name}`, { niche: true, type: RIVER, where: [w], hint: `river ${plain(name)}` });
    if (f.includes('m')) add('geo', `Name a mountain in ${name}`, { niche: true, type: MOUNTAIN, where: [w], hint: `mountain ${plain(name)}` });
    if (f.includes('i')) add('geo', `Name an island of ${name}`, { niche: true, type: ISLAND, where: [w], hint: `island ${plain(name)}` });
    if (f.includes('l')) add('geo', `Name a lake in ${name}`, { niche: true, type: LAKE, where: [w], hint: `lake ${plain(name)}` });
  });

  /* ---------------- GEOGRAPHY: USA ---------------- */
  const US = '\\b(united states|u\\.s\\.|us|usa|county|american|parish|borough|census|unincorporated)\\b';
  const STATES = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia',
    'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts',
    'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
    'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
    'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia',
    'Wisconsin', 'Wyoming'];
  const statePat = s => s === 'Virginia' ? '(?<!west )\\bvirginia\\b'
    : s === 'Washington' ? '\\bwashington\\b(?!,? ?d\\.? ?c)'
    : s === 'Kansas' ? '(?<!ar)\\bkansas\\b'
    : s === 'Hawaii' ? '\\bhawai.?i' : '\\b' + esc(s.toLowerCase()) + '\\b';
  STATES.forEach(s => {
    add('usa', `Name a city or town in ${s}`, { type: CITY + '|\\b(cdp|census-designated place|neighborhood|community)\\b', where: [statePat(s), US], hint: `city ${s}` });
    if (!['Louisiana', 'Alaska', 'Delaware', 'Hawaii', 'Rhode Island'].includes(s)) {
      add('usa', `Name a county in ${s}`, { niche: true, title: '\\bcounty\\b', type: '\\bcounty\\b', where: [statePat(s)], hint: `county ${s}` });
    }
  });
  add('usa', 'Name a parish in Louisiana', { type: '\\bparish\\b', where: ['\\blouisiana'], hint: 'parish Louisiana' });
  add('usa', 'Name a borough of Alaska', { type: '\\bborough|census area\\b', where: ['\\balaska'], hint: 'borough Alaska' });
  add('usa', 'Name a U.S. state', { type: '\\b(state of the united states|u\\.s\\. state|us state|state in the)\\b', hint: 'U.S. state' });
  add('usa', 'Name a U.S. national park', { type: '\\bnational park\\b', where: [US], hint: 'national park United States' });
  add('usa', 'Name a neighborhood of New York City', { type: '\\b(neighborhood|neighbourhood|area|section|district|community)\\b', where: ['\\b(new york|manhattan|brooklyn|queens|bronx|staten island)\\b'], hint: 'neighborhood New York City' });
  add('usa', 'Name a neighborhood of Los Angeles', { type: '\\b(neighborhood|neighbourhood|district|area|community)\\b', where: ['\\blos angeles'], hint: 'neighborhood Los Angeles' });
  add('usa', 'Name a neighborhood of Chicago', { type: '\\b(neighborhood|neighbourhood|community area|district|area)\\b', where: ['\\bchicago'], hint: 'neighborhood Chicago' });
  add('usa', 'Name a U.S. interstate highway', { type: '\\b(interstate|highway)\\b', hint: 'Interstate highway' });
  add('usa', 'Name an American university', { type: '\\b(university|college|institute)\\b', where: [US + '|\\b(' + STATES.map(s => s.toLowerCase()).join('|') + ')\\b'], hint: 'university United States' });

  /* ---------------- GEOGRAPHY: world features ---------------- */
  [
    ['Name a capital city', '\\bcapital\\b', 'capital city'],
    ['Name a country', '\\b(country|sovereign state|nation|kingdom|republic|island country|landlocked country|microstate|city-state)\\b', 'country', '\\b(county|song|album|film|band|province|region of|music)\\b'],
    ['Name a sea (not an ocean)', '\\b(sea|marginal sea)\\b', 'sea', '\\bocean\\b(?! basin)'],
    ['Name a desert', '\\bdesert\\b', 'desert'],
    ['Name a volcano', '\\b(volcano|stratovolcano|shield volcano|caldera|volcanic)\\b', 'volcano'],
    ['Name a waterfall', '\\b(waterfall|falls|cascade|cataract)\\b', 'waterfall'],
    ['Name a mountain range', '\\b(mountain range|range|mountains|massif|highlands|cordillera|sierra|alps)\\b', 'mountain range'],
    ['Name a river', RIVER, 'river'],
    ['Name a lake', LAKE, 'lake'],
    ['Name an island', ISLAND, 'island'],
    ['Name a strait', '\\b(strait|channel|sound|passage)\\b', 'strait'],
    ['Name a bay or gulf', '\\b(bay|gulf|bight|inlet|firth|fjord)\\b', 'bay gulf'],
    ['Name a canal', '\\bcanal\\b', 'canal'],
    ['Name a peninsula', '\\bpeninsula\\b', 'peninsula'],
    ['Name a glacier', '\\b(glacier|ice sheet|ice cap|icefield)\\b', 'glacier'],
    ['Name a cave', '\\b(cave|cavern|grotto|cave system)\\b', 'cave'],
    ['Name a canyon or gorge', '\\b(canyon|gorge|ravine|valley)\\b', 'canyon'],
    ['Name a Canadian province or territory', '\\b(province|territory)\\b', 'province Canada', null, ['\\bcanad']],
    ['Name a German state', '\\b(state|states|land|länder|bundesland)\\b', 'state of Germany', null, ['\\bgerman']],
    ['Name a region of France', '\\b(region|regions|administrative region|department)\\b', 'region of France', null, ['\\b(france|french)\\b']],
    ['Name a prefecture of Japan', '\\bprefecture\\b', 'prefecture Japan', null, ['\\bjapan']],
    ['Name a state or territory of India', '\\b(state|union territory)\\b', 'state of India', null, ['\\bindia']],
    ['Name a state of Mexico', '\\bstate\\b', 'state of Mexico', null, ['(?<!new )\\bmexic']],
    ['Name a state of Brazil', '\\bstate\\b', 'state of Brazil', null, ['\\bbrazil']],
    ['Name a Swiss canton', '\\bcanton\\b', 'canton Switzerland', null, ['\\b(switzerland|swiss)\\b']],
    ['Name a region of Italy', '\\bregion\\b', 'region of Italy', null, ['\\bital']],
    ['Name a province of China', '\\b(province|autonomous region|municipality)\\b', 'province of China', null, ['\\b(china|chinese)\\b']],
    ['Name a London borough or district', '\\b(borough|district|area|neighbourhood|town|suburb)\\b', 'district London', null, ['\\blondon']],
    ['Name a Paris landmark', '\\b(landmark|monument|museum|cathedral|church|tower|bridge|palace|square|street|avenue|park|garden|basilica|opera|arch|cemetery|building)\\b', 'Paris landmark', null, ['\\bparis']],
    ['Name a Caribbean island', ISLAND, 'Caribbean island', null, ['\\b(caribbean|antilles|west indies|bahamas)\\b']],
    ['Name a Greek island', ISLAND, 'Greek island', null, ['\\b(greece|greek)\\b']],
    ['Name a Hawaiian island', ISLAND, 'Hawaiian island', null, ['\\bhawai']],
    ['Name a Scottish island', ISLAND, 'Scottish island', null, ['\\b(scotland|scottish|hebrides|orkney|shetland)\\b']],
    ['Name a Canary or Balearic island', ISLAND, 'Canary Islands', null, ['\\b(canary|canaries|balearic)\\b']],
    ['Name a Pacific island nation', '\\b(country|nation|island country|sovereign state|state)\\b', 'Pacific island country', null, ['\\b(pacific|oceania|polynesia|micronesia|melanesia)\\b']],
    ['Name a landlocked country', '\\b(country|state|nation)\\b', 'landlocked country', null, ['\\blandlocked\\b']],
    ['Name a famous bridge', '\\bbridge\\b', 'bridge'],
    ['Name a skyscraper', '\\b(skyscraper|tower|building|high-rise|supertall)\\b', 'skyscraper'],
    ['Name a castle', '\\b(castle|fortress|palace|citadel|château|schloss|keep)\\b', 'castle'],
    ['Name a cathedral', '\\b(cathedral|basilica|minster|duomo)\\b', 'cathedral'],
    ['Name a museum', '\\b(museum|gallery|museo|musée)\\b', 'museum'],
    ['Name a World Heritage Site', '\\b(world heritage|unesco)\\b', 'World Heritage Site'],
    ['Name an airport', '\\b(airport|aerodrome|airfield)\\b', 'airport'],
    ['Name a famous street', '\\b(street|avenue|boulevard|road|lane|strip|thoroughfare)\\b', 'street'],
    ['Name a national park outside the U.S.', '\\bnational park\\b', 'national park', '\\b(united states|u\\.s\\.)\\b']
  ].forEach(([q, type, hint, not, where]) => add('geo', q, { type, hint, not: not || undefined, where: where || undefined }));

  /* ---------------- FILM ---------------- */
  const DIRECTORS = [
    ['Steven Spielberg', 'spielberg'], ['Christopher Nolan', 'nolan'], ['Martin Scorsese', 'scorsese'], ['Quentin Tarantino', 'tarantino'],
    ['Alfred Hitchcock', 'hitchcock'], ['Stanley Kubrick', 'kubrick'], ['Ridley Scott', 'ridley scott'], ['James Cameron', 'james cameron'],
    ['David Fincher', 'fincher'], ['Wes Anderson', 'wes anderson'], ['Tim Burton', 'burton'], ['Hayao Miyazaki', 'miyazaki'],
    ['Akira Kurosawa', 'kurosawa'], ['Francis Ford Coppola', 'francis ford coppola'], ['Clint Eastwood', 'eastwood'], ['Woody Allen', 'woody allen'],
    ['Spike Lee', 'spike lee'], ['the Coen brothers', 'coen'], ['Denis Villeneuve', 'villeneuve'], ['Peter Jackson', 'peter jackson'],
    ['Guillermo del Toro', 'del toro'], ['Ang Lee', 'ang lee'], ['Sofia Coppola', 'sofia coppola'], ['Greta Gerwig', 'gerwig'],
    ['Jordan Peele', 'peele'], ['Bong Joon Ho', 'bong joon'], ['Park Chan-wook', 'park chan'], ['Pedro Almodóvar', 'almod[oó]var'],
    ['Federico Fellini', 'fellini'], ['Ingmar Bergman', 'bergman'], ['Paul Thomas Anderson', 'paul thomas anderson'], ['Wes Craven', 'craven'],
    ['John Carpenter', 'carpenter'], ['George Lucas', 'lucas'], ['Robert Zemeckis', 'zemeckis'], ['Ron Howard', 'ron howard'],
    ['Steven Soderbergh', 'soderbergh'], ['Danny Boyle', 'boyle'], ['Guy Ritchie', 'ritchie'], ['Michael Bay', 'michael bay'],
    ['Zack Snyder', 'snyder'], ['Sam Raimi', 'raimi'], ['David Lynch', 'lynch'], ['Terry Gilliam', 'gilliam'], ['Oliver Stone', 'oliver stone'],
    ['Rob Reiner', 'reiner'], ['John Hughes', 'john hughes'], ['Brian De Palma', 'de palma'], ['Billy Wilder', 'wilder'], ['John Ford', 'john ford'],
    ['Sergio Leone', 'leone'], ['Werner Herzog', 'herzog'], ['Lars von Trier', 'von trier'], ['Darren Aronofsky', 'aronofsky'],
    ['Richard Linklater', 'linklater'], ['Taika Waititi', 'waititi'], ['Edgar Wright', 'edgar wright'], ['M. Night Shyamalan', 'shyamalan'],
    ['Kathryn Bigelow', 'bigelow'], ['Jane Campion', 'campion'], ['Mel Brooks', 'mel brooks'], ['Tony Scott', 'tony scott'],
    ['Baz Luhrmann', 'luhrmann'], ['Agnès Varda', 'varda'], ['Jean-Luc Godard', 'godard'], ['François Truffaut', 'truffaut'],
    ['Wong Kar-wai', 'wong kar'], ['Satyajit Ray', 'satyajit ray'], ['Yorgos Lanthimos', 'lanthimos'], ['Ari Aster', 'aster'],
    ['Chloé Zhao', 'zhao'], ['Barry Jenkins', 'barry jenkins'], ['Ryan Coogler', 'coogler'], ['James Gunn', 'gunn'],
    ['Joss Whedon', 'whedon'], ['J. J. Abrams', 'abrams'], ['Jon Favreau', 'favreau'], ['John Hughes', 'hughes'],
    ['Nora Ephron', 'ephron'], ['Penny Marshall', 'penny marshall'], ['Frank Capra', 'capra'], ['Orson Welles', 'welles'],
    ['Roman Polanski', 'polanski'], ['Andrei Tarkovsky', 'tarkovsky'], ['Luc Besson', 'besson'], ['Hirokazu Kore-eda', 'kore.?eda']
  ];
  const seenDir = new Set();
  DIRECTORS.forEach(([name, key]) => {
    if (seenDir.has(name)) return; seenDir.add(name);
    add('film', `Name a film directed by ${name}`, { cat: `^films directed by .*(${key})`, type: FILM, where: [`(directed|direction|director)[^.]{0,120}(${key})|(${key})[^.]{0,40}(film|directed)`], hint: `film ${name.replace(/^the /, '')}` });
  });
  for (let y = 1970; y <= 2025; y++) {
    add('film', `Name a movie released in ${y}`, { cat: `^${y} films$`, type: FILM, where: [`\\b${y}\\b`], hint: `${y} film` });
  }
  [
    ['Name a Pixar film', 'pixar'], ['Name a Disney animated feature', 'disney'], ['Name a Studio Ghibli film', 'ghibli'],
    ['Name a DreamWorks Animation film', 'dreamworks'], ['Name a Marvel Cinematic Universe film', 'marvel cinematic universe|\\bmcu\\b'],
    ['Name a James Bond film', 'james bond|\\bbond film|\\b007\\b'], ['Name a Star Wars film', 'star wars'], ['Name a Star Trek film', 'star trek'],
    ['Name a horror film', 'horror'], ['Name a western film', '\\bwestern\\b'], ['Name a musical film', '\\bmusical\\b'],
    ['Name a romantic comedy film', 'romantic comedy|rom-com'], ['Name a science fiction film', 'science fiction|sci-fi'],
    ['Name a film noir', 'film noir|\\bnoir\\b'], ['Name a war film', '\\bwar\\b'], ['Name a Bollywood film', 'hindi|bollywood|\\bindian\\b'],
    ['Name a Christmas film', 'christmas'], ['Name a film based on a Stephen King book', '\\bstephen king'], ['Name a Best Picture Oscar winner', 'academy award for best picture|best picture'],
    ['Name a Godzilla or kaiju film', 'godzilla|kaiju|monster film'], ['Name a zombie film', 'zombie'], ['Name a heist film', '\\bheist\\b'],
    ['Name a sports film', '\\b(sports|boxing|baseball|football|basketball|hockey|racing|surfing)\\b'], ['Name a teen film', '\\b(teen|high school|coming-of-age)\\b'],
    ['Name a silent film', '\\bsilent\\b'], ['Name a stop-motion film', 'stop.motion|claymation'], ['Name a disaster film', '\\bdisaster\\b'],
    ['Name a martial arts film', 'martial arts|kung fu|wuxia'], ['Name a superhero film', 'superhero'], ['Name a documentary film', 'documentary']
  ].forEach(([q, w]) => add('film', q, { type: FILM, where: [w], hint: q.replace(/^Name an? /, '') }));
  [['Tom Hanks'], ['Meryl Streep'], ['Leonardo DiCaprio'], ['Denzel Washington'], ['Tom Cruise'], ['Nicolas Cage'], ['Keanu Reeves'],
   ['Julia Roberts'], ['Scarlett Johansson'], ['Robin Williams'], ['Jim Carrey'], ['Harrison Ford'], ['Brad Pitt'], ['Will Smith'],
   ['Cate Blanchett'], ['Sandra Bullock'], ['Arnold Schwarzenegger'], ['Jackie Chan'], ['Audrey Hepburn'], ['Marilyn Monroe'],
   ['Humphrey Bogart'], ['Samuel L. Jackson'], ['Morgan Freeman'], ['Adam Sandler'], ['Eddie Murphy'], ['Zendaya'], ['Timothée Chalamet'],
   ['Margot Robbie'], ['Ryan Gosling'], ['Emma Stone']].forEach(([a]) => {
    const key = esc(a.split(' ').slice(-1)[0].toLowerCase()).replace('chalamet', 'chalamet');
    add('film', `Name a film starring ${a}`, { type: FILM, where: [`\\b${key}\\b`], hint: `film ${a}` });
  });

  /* ---------------- TELEVISION ---------------- */
  for (let y = 1960; y <= 2024; y++) {
    add('tv', `Name a TV series that premiered in ${y}`, { cat: `^${y} .*television series debuts$`, hint: `${y} television series` });
  }
  [
    ['Name a sitcom', '\\bsitcom|situation comedy\\b'], ['Name an HBO series', '\\bhbo\\b'], ['Name a Netflix original series', '\\bnetflix\\b'],
    ['Name a BBC series', '\\bbbc\\b'], ['Name an anime series', '\\banime\\b'], ['Name a game show', '\\bgame show|quiz show\\b'],
    ['Name a reality TV show', '\\breality\\b'], ['Name an animated TV series', '\\banimated\\b'], ['Name a soap opera', '\\bsoap opera|telenovela\\b'],
    ['Name a talk show', '\\btalk show|late-night\\b'], ['Name a crime drama series', '\\b(crime|police|detective|procedural)\\b'],
    ['Name a medical drama series', '\\b(medical|hospital|doctor)\\b'], ['Name a children\'s TV show', '\\b(children|preschool|kids)\\b'],
    ['Name a Cartoon Network show', '\\bcartoon network\\b'], ['Name a Nickelodeon show', '\\bnickelodeon\\b'], ['Name a Disney Channel show', '\\bdisney channel\\b'],
    ['Name a Star Trek series', '\\bstar trek\\b'], ['Name a sketch comedy show', '\\bsketch\\b'], ['Name a British sitcom', '\\bbritish|bbc|itv|channel 4\\b'],
    ['Name a K-drama', '\\b(south korean|korean)\\b'], ['Name a teen drama series', '\\bteen\\b'], ['Name a fantasy TV series', '\\bfantasy\\b'],
    ['Name a science fiction TV series', '\\bscience fiction|sci-fi\\b'], ['Name a cooking show', '\\b(cooking|baking|culinary|chef|food)\\b'],
    ['Name a mockumentary series', '\\bmockumentary\\b']
  ].forEach(([q, w]) => add('tv', q, { type: TVS, where: [w], hint: q.replace(/^Name an? /, '') }));
  [['The Simpsons', 'simpsons'], ['Friends', '\\bfriends\\b'], ['The Office', '\\bthe office\\b'], ['Seinfeld', 'seinfeld'], ['Breaking Bad', 'breaking bad'],
   ['Game of Thrones', 'game of thrones|a song of ice and fire'], ['Doctor Who', 'doctor who'], ['SpongeBob SquarePants', 'spongebob'],
   ['Family Guy', 'family guy'], ['South Park', 'south park'], ['Stranger Things', 'stranger things'], ['The Sopranos', 'sopranos'],
   ['Futurama', 'futurama'], ['Grey\'s Anatomy', 'grey.s anatomy'], ['Twin Peaks', 'twin peaks'], ['Lost', '\\blost\\b']]
    .forEach(([s, key]) => add('tv', `Name a character from ${s}`, { type: '\\b(character|fictional|protagonist|antagonist)\\b', where: [key], hint: `character ${s}` }));

  /* ---------------- MUSIC ---------------- */
  const ARTISTS = [
    ['Taylor Swift', 'taylor swift', 'sa'], ['the Beatles', 'beatles', 'sa'], ['Queen', 'queen', 'sa'], ['Michael Jackson', 'michael jackson', 'sa'],
    ['Madonna', 'madonna', 'sa'], ['Beyoncé', 'beyonc[eé]', 'sa'], ['Drake', '\\bdrake', 'sa'], ['Eminem', 'eminem', 'sa'], ['Rihanna', 'rihanna', 'sa'],
    ['Adele', 'adele', 's'], ['Ed Sheeran', 'sheeran', 's'], ['Elvis Presley', 'presley|\\belvis', 'sa'], ['the Rolling Stones', 'rolling stones', 'sa'],
    ['Led Zeppelin', 'led zeppelin', 'sa'], ['Pink Floyd', 'pink floyd', 'sa'], ['David Bowie', 'bowie', 'sa'], ['Prince', '\\bprince\\b', 'sa'],
    ['Elton John', 'elton john', 'sa'], ['ABBA', '\\babba\\b', 'sa'], ['Bob Dylan', 'dylan', 'sa'], ['Bruce Springsteen', 'springsteen', 'sa'],
    ['Nirvana', 'nirvana', 's'], ['Radiohead', 'radiohead', 'sa'], ['Coldplay', 'coldplay', 'sa'], ['U2', '\\bu2\\b', 'sa'], ['Oasis', '\\boasis\\b', 'sa'],
    ['Metallica', 'metallica', 'sa'], ['AC/DC', 'ac/?dc', 'sa'], ['Fleetwood Mac', 'fleetwood mac', 'sa'], ['the Beach Boys', 'beach boys', 'sa'],
    ['Stevie Wonder', 'stevie wonder', 'sa'], ['Whitney Houston', 'whitney houston', 's'], ['Mariah Carey', 'mariah carey', 'sa'],
    ['Britney Spears', 'britney spears', 'sa'], ['Lady Gaga', 'lady gaga', 'sa'], ['Katy Perry', 'katy perry', 's'], ['Justin Bieber', 'bieber', 'sa'],
    ['Bruno Mars', 'bruno mars', 's'], ['the Weeknd', 'weeknd', 'sa'], ['Kanye West', 'kanye|\\bye\\b', 'sa'], ['Kendrick Lamar', 'kendrick lamar', 'sa'],
    ['Billie Eilish', 'billie eilish', 's'], ['Ariana Grande', 'ariana grande', 'sa'], ['Dua Lipa', 'dua lipa', 's'], ['Harry Styles', 'harry styles', 's'],
    ['One Direction', 'one direction', 's'], ['Olivia Rodrigo', 'olivia rodrigo', 's'], ['Sabrina Carpenter', 'sabrina carpenter', 's'],
    ['Bad Bunny', 'bad bunny', 's'], ['Shakira', 'shakira', 'sa'], ['Johnny Cash', 'johnny cash', 'sa'], ['Dolly Parton', 'dolly parton', 'sa'],
    ['Frank Sinatra', 'sinatra', 'sa'], ['Aretha Franklin', 'aretha franklin', 's'], ['Marvin Gaye', 'marvin gaye', 's'], ['the Bee Gees', 'bee gees', 's'],
    ['the Who', '\\bthe who\\b', 'sa'], ['the Kinks', 'kinks', 's'], ['the Doors', '\\bthe doors\\b', 'sa'], ['Jimi Hendrix', 'hendrix', 's'],
    ['Red Hot Chili Peppers', 'red hot chili peppers', 'sa'], ['Green Day', 'green day', 'sa'], ['Foo Fighters', 'foo fighters', 's'],
    ['Pearl Jam', 'pearl jam', 's'], ['Linkin Park', 'linkin park', 's'], ['Guns N\' Roses', 'guns n.? roses', 's'], ['Bon Jovi', 'bon jovi', 's'],
    ['Aerosmith', 'aerosmith', 's'], ['Kiss', '\\bkiss\\b', 's'], ['Daft Punk', 'daft punk', 'sa'], ['Arctic Monkeys', 'arctic monkeys', 'sa'],
    ['the Killers', '\\bthe killers\\b', 's'], ['Blur', '\\bblur\\b', 's'], ['the Smiths', '\\bthe smiths\\b', 's'], ['the Cure', '\\bthe cure\\b', 's'],
    ['Depeche Mode', 'depeche mode', 's'], ['Talking Heads', 'talking heads', 's'], ['R.E.M.', 'r\\.?e\\.?m\\.?', 's'], ['Paul McCartney', 'mccartney', 's'],
    ['John Lennon', 'lennon', 's'], ['Billy Joel', 'billy joel', 's'], ['Cher', '\\bcher\\b', 's'], ['Tina Turner', 'tina turner', 's'],
    ['Janet Jackson', 'janet jackson', 's'], ['Celine Dion', 'c[eé]line dion', 's'], ['Shania Twain', 'shania twain', 's'], ['Garth Brooks', 'garth brooks', 's'],
    ['Lana Del Rey', 'lana del rey', 'sa'], ['SZA', '\\bsza\\b', 's'], ['Post Malone', 'post malone', 's'], ['Travis Scott', 'travis scott', 's'],
    ['Nicki Minaj', 'nicki minaj', 's'], ['Jay-Z', 'jay.?z', 'sa'], ['OutKast', 'outkast', 's'], ['Kylie Minogue', 'kylie minogue', 's'],
    ['the Spice Girls', 'spice girls', 's'], ['the Backstreet Boys', 'backstreet boys', 's'], ['NSYNC', 'n?sync', 's'], ['BTS', '\\bbts\\b', 's'],
    ['Blackpink', 'blackpink', 's'], ['Chappell Roan', 'chappell roan', 's'], ['Lorde', '\\blorde\\b', 's'], ['Gorillaz', 'gorillaz', 'sa'],
    ['Muse', '\\bmuse\\b', 's'], ['Kate Bush', 'kate bush', 's'], ['Joni Mitchell', 'joni mitchell', 'sa'], ['Neil Young', 'neil young', 'sa'],
    ['Simon & Garfunkel', 'simon (&|and) garfunkel', 's'], ['Tom Petty', 'tom petty', 's'], ['Bob Marley', 'marley', 'sa'], ['Lil Wayne', 'lil wayne', 's'],
    ['2Pac', '2pac|tupac', 's'], ['the Notorious B.I.G.', 'notorious b\\.?i\\.?g|biggie', 's'], ['Snoop Dogg', 'snoop', 's'], ['Missy Elliott', 'missy elliott', 's'],
    ['Usher', '\\busher\\b', 's'], ['Alicia Keys', 'alicia keys', 's'], ['Frank Ocean', 'frank ocean', 'sa'], ['Tyler, the Creator', 'tyler, the creator', 'sa'],
    ['Phoebe Bridgers', 'phoebe bridgers', 's'], ['Mitski', 'mitski', 's'], ['Hozier', 'hozier', 's'], ['Imagine Dragons', 'imagine dragons', 's'],
    ['Maroon 5', 'maroon 5', 's'], ['Pink', '\\bp!?nk\\b|\\bpink\\b', 's'], ['Avril Lavigne', 'avril lavigne', 's'], ['Gwen Stefani', 'stefani|no doubt', 's'],
    ['the Police', '\\bthe police\\b', 's'], ['Sting', '\\bsting\\b', 's'], ['Genesis', '\\bgenesis\\b', 's'], ['Phil Collins', 'phil collins', 's'],
    ['the Eagles', '\\beagles\\b', 's'], ['Creedence Clearwater Revival', 'creedence', 's'], ['the Clash', '\\bthe clash\\b', 's'], ['Ramones', 'ramones', 's'],
    ['Black Sabbath', 'black sabbath', 'sa'], ['Iron Maiden', 'iron maiden', 'sa'], ['Rush', '\\brush\\b', 'a'], ['Steely Dan', 'steely dan', 'a'],
    ['Miles Davis', 'miles davis', 'a'], ['John Coltrane', 'coltrane', 'a'], ['Kraftwerk', 'kraftwerk', 'a'], ['Björk', 'bj[oö]rk', 'sa'],
    ['Portishead', 'portishead', 'a'], ['Massive Attack', 'massive attack', 'a'], ['Tame Impala', 'tame impala', 'sa'], ['Vampire Weekend', 'vampire weekend', 'a'],
    ['the National', '\\bthe national\\b', 'a'], ['Sufjan Stevens', 'sufjan', 'a'], ['Bon Iver', 'bon iver', 'a'], ['Fiona Apple', 'fiona apple', 'a']
  ];
  ARTISTS.forEach(([name, key, f]) => {
    if (f.includes('s')) add('music', `Name a song by ${name}`, { cat: `^(the )?(${key}) songs$`, type: SONG, where: [key], not: '\\balbum\\b(?! by)', hint: `song ${name}` });
    if (f.includes('a')) add('music', `Name an album by ${name}`, { cat: `^(the )?(${key}) albums$`, type: ALBUM, where: [key], hint: `album ${name}` });
  });
  [
    ['Name a music genre', '\\b(genre|subgenre|style of music|music style|musical style|form of music|fusion genre)\\b'],
    ['Name a heavy metal band', '\\b(heavy metal|metal band|thrash metal|death metal|black metal|doom metal|nu metal|power metal|metalcore)\\b'],
    ['Name a punk band', '\\bpunk\\b'], ['Name a boy band', '\\bboy band\\b'], ['Name a girl group', '\\bgirl group\\b'],
    ['Name a K-pop group', '\\b(k-pop|south korean (boy|girl) group)\\b'], ['Name a jazz musician', '\\bjazz\\b'],
    ['Name a rapper', '\\b(rapper|hip hop|hip-hop|mc)\\b'], ['Name a country singer', '\\bcountry\\b'], ['Name an opera', '\\bopera\\b'],
    ['Name a ballet', '\\bballet\\b'], ['Name a Broadway musical', '\\bmusical\\b'], ['Name a symphony', '\\bsymphony\\b'],
    ['Name a Christmas song', '\\bchristmas\\b'], ['Name a national anthem', '\\bnational anthem\\b'], ['Name a DJ', '\\b(dj|disc jockey|record producer)\\b'],
    ['Name a music festival', '\\bfestival\\b'], ['Name a record label', '\\brecord label|label\\b'], ['Name a grunge band', '\\bgrunge\\b'],
    ['Name a disco song', '\\bdisco\\b'], ['Name a one-hit wonder', '\\b(song|single)\\b']
  ].forEach(([q, t]) => add('music', q, { type: t, hint: q.replace(/^Name an? /, '') }));
  [['Name a classical composer', '\\bcomposer\\b', 'composer'], ['Name a Baroque composer', '\\bcomposer\\b', 'composer baroque', '\\bbaroque\\b'],
   ['Name a guitarist', '\\bguitarist\\b', 'guitarist'], ['Name a drummer', '\\bdrummer\\b', 'drummer'], ['Name a pianist', '\\bpianist\\b', 'pianist'],
   ['Name a violinist', '\\bviolinist\\b', 'violinist'], ['Name an opera singer', '\\b(soprano|tenor|baritone|bass|mezzo|contralto|opera singer|operatic)\\b', 'opera singer']]
    .forEach(([q, t, h, w]) => add('music', q, { type: t, hint: h, where: w ? [w] : undefined }));

  /* ---------------- BOOKS ---------------- */
  const AUTHORS = [
    ['Stephen King', 'stephen king'], ['Agatha Christie', 'christie'], ['Charles Dickens', 'dickens'], ['Jane Austen', 'austen'],
    ['Ernest Hemingway', 'hemingway'], ['F. Scott Fitzgerald', 'fitzgerald'], ['Mark Twain', 'twain'], ['George Orwell', 'orwell'],
    ['Leo Tolstoy', 'tolstoy'], ['Fyodor Dostoevsky', 'dostoevsky|dostoyevsky'], ['Virginia Woolf', 'woolf'], ['Toni Morrison', 'morrison'],
    ['Kurt Vonnegut', 'vonnegut'], ['Haruki Murakami', 'murakami'], ['Terry Pratchett', 'pratchett'], ['Neil Gaiman', 'gaiman'],
    ['John Steinbeck', 'steinbeck'], ['William Faulkner', 'faulkner'], ['Thomas Hardy', 'hardy'], ['Jules Verne', 'verne'],
    ['H. G. Wells', 'wells'], ['Michael Crichton', 'crichton'], ['Dan Brown', 'dan brown'], ['John Grisham', 'grisham'],
    ['Cormac McCarthy', 'mccarthy'], ['Margaret Atwood', 'atwood'], ['Ian McEwan', 'mcewan'], ['Kazuo Ishiguro', 'ishiguro'],
    ['Salman Rushdie', 'rushdie'], ['Gabriel García Márquez', 'garc[ií]a m[aá]rquez'], ['Isabel Allende', 'allende'], ['Philip K. Dick', 'philip k\\.? dick'],
    ['Isaac Asimov', 'asimov'], ['Ray Bradbury', 'bradbury'], ['Ursula K. Le Guin', 'le guin'], ['Arthur C. Clarke', 'clarke'],
    ['Roald Dahl', '\\bdahl\\b'], ['Victor Hugo', 'victor hugo'], ['Alexandre Dumas', 'dumas'], ['Herman Melville', 'melville'],
    ['Nathaniel Hawthorne', 'hawthorne'], ['Edith Wharton', 'wharton'], ['Henry James', 'henry james'], ['Graham Greene', 'graham greene'],
    ['Evelyn Waugh', 'waugh'], ['Brandon Sanderson', 'sanderson'], ['Rick Riordan', 'riordan'], ['Judy Blume', 'blume'],
    ['James Patterson', 'patterson'], ['Ken Follett', 'follett'], ['Anne Rice', 'anne rice'], ['Philip Roth', '\\broth\\b'],
    ['Don DeLillo', 'delillo'], ['Thomas Pynchon', 'pynchon'], ['Zadie Smith', 'zadie smith'], ['Sally Rooney', 'rooney'],
    ['Colleen Hoover', 'colleen hoover'], ['J. R. R. Tolkien', 'tolkien'], ['C. S. Lewis', 'c\\.? ?s\\.? lewis'], ['Charlotte Brontë', 'bront[eë]'],
    ['Emily Brontë', 'bront[eë]'], ['Oscar Wilde', 'wilde'], ['Franz Kafka', 'kafka'], ['Vladimir Nabokov', 'nabokov'], ['Jack London', 'jack london'],
    ['Robert Louis Stevenson', 'stevenson'], ['Arthur Conan Doyle', 'conan doyle'], ['Ian Fleming', 'fleming'], ['John le Carré', 'le carr[eé]'],
    ['Douglas Adams', 'douglas adams'], ['Frank Herbert', 'frank herbert'], ['George R. R. Martin', 'george r\\.? ?r\\.? martin'], ['Suzanne Collins', 'suzanne collins'],
    ['Chinua Achebe', 'achebe'], ['Umberto Eco', 'umberto eco'], ['Italo Calvino', 'calvino'], ['Albert Camus', 'camus']
  ];
  const seenAuth = new Set();
  AUTHORS.forEach(([name, key]) => {
    if (seenAuth.has(name)) return; seenAuth.add(name);
    add('books', `Name a book by ${name}`, { cat: `^(novels|books|works|short story collections|plays) by .*(${key})`, type: BOOK + '|\\b(play|poem|collection|essay|memoir)\\b', where: [key], hint: `novel ${name}` });
  });
  [
    ['Name a Shakespeare play', '\\b(play|tragedy|comedy|history)\\b', 'shakespeare'],
    ['Name a Shakespeare character', '\\b(character|protagonist|antagonist|fictional|title character)\\b', 'shakespeare'],
    ['Name a Harry Potter character', '\\b(character|fictional|protagonist|antagonist)\\b', 'harry potter|hogwarts|rowling'],
    ['Name a Lord of the Rings character', '\\b(character|fictional|protagonist|hobbit|wizard|elf|dwarf|king)\\b', 'tolkien|middle-earth|lord of the rings'],
    ['Name a Sherlock Holmes story', '\\b(story|short story|novel|novella|collection)\\b', 'sherlock holmes|conan doyle'],
    ['Name a fairy tale', '\\b(fairy tale|folk tale|folktale|fable|story)\\b', '.'],
    ['Name a comic strip', '\\bcomic strip\\b', '.'],
    ['Name a manga series', '\\bmanga\\b', '.'],
    ['Name a graphic novel', '\\b(graphic novel|comic book|comics)\\b', '.'],
    ['Name a Greek epic or tragedy', '\\b(epic|tragedy|play|poem)\\b', 'greek|homer|sophocles|euripides|aeschylus'],
    ['Name a dystopian novel', '\\bnovel\\b', 'dystopia'],
    ['Name a fantasy novel', '\\bnovel\\b', 'fantasy'],
    ['Name a science fiction novel', '\\bnovel\\b', 'science fiction|sci-fi'],
    ['Name a children\'s book', '\\b(book|novel|picture book|story)\\b', "children|picture book|young readers"],
    ['Name a poem', '\\bpoem|poetry|sonnet|ode|elegy\\b', '.'],
    ['Name a newspaper', '\\b(newspaper|daily|tabloid)\\b', '.'],
    ['Name a magazine', '\\b(magazine|periodical|journal)\\b', '.'],
    ['Name a poet', '\\bpoet\\b', '.'],
    ['Name a playwright', '\\b(playwright|dramatist)\\b', '.'],
    ['Name a literary detective', '\\b(detective|investigator|sleuth|inspector)\\b', 'fictional|character']
  ].forEach(([q, t, w]) => add('books', q, { type: t, where: [w], hint: q.replace(/^Name an? /, '') }));

  /* ---------------- ART ---------------- */
  const PAINTERS = [
    ['Vincent van Gogh', 'van gogh'], ['Pablo Picasso', 'picasso'], ['Claude Monet', 'monet'], ['Leonardo da Vinci', 'leonardo'],
    ['Rembrandt', 'rembrandt'], ['Johannes Vermeer', 'vermeer'], ['Salvador Dalí', 'dal[ií]'], ['Frida Kahlo', 'kahlo'], ['Edvard Munch', 'munch'],
    ['Gustav Klimt', 'klimt'], ['Michelangelo', 'michelangelo'], ['Caravaggio', 'caravaggio'], ['Raphael', 'raphael'], ['Sandro Botticelli', 'botticelli'],
    ['Edward Hopper', 'hopper'], ['Andy Warhol', 'warhol'], ['Georgia O\'Keeffe', "o.keeffe"], ['J. M. W. Turner', 'turner'], ['Diego Velázquez', 'vel[aá]zquez'],
    ['Francisco Goya', 'goya'], ['Pierre-Auguste Renoir', 'renoir'], ['Édouard Manet', 'manet'], ['Paul Cézanne', 'c[eé]zanne'], ['Henri Matisse', 'matisse'],
    ['René Magritte', 'magritte'], ['Hieronymus Bosch', 'bosch'], ['Pieter Bruegel the Elder', 'bruegel|brueghel'], ['Katsushika Hokusai', 'hokusai'],
    ['Edgar Degas', 'degas'], ['Paul Gauguin', 'gauguin'], ['Jan van Eyck', 'van eyck'], ['Titian', 'titian'], ['Peter Paul Rubens', 'rubens'],
    ['Joan Miró', 'mir[oó]'], ['Wassily Kandinsky', 'kandinsky'], ['Piet Mondrian', 'mondrian'], ['Roy Lichtenstein', 'lichtenstein'], ['Grant Wood', 'grant wood']
  ];
  const BIG_ART = ['Vincent van Gogh', 'Pablo Picasso', 'Claude Monet', 'Leonardo da Vinci', 'Rembrandt', 'Salvador Dalí', 'Michelangelo', 'Andy Warhol', 'Frida Kahlo'];
  PAINTERS.forEach(([name, key]) => add('art', `Name an artwork by ${name}`, { niche: !BIG_ART.includes(name), cat: `^(paintings|works|sculptures|drawings|frescos|prints) by .*(${key})`, type: PAINTING + '|\\b(sculpture|statue|fresco|ceiling|drawing|print)\\b', where: [key], hint: `painting ${name}` }));
  [
    ['Name an art movement', '\\b(art movement|movement|style|school)\\b', 'art|painting|artistic'],
    ['Name an architectural style', '\\b(architectural style|style of architecture|architecture|style)\\b', 'architect'],
    ['Name a famous sculpture', '\\b(sculpture|statue|bust|relief|monument)\\b', '.'],
    ['Name a painter', '\\bpainter\\b', '.'], ['Name a sculptor', '\\bsculptor\\b', '.'], ['Name an architect', '\\barchitect\\b', '.'],
    ['Name a photographer', '\\bphotographer\\b', '.'], ['Name a fashion designer', '\\b(fashion designer|couturier|designer)\\b', 'fashion|couture|clothing'],
    ['Name a fashion brand', '\\b(fashion|luxury|clothing|apparel|fashion house|brand)\\b', '.'], ['Name a typeface', '\\b(typeface|font)\\b', '.'],
    ['Name an impressionist painter', '\\bpainter\\b', 'impressionis'], ['Name a Renaissance artist', '\\b(painter|sculptor|artist|architect)\\b', 'renaissance'],
    ['Name a surrealist artist', '\\b(painter|artist|sculptor|photographer)\\b', 'surreal'], ['Name a pop artist', '\\b(artist|painter|printmaker)\\b', 'pop art'],
    ['Name a street artist', '\\b(artist|graffiti)\\b', 'street art|graffiti|mural'], ['Name a cartoonist', '\\b(cartoonist|comics artist|illustrator|animator)\\b', '.']
  ].forEach(([q, t, w]) => add('art', q, { type: t, where: [w], hint: q.replace(/^Name an? /, '') }));

  /* ---------------- GAMES ---------------- */
  for (let y = 1980; y <= 2025; y++) add('games', `Name a video game released in ${y}`, { cat: `^${y} video games$`, type: '\\bvideo game\\b', where: [`\\b${y}\\b`], hint: `${y} video game` });
  [['Mario', 'mario'], ['The Legend of Zelda', 'zelda'], ['Pokémon', 'pok[eé]mon'], ['Sonic the Hedgehog', 'sonic'], ['Final Fantasy', 'final fantasy'],
   ['Call of Duty', 'call of duty'], ['Grand Theft Auto', 'grand theft auto|\\bgta\\b'], ['Assassin\'s Creed', 'assassin.s creed'], ['Halo', '\\bhalo\\b'],
   ['Metroid', 'metroid'], ['Kirby', 'kirby'], ['Mega Man', 'mega man'], ['Castlevania', 'castlevania'], ['Resident Evil', 'resident evil'],
   ['Street Fighter', 'street fighter'], ['Mortal Kombat', 'mortal kombat'], ['Donkey Kong', 'donkey kong'], ['Star Wars', 'star wars'],
   ['The Elder Scrolls', 'elder scrolls'], ['Fallout', 'fallout'], ['Tomb Raider', 'tomb raider'], ['Metal Gear', 'metal gear'],
   ['Dragon Quest', 'dragon quest'], ['Kingdom Hearts', 'kingdom hearts'], ['Persona', 'persona'], ['Need for Speed', 'need for speed'],
   ['Crash Bandicoot', 'crash bandicoot'], ['Spyro', 'spyro'], ['Lego', '\\blego\\b'], ['Batman', 'batman'], ['Tetris', 'tetris'],
   ['Fire Emblem', 'fire emblem'], ['Silent Hill', 'silent hill'], ['Battlefield', 'battlefield'], ['The Sims', '\\bthe sims|\\bsims\\b'],
   ['Pac-Man', 'pac-?man'], ['Mario Kart', 'mario kart'], ['Animal Crossing', 'animal crossing'], ['Dark Souls or Souls-like', 'souls|fromsoftware'],
   ['Monster Hunter', 'monster hunter'], ['Yakuza', 'yakuza|like a dragon'], ['Far Cry', 'far cry'], ['Madden NFL', 'madden'], ['FIFA', '\\bfifa\\b|ea sports fc']]
    .forEach(([name, key]) => add('games', `Name a ${name} video game`, { type: GAME, where: [key], hint: `${name} video game` }));
  [
    ['Name a video game console', '\\b(video game console|home console|handheld|game console|console)\\b'],
    ['Name a video game character', '\\b(character|protagonist|antagonist|mascot|fictional)\\b'],
    ['Name a video game developer', '\\b(video game developer|developer|game studio|studio)\\b'],
    ['Name a board game', '\\bboard game\\b'], ['Name a card game', '\\bcard game\\b'], ['Name a tabletop role-playing game', '\\b(role-playing game|rpg|tabletop)\\b'],
    ['Name a puzzle video game', '\\bpuzzle\\b'], ['Name a fighting game', '\\bfighting game\\b'], ['Name a racing game', '\\bracing\\b'],
    ['Name a first-person shooter', '\\b(first-person shooter|fps)\\b'], ['Name a platform game', '\\bplatform\\b'], ['Name an arcade game', '\\barcade\\b'],
    ['Name a role-playing video game', '\\b(role-playing|rpg)\\b'], ['Name a strategy video game', '\\bstrategy\\b'], ['Name a horror video game', '\\bhorror\\b'],
    ['Name an indie game', '\\b(indie|independent)\\b'], ['Name a mobile game', '\\b(mobile|ios|android|smartphone)\\b'], ['Name a sandbox game', '\\b(sandbox|open world|open-world)\\b'],
    ['Name a dice game', '\\bdice\\b'], ['Name a chess opening', '\\b(opening|defence|defense|gambit|attack|variation|game)\\b'],
    ['Name a party game', '\\bparty\\b'], ['Name a Nintendo character', '\\b(character|mascot|protagonist|antagonist|fictional)\\b'],
    ['Name a playground game', '\\b(game|children.s game|playground)\\b'],
    ['Name a solitaire game', '\\b(solitaire|patience)\\b']
  ].forEach(([q, t]) => {
    const w = q.includes('chess') ? ['\\bchess\\b'] : q.includes('Nintendo') ? ['nintendo|mario|zelda|kirby|metroid|pok[eé]mon|donkey kong|star fox'] : q.includes('Pokémon') ? ['pok[eé]mon'] : undefined;
    add('games', q, { type: t, where: w, hint: q.replace(/^Name an? /, '') });
  });

  /* ---------------- FOOD ---------------- */
  const CUISINES = [
    ['Japanese', '\\bjapan'], ['Chinese', '\\b(china|chinese|cantonese|sichuan|szechuan|hunan|shanghai|fujian|taiwan)'], ['Korean', '\\bkorea'],
    ['Thai', '\\bthai(land)?\\b'], ['Vietnamese', '\\b(vietnam|viet)'], ['Indian', '\\b(india|indian|punjab|bengal|kerala|gujarat|tamil|hyderabad|goa|mughlai|south asia)'],
    ['Pakistani', '\\bpakistan'], ['Filipino', '\\b(philippin|filipino)'], ['Indonesian', '\\b(indonesia|java|bali|sumatra|padang)'], ['Malaysian', '\\b(malaysia|malay)'],
    ['Mexican', '(?<!new )\\bmexic'], ['Peruvian', '\\bperu(vian)?\\b'], ['Brazilian', '\\bbrazil'], ['Argentine', '\\bargentin'], ['Cuban', '\\bcuba(n)?\\b'],
    ['Jamaican', '\\bjamaica'], ['Italian', '\\b(italy|italian|sicil|naples|neapolitan|roman|tuscan|milan|venetian|lombard|ligurian|sardinian|bolognese)'],
    ['French', '\\b(france|french|provence|proven[cç]al|normandy|breton|lyon|alsace|burgundy|parisian)'], ['Spanish', '\\b(spain|spanish|catalan|basque|andalusian|valencia|galician)'],
    ['Portuguese', '\\bportug'], ['Greek', '\\b(greece|greek)\\b'], ['Turkish', '\\b(turkey|turkish|ottoman|türkiye)\\b'], ['Lebanese', '\\b(leban|levant)'],
    ['Israeli', '\\b(israel|jewish)'], ['Persian', '\\b(iran|persian)'], ['Moroccan', '\\b(morocc|maghreb)'], ['Ethiopian', '\\b(ethiopia|eritrea)'],
    ['Nigerian', '\\b(nigeria|west africa)'], ['South African', '\\bsouth africa'], ['German', '\\b(german|bavaria|swabia)'], ['Austrian', '\\b(austria|vienn)'],
    ['Swiss', '\\b(swiss|switzerland)\\b'], ['Belgian', '\\bbelgi'], ['Dutch', '\\b(dutch|netherlands|holland)\\b'],
    ['British', '\\b(brit|england|english|scotland|scottish|wales|welsh|cornish|yorkshire)'], ['Irish', '\\b(ireland|irish)\\b'],
    ['Swedish', '\\bswed'], ['Danish', '\\b(danish|denmark)\\b'], ['Norwegian', '\\bnorw'], ['Finnish', '\\b(finland|finnish)\\b'],
    ['Polish', '\\b(poland|polish)\\b'], ['Russian', '\\brussia'], ['Ukrainian', '\\bukrain'], ['Hungarian', '\\bhungar'], ['Georgian', '\\bgeorgia'],
    ['Hawaiian', '\\bhawai'], ['Cajun or Creole', '\\b(cajun|creole|louisiana|new orleans)'], ['Tex-Mex', '\\b(tex-mex|texas|southwestern)'],
    ['Southern U.S.', '\\b(southern united states|american south|soul food|southern)'], ['Caribbean', '\\b(caribbean|trinidad|barbad|haiti|puerto ric|dominican|jamaica)'],
    ['Middle Eastern', '\\b(middle east|levant|arab|persian|turkish|lebanese|israeli|syrian|egyptian|iraqi)'], ['Scandinavian', '\\b(scandinavia|nordic|swed|norw|danish|denmark|finland|iceland)'],
    ['Sri Lankan', '\\bsri lanka'], ['Singaporean', '\\bsingapore'], ['Egyptian', '\\begypt'], ['Afghan', '\\bafghan'], ['Chilean', '\\bchile(an)?\\b'],
    ['Colombian', '\\bcolombia'], ['Venezuelan', '\\bvenezuela'], ['Canadian', '\\b(canad|quebec|québec)'], ['Australian', '\\baustralia'], ['Czech', '\\bczech']
  ];
  CUISINES.forEach(([d, w]) => add('food', `Name a ${d} dish`, { type: FOOD, where: [w], hint: `${d} dish`, not: '\\b(restaurant|chef|company|cookbook|television)\\b' }));
  [['French', '\\b(france|french)\\b'], ['Italian', '\\bital'], ['Swiss', '\\b(swiss|switzerland)\\b'], ['Dutch', '\\b(dutch|netherlands)\\b'],
   ['Spanish', '\\b(spain|spanish)\\b'], ['English', '\\b(england|english|british)\\b'], ['Greek', '\\b(greece|greek)\\b'], ['Mexican', '\\bmexic'],
   ['German', '\\bgerman'], ['American', '\\b(american|united states|wisconsin|vermont|california)\\b']]
    .forEach(([d, w]) => add('food', `Name a ${d} cheese`, { type: '\\bcheeses?\\b', where: [w], hint: `${d} cheese` }));
  [
    ['Name a vegetable', '\\b(vegetable|vegetables|root|tuber|leaf vegetable|legume|squash|brassica|allium|cultivar|cabbage|bean|gourd)\\b'],
    ['Name a type of bread', '\\b(bread|flatbread|loaf|roll|bun|baguette|brioche|bagel|sourdough|rye)\\b'],
    ['Name a dessert', '\\b(dessert|cake|pudding|pastry|pie|tart|sweet|ice cream|custard|confection|cookie|biscuit|mousse|souffl[eé]|gelato|sorbet)\\b'],
    ['Name a cake', '\\b(cake|gâteau|gateau|torte|sponge)\\b'], ['Name a cookie or biscuit', '\\b(cookie|cookies|biscuit|biscuits|biscotti|wafer|shortbread|macaron)\\b'],
    ['Name a candy or chocolate bar', '\\b(candy|confectionery|chocolate|sweet|lollipop|toffee|gum|bar|mint|licorice|liquorice|gummy)\\b'],
    ['Name a sauce', '\\b(sauce|condiment|dressing|salsa|gravy|dip|relish|pesto|chutney|paste)\\b'],
    ['Name a nut or seed you can eat', '\\b(nut|nuts|seed|seeds|kernel|legume)\\b'],
    ['Name an edible mushroom', '\\b(mushroom|fungus|fungi|bolete|truffle|mycelium)\\b'],
    ['Name a beer style', '\\b(beer|ale|lager|stout|porter|pilsner|bock|ipa|saison|lambic|weissbier|witbier|kölsch|kolsch)\\b'],
    ['Name a wine grape variety', '\\b(grape|grape variety|wine grape|cultivar|varietal|vitis)\\b'],
    ['Name a liqueur or spirit', '\\b(liqueur|spirit|liquor|brandy|whisky|whiskey|rum|gin|vodka|tequila|mezcal|schnapps|aperitif|digestif|bitters|absinthe|baijiu|soju|grappa|amaro)\\b'],
    ['Name a sausage', '\\b(sausage|wurst|salami|chorizo|frankfurter|hot dog|bratwurst|kielbasa|boudin|pudding)\\b'],
    ['Name a pastry', '\\b(pastry|pastries|croissant|danish|strudel|tart|puff|choux|éclair|eclair|turnover|viennoiserie|baklava)\\b'],
    ['Name a dumpling', '\\b(dumpling|dumplings|gyoza|pierogi|ravioli|wonton|bao|momo|mandu|jiaozi|pelmeni|empanada|samosa)\\b'],
    ['Name a noodle dish', '\\b(noodle|noodles|ramen|udon|soba|pho|pasta|lo mein|chow mein|pad thai|laksa)\\b'],
    ['Name a sandwich', '\\b(sandwich|sub|hoagie|panini|burger|wrap|toastie|sando|bánh mì|banh mi|roll)\\b'],
    ['Name a salad', '\\bsalad\\b'], ['Name a potato dish', '\\bpotato'], ['Name a rice dish', '\\brice\\b'], ['Name an egg dish', '\\begg'],
    ['Name a pancake or flatbread', '\\b(pancake|crêpe|crepe|flatbread|tortilla|waffle|blini|dosa|injera|roti|naan|pita|lavash|chapati|galette)\\b'],
    ['Name a chili pepper', '\\b(chili|chile|chilli|pepper|capsicum)\\b'], ['Name an apple variety', '\\b(apple|cultivar)\\b'],
    ['Name a type of tea', '\\btea\\b'], ['Name a coffee drink', '\\b(coffee|espresso)\\b'], ['Name a soft drink', '\\b(soft drink|soda|cola|carbonated|pop|beverage|drink|lemonade|ginger ale|root beer)\\b'],
    ['Name a fast food chain', '\\b(fast food|fast-food|restaurant chain|chain|restaurant|franchise)\\b'], ['Name a snack food', '\\b(snack|chips|crisps|crackers|pretzel|popcorn|puffs)\\b'],
    ['Name a condiment', '\\b(condiment|sauce|relish|mustard|ketchup|mayonnaise|dressing|pickle|chutney|spread|vinegar)\\b'],
    ['Name a cut of beef', '\\b(beef|steak|cut|primal|brisket|loin|rib|chuck|sirloin)\\b'], ['Name a seafood dish', '\\b(seafood|fish|shellfish|shrimp|prawn|crab|lobster|oyster|clam|mussel|squid|octopus|scallop)\\b'],
    ['Name a breakfast food', '\\b(breakfast|brunch)\\b'], ['Name a street food', '\\b(street food|snack|fast food|food stall|vendor)\\b'],
    ['Name a type of sushi', '\\b(sushi|maki|nigiri|sashimi|temaki|uramaki|chirashi|inari|gunkan|roll)\\b'], ['Name an ice cream flavor or brand', '\\b(ice cream|gelato|frozen dessert|sorbet|flavou?r)\\b'],
    ['Name a cooking technique', '\\b(cooking|technique|method|culinary|cookery)\\b'], ['Name a kitchen utensil or tool', '\\b(utensil|kitchen|tool|cookware|knife|pan|pot|implement)\\b'],
    ['Name a spirit-forward drink', '\\b(cocktail|drink|spirit|liqueur|whisky|whiskey|gin|rum|vodka|brandy|tequila)\\b'], ['Name a cocktail made with gin', '\\bcocktail|drink\\b', '\\bgin\\b'],
    ['Name a cocktail made with rum', '\\bcocktail|drink\\b', '\\brum\\b'], ['Name a cocktail made with whiskey', '\\bcocktail|drink\\b', '\\b(whisk(e)?y|bourbon|rye|scotch)\\b'],
    ['Name a cocktail made with tequila', '\\bcocktail|drink\\b', '\\b(tequila|mezcal)\\b'], ['Name a cocktail made with vodka', '\\bcocktail|drink\\b', '\\bvodka\\b'],
    ['Name a berry', '\\b(berry|berries|fruit)\\b'], ['Name a citrus fruit', '\\b(citrus|fruit|orange|lemon|lime|mandarin)\\b', '\\bcitrus|orange|lemon|lime|mandarin|grapefruit|pomelo|yuzu|kumquat|tangerine'],
    ['Name a tropical fruit', '\\b(fruit|tree|plant|species)\\b', '\\btropic'], ['Name a legume', '\\b(legume|bean|pea|lentil|pulse|fabaceae|chickpea)\\b'],
    ['Name a type of rice', '\\brice\\b'], ['Name a grain or cereal crop', '\\b(grain|cereal|crop|wheat|barley|millet|oat|rye|sorghum|grass|pseudocereal)\\b'],
    ['Name a type of onion or allium', '\\b(allium|onion|garlic|leek|shallot|chive|scallion|ramp)\\b'], ['Name a squash or gourd', '\\b(squash|gourd|pumpkin|melon|cucurbit|zucchini)\\b'],
    ['Name a leafy green', '\\b(leaf|leafy|lettuce|green|greens|cabbage|chard|kale|spinach|brassica|vegetable)\\b'], ['Name a root vegetable', '\\b(root|tuber|vegetable|rhizome|corm)\\b'],
    ['Name a fish people eat', '\\b(fish|species|food fish)\\b'], ['Name a shellfish', '\\b(shellfish|mollusc|mollusk|crustacean|bivalve|clam|oyster|mussel|scallop|crab|lobster|shrimp|prawn)\\b'],
    ['Name a type of pie', '\\bpie\\b'], ['Name a type of pizza', '\\bpizza\\b'], ['Name a soup from Asia', '\\bsoup|broth\\b', '\\b(asia|china|chinese|japan|korea|thai|vietnam|india|malaysia|indonesia|philippin)'],
    ['Name a bread from Europe', '\\bbread|loaf|roll|bun\\b', '\\b(europe|french|france|german|ital|spain|spanish|british|irish|polish|russian|swed|danish|greek|portug)'],
    ['Name a brand of beer', '\\b(beer|lager|brewery|brand|ale|pilsner)\\b'], ['Name a brand of chocolate', '\\b(chocolate|chocolatier|confectionery|candy|brand)\\b'],
    ['Name a kind of jam or spread', '\\b(jam|jelly|spread|preserve|marmalade|butter|paste|curd)\\b'], ['Name a fermented food', '\\b(ferment|fermented|pickled|cultured)\\b']
  ].forEach(([q, t, w]) => add('food', q, { type: t, where: w ? [w] : undefined, hint: q.replace(/^Name an? /, '') }));

  /* ---------------- ANIMALS ---------------- */
  [
    ['Name a type of ray or skate', '\\b(ray|stingray|skate|manta|guitarfish|sawfish)\\b'], ['Name a whale', '\\b(whale|cetacean|rorqual|orca)\\b'],
    ['Name a dolphin or porpoise', '\\b(dolphin|porpoise|orca)\\b'], ['Name a seal or sea lion', '\\b(seal|sea lion|walrus|pinniped|fur seal)\\b'],
    ['Name a fish', '\\b(fish|species of fish|ray-finned|cichlid|catfish|carp|perch|cod|salmon|trout|eel|minnow|goby|wrasse|tetra|ray|shark)\\b'],
    ['Name an aquarium fish', '\\b(fish|tetra|cichlid|guppy|barb|danio|gourami|catfish|loach|pleco|molly|platy|betta|angelfish|discus|goldfish|koi)\\b'],
    ['Name an eel', '\\beel\\b'], ['Name a cephalopod', '\\b(octopus|squid|cuttlefish|nautilus|cephalopod)\\b'], ['Name a crab', '\\bcrab\\b'],
    ['Name a jellyfish', '\\b(jellyfish|medusa|hydrozoan|cnidarian|box jelly|siphonophore)\\b'], ['Name a bird', '\\b(bird|birds|species of bird|passerine|songbird|raptor|seabird|waterfowl)\\b'],
    ['Name a bird of prey', '\\b(bird of prey|raptor|hawk|eagle|falcon|kite|buzzard|harrier|vulture|osprey|owl|caracara|kestrel|condor|accipitridae)\\b'],
    ['Name an owl', '\\bowl\\b'], ['Name a parrot', '\\b(parrot|macaw|cockatoo|parakeet|lorikeet|lory|conure|amazon|lovebird|budgerigar|kakapo|kea|kaka|cockatiel|psittac)\\b'],
    ['Name a penguin', '\\bpenguin\\b'], ['Name a hummingbird', '\\bhummingbird\\b'], ['Name a duck', '\\b(duck|teal|merganser|eider|wigeon|pochard|scaup|goldeneye|mallard|pintail|shoveler|scoter|whistling|anatidae)\\b'],
    ['Name a woodpecker', '\\b(woodpecker|flicker|sapsucker|piculet|wryneck)\\b'], ['Name a seabird', '\\b(seabird|gull|tern|albatross|petrel|shearwater|puffin|gannet|booby|cormorant|frigatebird|auk|skua|pelican|tropicbird|guillemot|murre|kittiwake)\\b'],
    ['Name a songbird', '\\b(songbird|passerine|warbler|thrush|finch|sparrow|wren|lark|robin|bunting|tanager|oriole|starling|blackbird|nightingale|vireo|chickadee|tit|flycatcher)\\b'],
    ['Name a flightless bird', '\\b(flightless|ratite|ostrich|emu|rhea|cassowary|kiwi|penguin|kakapo|dodo|moa|takahe|weka|steamer duck)\\b'],
    ['Name a snake', '\\b(snake|serpent|viper|python|boa|cobra|mamba|adder|rattlesnake|colubrid|krait|taipan|anaconda)\\b'],
    ['Name a venomous snake', '\\b(snake|viper|cobra|mamba|adder|rattlesnake|krait|taipan|sea snake|serpent)\\b', '\\bvenom'],
    ['Name a lizard', '\\b(lizard|gecko|iguana|skink|monitor|chameleon|agama|anole|gila|komodo|tegu|uromastyx|dragon|squamate)\\b'],
    ['Name a turtle or tortoise', '\\b(turtle|tortoise|terrapin|testudine)\\b'], ['Name a frog or toad', '\\b(frog|toad|anura|anuran|tree frog|bullfrog)\\b'],
    ['Name a salamander or newt', '\\b(salamander|newt|axolotl|hellbender|olm|mudpuppy|siren|caecilian)\\b'],
    ['Name a crocodilian', '\\b(crocodile|alligator|caiman|gharial|crocodilian)\\b'], ['Name a pterosaur', '\\b(pterosaur|pterodactyl|azhdarchid|pterodactyloid|rhamphorhynch)\\b'],
    ['Name a prehistoric marine reptile', '\\b(ichthyosaur|plesiosaur|mosasaur|pliosaur|nothosaur|marine reptile|placodont)\\b'],
    ['Name a prehistoric mammal', '\\b(mammal|prehistoric|extinct|mammoth|mastodon|sabre|saber|megafauna|ground sloth|glyptodont)\\b', '\\b(extinct|prehistoric|fossil|pleistocene|miocene|eocene|oligocene|pliocene|paleocene)\\b'],
    ['Name an extinct animal', '\\b(species|animal|bird|mammal|reptile|genus|extinct)\\b', '\\bextinct'],
    ['Name an insect', '\\b(insect|beetle|butterfly|moth|fly|bee|wasp|ant|bug|cricket|grasshopper|dragonfly|damselfly|cicada|mantis|termite|flea|louse|aphid|mayfly|stick insect|earwig|cockroach|weevil|hornet)\\b', null, '\\b(spider|scorpion|mite|tick|crustacean|arachnid)\\b'],
    ['Name a beetle', '\\b(beetle|weevil|scarab|ladybird|ladybug|firefly|coleoptera|longhorn|chafer)\\b'],
    ['Name a butterfly', '\\b(butterfly|butterflies|swallowtail|skipper|monarch|admiral|fritillary|blue|hairstreak|copper|white|lepidoptera)\\b', null, '\\bmoth\\b'],
    ['Name a moth', '\\bmoth\\b'], ['Name a bee or wasp', '\\b(bee|wasp|hornet|bumblebee|yellowjacket|hymenoptera)\\b'], ['Name an ant', '\\bant\\b|\\bants\\b'],
    ['Name a spider', '\\b(spider|tarantula|widow|arachnid|orb-weaver|recluse|huntsman)\\b'], ['Name a scorpion or arachnid', '\\b(scorpion|arachnid|spider|tick|mite|harvestman|solifuge|whip)\\b'],
    ['Name a mammal', '\\b(mammal|species of mammal|rodent|primate|carnivoran|ungulate|marsupial|bat|cetacean)\\b'],
    ['Name a primate', '\\b(primate|monkey|ape|lemur|gorilla|chimpanzee|orangutan|gibbon|baboon|macaque|tarsier|loris|marmoset|tamarin|capuchin|bonobo|langur|colobus|mandrill|howler)\\b'],
    ['Name a monkey', '\\b(monkey|baboon|macaque|marmoset|tamarin|capuchin|langur|colobus|mandrill|howler|guenon|mangabey|douc|proboscis|saki|uakari)\\b'],
    ['Name a wild cat', '\\b(cat|lion|tiger|leopard|jaguar|cheetah|cougar|puma|lynx|ocelot|serval|caracal|bobcat|felid|felidae|margay|kodkod)\\b', null, '\\bcat breed|breed of (domestic )?cat\\b'],
    ['Name a bear', '\\bbear\\b'], ['Name a wild canine', '\\b(wolf|fox|jackal|coyote|dingo|dhole|canid|canidae|dog)\\b', null, '\\bdog breed|breed of dog\\b'],
    ['Name a deer', '\\b(deer|elk|moose|caribou|reindeer|muntjac|chital|sambar|wapiti|cervid|cervidae|pudu|brocket)\\b'],
    ['Name an antelope', '\\b(antelope|gazelle|impala|kudu|eland|oryx|gnu|wildebeest|springbok|duiker|dik-dik|bongo|nyala|addax|saiga|blackbuck|klipspringer|bovid|sitatunga|topi|hartebeest)\\b'],
    ['Name a rodent', '\\b(rodent|mouse|rat|squirrel|beaver|hamster|gerbil|porcupine|capybara|chinchilla|vole|lemming|marmot|chipmunk|gopher|guinea pig|dormouse|agouti|paca|jerboa|rodentia)\\b'],
    ['Name a bat', '\\bbat\\b|\\bbats\\b|flying fox|chiroptera'], ['Name a hoofed mammal', '\\b(ungulate|hoofed|deer|antelope|horse|zebra|giraffe|hippo|rhinoceros|camel|llama|pig|boar|goat|sheep|cattle|bison|buffalo|tapir|okapi|bovid)\\b'],
    ['Name a cat breed', '\\b(cat breed|breed of cat|breed of domestic cat|cat)\\b', '\\bbreed'], ['Name a horse breed', '\\b(horse|pony)\\b', '\\bbreed'],
    ['Name a cattle breed', '\\b(cattle|cow|ox|bull)\\b', '\\bbreed'], ['Name a chicken breed', '\\b(chicken|fowl|hen|bantam)\\b', '\\bbreed'],
    ['Name a sheep breed', '\\bsheep\\b', '\\bbreed'], ['Name a pig breed', '\\b(pig|swine|hog)\\b', '\\bbreed'], ['Name a goat breed', '\\bgoat\\b', '\\bbreed'],
    ['Name a rabbit breed', '\\brabbit\\b', '\\bbreed'], ['Name an animal native to Australia', '\\b(species|mammal|bird|reptile|marsupial|monotreme|animal|lizard|snake|frog|fish|insect|spider)\\b', '\\baustrali'],
    ['Name an animal native to Madagascar', '\\b(species|mammal|bird|reptile|lemur|animal|lizard|chameleon|frog|tenrec|fossa)\\b', '\\bmadagascar'],
    ['Name an animal native to Africa', '\\b(species|mammal|bird|reptile|animal|antelope|primate)\\b', '\\bafric'],
    ['Name an animal native to South America', '\\b(species|mammal|bird|reptile|animal|primate|rodent|frog|fish)\\b', '\\bsouth americ|amazon|andes|brazil|peru|argentin|colombia|venezuela'],
    ['Name an endangered animal', '\\b(species|animal|mammal|bird|reptile|amphibian|fish)\\b', '\\b(endangered|critically endangered|threatened|vulnerable)\\b'],
    ['Name a nocturnal animal', '\\b(species|animal|mammal|bird|owl|bat)\\b', '\\bnocturnal'], ['Name an animal that hibernates', '\\b(species|animal|mammal|bear|bat|rodent)\\b', '\\bhibernat'],
    ['Name a coral or sea anemone', '\\b(coral|anemone|cnidarian|anthozoa)\\b'], ['Name a sea snail or slug', '\\b(snail|slug|nudibranch|gastropod|conch|whelk|cowrie|abalone|limpet|periwinkle)\\b'],
    ['Name a crustacean', '\\b(crustacean|crab|lobster|shrimp|prawn|krill|barnacle|copepod|isopod|amphipod|crayfish|crawfish|woodlouse)\\b'],
    ['Name a dog breed from Germany', '\\bdog\\b', '\\bgerman'], ['Name a dog breed from France', '\\bdog\\b', '\\b(france|french)\\b'],
    ['Name a dog breed from England', '\\bdog\\b', '\\b(england|english|britain|british)\\b'], ['Name a dog breed from Scotland', '\\bdog\\b', '\\b(scotland|scottish)\\b'],
    ['Name a dog breed from Ireland', '\\bdog\\b', '\\b(ireland|irish)\\b'], ['Name a dog breed from Japan', '\\bdog\\b', '\\bjapan'], ['Name a dog breed from China', '\\bdog\\b', '\\b(china|chinese|tibet)'],
    ['Name a dog breed from Italy', '\\bdog\\b', '\\bital'], ['Name a dog breed from Russia', '\\bdog\\b', '\\brussia'], ['Name a dog breed from Hungary', '\\bdog\\b', '\\bhungar'],
    ['Name a dog breed from Switzerland', '\\bdog\\b', '\\b(swiss|switzerland)\\b'], ['Name a dog breed from Spain', '\\bdog\\b', '\\b(spain|spanish)\\b'],
    ['Name a dog breed from Belgium', '\\bdog\\b', '\\bbelgi'], ['Name a dog breed from the U.S.', '\\bdog\\b', '\\b(american|united states)\\b'],
    ['Name a terrier breed', '\\bterrier\\b'], ['Name a hound breed', '\\b(hound|beagle|basset|harrier|foxhound|coonhound|greyhound|whippet|saluki|borzoi|sighthound|scenthound)\\b'],
    ['Name a herding dog breed', '\\b(herding|sheepdog|shepherd|collie|cattle dog|heeler|corgi)\\b'], ['Name a spaniel or retriever', '\\b(spaniel|retriever)\\b'],
    ['Name a famous animal (real)', '\\b(animal|dog|cat|horse|gorilla|chimpanzee|elephant|whale|octopus|parrot|pig|sheep|bear|orca|bird)\\b', '\\b(famous|known|celebrity|mascot|internet|was a|died)\\b'],
    ['Name a fictional dog', '\\b(dog|puppy|hound|canine)\\b', '\\b(fictional|character|cartoon|comic|film|series)\\b'],
    ['Name a fictional cat', '\\b(cat|kitten|feline)\\b', '\\b(fictional|character|cartoon|comic|film|series)\\b']
  ].forEach(([q, t, w, not]) => {
    const where = w ? [w] : undefined;
    const isBreed = /dog breed|terrier breed|hound breed|herding dog|spaniel or retriever/.test(q);
    add('animals', q, { type: isBreed ? '\\b(dog breed|breed of dog|breed|dog|terrier|hound|spaniel|retriever|sheepdog|collie)\\b' : t, where: isBreed && w ? [w] : where, not: not || undefined, hint: q.replace(/^Name an? /, '') });
  });

  /* ---------------- PLANTS ---------------- */
  [
    ['Name a tree', '\\b(tree|trees|conifer|oak|maple|pine|palm|species of tree|tree species|evergreen|deciduous)\\b'],
    ['Name a flower', '\\b(flower|flowering plant|flowers|ornamental|bloom|blossom|wildflower|bulb|perennial|species of plant|genus of plants|plant)\\b'],
    ['Name a cactus or succulent', '\\b(cactus|cacti|cactaceae|succulent|agave|aloe|crassula|echeveria|sedum|euphorbia)\\b'],
    ['Name a fern or moss', '\\b(fern|moss|bryophyte|horsetail|liverwort|clubmoss|pteridophyte)\\b'],
    ['Name a palm tree', '\\b(palm|arecaceae)\\b'], ['Name a conifer', '\\b(conifer|pine|fir|spruce|cedar|cypress|juniper|larch|yew|redwood|sequoia|hemlock|araucaria|podocarp|pinophyta)\\b'],
    ['Name a carnivorous plant', '\\b(carnivorous|pitcher plant|sundew|flytrap|bladderwort|butterwort|nepenthes|sarracenia|drosera)\\b'],
    ['Name an orchid', '\\borchid\\b'], ['Name a houseplant', '\\b(houseplant|house plant|indoor|ornamental|plant|species)\\b'],
    ['Name a poisonous plant', '\\b(plant|species|shrub|tree|flower|herb)\\b', '\\b(poison|toxic|venom)'], ['Name a herb used in cooking', '\\b(herb|plant|spice|species)\\b', '\\b(culinary|cooking|flavou?r|cuisine|used in)\\b'],
    ['Name a grass or bamboo', '\\b(grass|bamboo|poaceae|sedge|reed|cereal)\\b'], ['Name a vine or climbing plant', '\\b(vine|climb|liana|creeper|ivy|climbing)\\b'],
    ['Name a shrub', '\\b(shrub|bush|hedge|evergreen|deciduous)\\b'], ['Name a weed', '\\b(weed|invasive|plant|species)\\b'],
    ['Name a fungus', '\\b(fungus|fungi|mushroom|mold|mould|yeast|lichen|toadstool|bracket)\\b'], ['Name a seaweed or alga', '\\b(seaweed|alga|algae|kelp|wrack)\\b'],
    ['Name a rose variety or species', '\\brose\\b|\\brosa\\b'], ['Name a lily or tulip', '\\b(lily|lilium|tulip|tulipa)\\b'], ['Name a garden flower', '\\b(flower|flowering|ornamental|garden|perennial|annual|bulb|cultivar)\\b']
  ].forEach(([q, t, w]) => add('plants', q, { type: t, where: w ? [w] : undefined, hint: q.replace(/^Name an? /, '') }));

  /* ---------------- SCIENCE & TECH ---------------- */
  [
    ['Name a chemical element', '\\bchemical element\\b', null, '^chemical elements$'], ['Name a mineral', '\\b(mineral|minerals|silicate|oxide|sulfide|carbonate|ore)\\b'],
    ['Name a gemstone', '\\b(gemstone|gem|precious stone|semi-precious|variety of|mineral|crystal)\\b'], ['Name a type of rock', '\\b(rock|igneous|sedimentary|metamorphic|stone)\\b'],
    ['Name a constellation', '\\bconstellation\\b'], ['Name a star (not the Sun)', '\\b(star|stars|giant|supergiant|dwarf|binary|variable|star system|pulsar)\\b', null, null, '\\b(singer|actor|actress|album|song|film|band|newspaper|footballer)\\b'],
    ['Name an asteroid or comet', '\\b(asteroid|comet|minor planet|near-earth object|trans-neptunian)\\b'], ['Name a galaxy or nebula', '\\b(galaxy|nebula|cluster)\\b'],
    ['Name a spacecraft or space probe', '\\b(spacecraft|space probe|probe|satellite|rover|lander|space telescope|space station|orbiter|capsule|space shuttle|rocket|mission)\\b'],
    ['Name a rocket', '\\b(rocket|launch vehicle|booster|missile)\\b'], ['Name a programming language', '\\bprogramming language|language\\b', '\\b(programming|scripting|compiled|interpreted|syntax|code|software|computing|query)\\b'],
    ['Name an operating system', '\\boperating system|\\bos\\b|distribution|kernel\\b'], ['Name a web browser', '\\bweb browser|browser\\b'],
    ['Name a unit of measurement', '\\b(unit of|unit|measure|measurement)\\b'], ['Name a bone in the human body', '\\bbone|bones|ossicle\\b'], ['Name a muscle', '\\bmuscle\\b'],
    ['Name an organ of the human body', '\\b(organ|gland|tissue|structure)\\b'], ['Name a type of cloud', '\\bcloud|clouds|cumulus|stratus|cirrus|nimbus\\b'],
    ['Name a subatomic particle', '\\b(particle|boson|fermion|quark|lepton|meson|baryon|hadron|neutrino)\\b'], ['Name a vitamin or nutrient', '\\b(vitamin|nutrient|mineral|essential|amino acid|fatty acid)\\b'],
    ['Name an enzyme', '\\benzyme|enzymes|-ase\\b'], ['Name a hormone', '\\bhormone|hormones|neurotransmitter\\b'], ['Name an acid', '\\bacid\\b'],
    ['Name a geologic period', '\\b(period|epoch|era|eon|age)\\b', '\\b(million years|geolog|stratigraph|mya|ma\\b)'], ['Name a disease caused by a virus', '\\b(disease|infection|illness|virus|viral)\\b', '\\bvir'],
    ['Name a virus', '\\bvirus\\b'], ['Name a bacterium', '\\b(bacterium|bacteria|species|genus|bacillus|coccus)\\b', '\\bbacteri'], ['Name a phobia', '\\bphobia|fear\\b'],
    ['Name a mathematical theorem', '\\b(theorem|conjecture|lemma|law|principle|identity|formula)\\b'], ['Name a scientist', '\\b(scientist|physicist|chemist|biologist|astronomer|mathematician|geologist|naturalist|inventor|engineer)\\b'],
    ['Name a physicist', '\\bphysicist\\b'], ['Name a chemist', '\\bchemist\\b'], ['Name a mathematician', '\\bmathematician\\b'], ['Name an astronomer', '\\bastronomer\\b'],
    ['Name a biologist or naturalist', '\\b(biologist|naturalist|zoologist|botanist|geneticist|ecologist|primatologist|entomologist|ornithologist)\\b'], ['Name an inventor', '\\b(inventor|engineer|innovator)\\b'],
    ['Name an astronaut', '\\b(astronaut|cosmonaut|taikonaut|spaceflight)\\b'], ['Name a computer scientist', '\\b(computer scientist|programmer|software|computing)\\b'],
    ['Name a tech company', '\\b(company|corporation|technology|software|internet|electronics|conglomerate|startup)\\b'], ['Name a social media platform', '\\b(social media|social network|social networking|platform|messaging|app|service|website)\\b'],
    ['Name a website', '\\b(website|web site|online|internet|search engine|platform)\\b'], ['Name a car manufacturer', '\\b(automobile|automotive|car|automaker|motor|vehicle) (manufacturer|company|marque|maker|brand)|automaker|marque\\b'],
    ['Name a motorcycle maker', '\\b(motorcycle|motorbike|scooter)\\b'], ['Name an airline', '\\b(airline|airlines|carrier|flag carrier|low-cost)\\b'],
    ['Name an aircraft', '\\b(aircraft|airliner|fighter|bomber|plane|airplane|aeroplane|helicopter|jet|biplane|glider|airship)\\b'], ['Name a famous ship', '\\b(ship|ocean liner|vessel|frigate|battleship|aircraft carrier|schooner|steamship|galleon|sloop|cruiser|submarine|yacht)\\b'],
    ['Name a train or railway line', '\\b(train|railway|railroad|locomotive|line|express|rail)\\b'], ['Name a camera or electronics brand', '\\b(company|brand|manufacturer|corporation|electronics|camera)\\b'],
    ['Name a smartphone model', '\\b(smartphone|phone|mobile phone|handset)\\b'], ['Name a software application', '\\b(software|application|app|program|editor|suite)\\b'],
    ['Name a medical specialty', '\\b(specialty|speciality|medicine|branch|field|discipline|surgery)\\b'], ['Name a branch of science', '\\b(branch|field|science|discipline|study of|scientific study)\\b'],
    ['Name a weather phenomenon', '\\b(weather|storm|wind|phenomenon|meteorolog|precipitation|cyclone|tornado|fog|hail|lightning|monsoon)\\b'], ['Name a named hurricane or typhoon', '\\b(hurricane|typhoon|cyclone|tropical storm)\\b'],
    ['Name a dwarf planet or moon of Jupiter', '\\b(dwarf planet|moon|satellite)\\b', '\\b(dwarf planet|jupiter|jovian)\\b'], ['Name a crater or feature on the Moon', '\\b(crater|mare|mons|rille|lunar|valley|basin)\\b', '\\b(moon|lunar)\\b'],
    ['Name a cryptocurrency', '\\b(cryptocurrency|crypto|token|blockchain|coin)\\b'], ['Name a computer virus or malware', '\\b(malware|virus|worm|trojan|ransomware|botnet|spyware)\\b'],
    ['Name a logical fallacy', '\\bfallacy|fallacies|argument\\b'], ['Name a cognitive bias', '\\bbias|effect|heuristic|fallacy\\b'], ['Name a psychological disorder', '\\bdisorder|syndrome|condition|phobia|mania|psychosis\\b'],
    ['Name a nerve or blood vessel', '\\b(nerve|artery|vein|vessel|cranial|aorta|capillary)\\b'], ['Name a tool used in a lab', '\\b(laboratory|lab|instrument|apparatus|glassware|equipment|device|tool)\\b'],
    ['Name a type of energy or power plant', '\\b(energy|power|power station|power plant|renewable|fuel|generation)\\b'], ['Name a famous experiment', '\\bexperiment\\b']
  ].forEach(([q, t, w, cat, not]) => add('science', q, { type: t, where: w ? [w] : undefined, cat: cat || undefined, not: not || undefined, hint: q.replace(/^Name an? /, '').replace(/\(.*\)/, '') }));

  /* ---------------- PEOPLE ---------------- */
  [
    ['Name a U.S. president', '\\bpresident\\b', '\\bunited states|u\\.s\\.|american\\b', '^presidents of the united states$'],
    ['Name a U.S. vice president', '\\bvice president\\b', '\\bunited states|u\\.s\\.|american\\b', '^vice presidents of the united states$'],
    ['Name a First Lady of the United States', '\\bfirst lady\\b', '.', '^first ladies of the united states$'],
    ['Name a British prime minister', '\\bprime minister\\b', '\\b(united kingdom|great britain|british|uk)\\b', '^prime ministers of the united kingdom$'],
    ['Name a Canadian prime minister', '\\bprime minister\\b', '\\bcanad', '^prime ministers of canada$'],
    ['Name a Roman emperor', '\\b(roman emperor|emperor)\\b', '\\broman|rome\\b', '^roman emperors'],
    ['Name a Byzantine emperor', '\\bemperor\\b', '\\bbyzantin|eastern roman\\b'], ['Name a pope', '\\bpope\\b', '\\b(catholic|church|rome|vatican|holy see)\\b', '^popes$'],
    ['Name an English or British monarch', '\\b(king|queen|monarch)\\b', '\\b(england|great britain|united kingdom|english|british)\\b'],
    ['Name a French king', '\\bking\\b', '\\b(france|french|franks)\\b'], ['Name a Russian tsar', '\\b(tsar|czar|emperor|empress|grand prince)\\b', '\\brussia'],
    ['Name an Egyptian pharaoh', '\\b(pharaoh|king)\\b', '\\begypt'], ['Name a Chinese emperor', '\\bemperor\\b', '\\b(china|chinese|dynasty)\\b'],
    ['Name a Japanese emperor or shogun', '\\b(emperor|shogun|shōgun)\\b', '\\bjapan'], ['Name a Mughal or Ottoman ruler', '\\b(emperor|sultan|ruler|padishah)\\b', '\\b(mughal|ottoman)\\b'],
    ['Name a queen regnant', '\\bqueen\\b', '.'], ['Name a dictator', '\\b(dictator|leader|ruler|politician|general|revolutionary)\\b', '\\b(dictator|authoritarian|totalitarian|regime|junta)\\b'],
    ['Name a revolutionary leader', '\\b(revolutionary|leader|politician|activist|general)\\b', '\\brevolution'], ['Name a civil rights activist', '\\b(activist|leader|minister|campaigner)\\b', '\\bcivil rights|rights\\b'],
    ['Name an explorer', '\\b(explorer|navigator|adventurer|conquistador|voyager)\\b', '.'], ['Name a pirate', '\\b(pirate|privateer|buccaneer|corsair)\\b', '.'],
    ['Name a philosopher', '\\bphilosopher\\b', '.'], ['Name a Greek philosopher', '\\bphilosopher\\b', '\\bgreek|athens|athenian\\b'],
    ['Name a saint', '\\bsaint|martyr|bishop|apostle|monk|nun|abbot|mystic\\b', '\\b(saint|canonized|feast day|venerated)\\b'], ['Name a biblical figure', '\\b(prophet|king|figure|apostle|patriarch|matriarch|judge|priest|disciple|character)\\b', '\\b(bible|biblical|hebrew|testament|genesis|israelite)\\b'],
    ['Name a Nobel Prize in Physics winner', '\\bphysicist\\b', '\\bnobel\\b', '^nobel laureates in physics$'], ['Name a Nobel Prize in Literature winner', '\\b(writer|novelist|poet|playwright|author|essayist)\\b', '\\bnobel\\b', '^nobel laureates in literature$'],
    ['Name a Nobel Peace Prize winner', '\\b(activist|politician|leader|diplomat|organization|statesman|president|lawyer)\\b', '\\bnobel peace\\b', '^nobel peace prize laureates$'],
    ['Name a tennis player', '\\btennis player\\b', '.'], ['Name a golfer', '\\bgolfer\\b', '.'], ['Name a Formula One driver', '\\bracing driver|driver\\b', '\\bformula one|formula 1|\\bf1\\b'],
    ['Name a boxer', '\\bboxer\\b', '.'], ['Name a chess player', '\\bchess (player|grandmaster)|grandmaster\\b', '\\bchess\\b'], ['Name a footballer (soccer)', '\\b(footballer|soccer player|association football)\\b', '.'],
    ['Name a basketball player', '\\bbasketball player\\b', '.'], ['Name a baseball player', '\\bbaseball (player|pitcher|outfielder|infielder|catcher|shortstop)|baseball\\b', '.'],
    ['Name an American football quarterback', '\\b(quarterback|american football)\\b', '\\bquarterback\\b'], ['Name a cricketer', '\\bcricketer\\b', '.'], ['Name an ice hockey player', '\\b(ice hockey|hockey player)\\b', '.'],
    ['Name an Olympic swimmer', '\\bswimmer\\b', '.'], ['Name a track and field athlete', '\\b(sprinter|runner|athlete|hurdler|jumper|thrower|decathlete|heptathlete|marathon)\\b', '.'],
    ['Name a gymnast', '\\bgymnast\\b', '.'], ['Name a figure skater', '\\bfigure skater\\b', '.'], ['Name a skateboarder or surfer', '\\b(skateboarder|surfer|snowboarder|bmx)\\b', '.'],
    ['Name a professional wrestler', '\\bprofessional wrestler|wrestler\\b', '.'], ['Name a mixed martial artist', '\\b(mixed martial artist|mma|ufc|fighter)\\b', '.'], ['Name a jockey or equestrian', '\\b(jockey|equestrian|rider)\\b', '.'],
    ['Name a comedian', '\\b(comedian|comic|humorist|stand-up)\\b', '.'], ['Name a magician', '\\b(magician|illusionist|escapologist|mentalist|escape artist)\\b', '.'],
    ['Name a celebrity chef', '\\b(chef|cook|restaurateur)\\b', '.'], ['Name a YouTuber or streamer', '\\b(youtuber|streamer|youtube|twitch|internet personality|content creator|vlogger)\\b', '.'],
    ['Name a supermodel', '\\b(model|supermodel)\\b', '.'], ['Name a talk show host', '\\b(host|presenter|talk show)\\b', '.'], ['Name a news anchor or journalist', '\\b(journalist|anchor|newscaster|reporter|correspondent|broadcaster)\\b', '.'],
    ['Name a billionaire', '\\b(businessman|businesswoman|entrepreneur|investor|business magnate|executive|billionaire|founder|heir|heiress)\\b', '.'],
    ['Name a film director', '\\b(film director|filmmaker|director)\\b', '.'], ['Name an actor who played James Bond', '\\bactor\\b', '\\bjames bond\\b'], ['Name a silent film star', '\\b(actor|actress|comedian|filmmaker)\\b', '\\bsilent\\b'],
    ['Name an Oscar-winning actress', '\\bactress\\b', '\\b(academy award|oscar)\\b'], ['Name an Oscar-winning actor', '\\bactor\\b', '\\b(academy award|oscar)\\b'],
    ['Name a Marvel superhero or villain', '\\b(character|superhero|supervillain|fictional|antihero|team)\\b', '\\bmarvel\\b'], ['Name a DC Comics character', '\\b(character|superhero|supervillain|fictional|antihero|team)\\b', '\\bdc comics|\\bdc\\b'],
    ['Name a Disney character', '\\b(character|fictional|mascot|princess|protagonist|villain)\\b', '\\bdisney\\b'], ['Name a Star Wars character', '\\b(character|fictional|jedi|sith|droid|protagonist|villain)\\b', '\\bstar wars\\b'],
    ['Name a Looney Tunes character', '\\b(character|fictional|cartoon)\\b', '\\blooney tunes|merrie melodies\\b'], ['Name a Muppet', '\\b(muppet|character|puppet)\\b', '\\bmuppet|sesame street\\b'],
    ['Name a Batman villain', '\\b(character|supervillain|villain|fictional)\\b', '\\bbatman\\b'], ['Name a Spider-Man villain', '\\b(character|supervillain|villain|fictional)\\b', '\\bspider-man\\b'],
    ['Name an X-Men character', '\\b(character|superhero|mutant|fictional|supervillain)\\b', '\\bx-men\\b'], ['Name a Transformers character', '\\b(character|autobot|decepticon|fictional|robot)\\b', '\\btransformers\\b'],
    ['Name a fictional robot or AI', '\\b(robot|android|ai|artificial intelligence|cyborg|droid|computer)\\b', '\\b(fictional|character|film|series|novel)\\b'],
    ['Name a fictional villain', '\\b(villain|antagonist|supervillain|character)\\b', '\\b(fictional|character)\\b'], ['Name a fictional spy', '\\b(spy|agent|secret agent|operative)\\b', '\\b(fictional|character)\\b'],
    ['Name a fictional pirate', '\\b(pirate|captain|character)\\b', '\\b(fictional|character)\\b'], ['Name a cartoon character', '\\b(character|cartoon|animated|fictional|mascot)\\b', '.'],
    ['Name a fictional detective', '\\b(detective|investigator|sleuth|inspector|private eye)\\b', '\\b(fictional|character)\\b']
  ].forEach(([q, t, w, cat]) => add('people', q, { type: t, where: w && w !== '.' ? [w] : undefined, cat: cat || undefined, hint: q.replace(/^Name an? /, '').replace(/\(.*\)/, '') }));

  /* ---------------- MYTH & BELIEF ---------------- */
  [
    ['Name a Greek god or goddess', '\\b(god|goddess|deity|titan|titaness|primordial|olympian|personification)\\b', '\\bgreek\\b'],
    ['Name a Roman god or goddess', '\\b(god|goddess|deity|personification)\\b', '\\broman\\b'],
    ['Name a Norse god or goddess', '\\b(god|goddess|deity|jötunn|jotunn|giant|æsir|aesir|vanir|valkyrie)\\b', '\\b(norse|germanic|old norse|scandinavian)\\b'],
    ['Name an Egyptian god or goddess', '\\b(god|goddess|deity)\\b', '\\begypt'], ['Name a Hindu deity', '\\b(god|goddess|deity|avatar|devi|deva)\\b', '\\bhindu'],
    ['Name an Aztec or Maya god', '\\b(god|goddess|deity)\\b', '\\b(aztec|maya|mayan|mesoamerican|nahua)\\b'], ['Name a Celtic god or hero', '\\b(god|goddess|deity|hero|figure|king|warrior)\\b', '\\b(celtic|irish|welsh|gaulish|gaelic)\\b'],
    ['Name a Japanese yokai or kami', '\\b(yōkai|yokai|kami|spirit|creature|monster|deity|demon|god|goddess)\\b', '\\bjapan'],
    ['Name a Greek mythological hero', '\\b(hero|demigod|king|prince|warrior|figure|son of)\\b', '\\bgreek'], ['Name a monster from Greek myth', '\\b(monster|creature|beast|serpent|giant|nymph|being)\\b', '\\bgreek'],
    ['Name a mythical creature', '\\b(creature|monster|beast|spirit|being|cryptid|dragon|serpent|giant|demon)\\b', '\\b(myth|mytholog|legend|legendary|folklore|folk)'],
    ['Name a cryptid', '\\b(cryptid|creature|monster|beast|ape|being)\\b', '\\b(cryptid|cryptozoolog|folklore|sighting|legend|reported)'],
    ['Name a figure from Arthurian legend', '\\b(knight|king|queen|wizard|sorcer|enchantress|lady|figure|character)\\b', '\\b(arthur|arthurian|round table|camelot)\\b'],
    ['Name an angel or demon', '\\b(angel|archangel|demon|devil|fallen angel|spirit|jinn|cherub|seraph)\\b'], ['Name a religion', '\\b(religion|faith|religious movement|belief|tradition|sect|denomination|church)\\b'],
    ['Name a holiday or festival', '\\b(holiday|festival|observance|feast|celebration|day)\\b'], ['Name a Jewish holiday', '\\b(holiday|festival|observance|feast|day|fast)\\b', '\\bjewish|judaism\\b'],
    ['Name a Hindu or Buddhist festival', '\\b(festival|holiday|celebration|observance)\\b', '\\b(hindu|buddhis|sikh|jain)'], ['Name a book of the Bible', '\\b(book|gospel|epistle|letter)\\b', '\\b(bible|biblical|testament)\\b'],
    ['Name a tarot card', '\\b(tarot|card|arcana|trump)\\b'], ['Name a zodiac sign or constellation of the zodiac', '\\b(zodiac|astrological|sign|constellation)\\b'],
    ['Name a superstition or omen', '\\b(superstition|omen|belief|luck|charm|taboo)\\b'], ['Name a fairy or folklore spirit', '\\b(fairy|faerie|sprite|spirit|elf|goblin|gnome|brownie|pixie|kobold|banshee|nymph)\\b']
  ].forEach(([q, t, w]) => add('myth', q, { type: t, where: w ? [w] : undefined, hint: q.replace(/^Name an? /, '') }));

  /* ---------------- SPORTS ---------------- */
  [
    ['Name an NFL team', '\\b(team|franchise)\\b', '\\b(national football league|nfl)\\b'], ['Name an NBA team', '\\b(team|franchise)\\b', '\\b(national basketball association|nba)\\b'],
    ['Name an MLB team', '\\b(team|franchise)\\b', '\\b(major league baseball|mlb)\\b'], ['Name an NHL team', '\\b(team|franchise)\\b', '\\b(national hockey league|nhl)\\b'],
    ['Name an MLS team', '\\b(club|team|franchise)\\b', '\\b(major league soccer|mls)\\b'], ['Name a college football program', '\\b(football|team|program)\\b', '\\b(ncaa|college|university|division i|fbs|fcs)\\b'],
    ['Name an Olympic sport', '\\bsport\\b', '\\bolympic'], ['Name a Winter Olympic sport', '\\bsport\\b', '\\bwinter olympic'], ['Name a martial art', '\\b(martial art|combat sport|fighting style|self-defense|self-defence)\\b'],
    ['Name a team sport', '\\b(team sport|sport)\\b'], ['Name a racket sport', '\\b(racket|racquet|paddle|bat)\\b'], ['Name a water sport', '\\b(sport|water|aquatic)\\b', '\\b(water|swim|surf|sail|row|paddle|dive|boat)'],
    ['Name a dance', '\\b(dance|ballroom|folk dance|dance style)\\b'], ['Name a yoga pose', '\\b(asana|pose|posture)\\b'], ['Name a gymnastics move or apparatus', '\\b(gymnastics|apparatus|vault|beam|bars|rings|pommel|skill|element)\\b'],
    ['Name a skateboarding trick', '\\b(trick|skateboarding|ollie|flip|grind)\\b'], ['Name a wrestling move', '\\b(move|hold|throw|slam|suplex|submission|technique)\\b'],
    ['Name a Formula One circuit', '\\b(circuit|racetrack|race track|raceway|autodrome|street circuit|motor racing)\\b'], ['Name a horse race', '\\b(horse race|race|stakes|derby|cup|handicap)\\b', '\\b(horse|thoroughbred|flat racing|steeplechase)\\b'],
    ['Name a golf tournament', '\\b(golf|tournament|championship|open)\\b', '\\bgolf'], ['Name a tennis tournament', '\\b(tournament|championship|open|cup)\\b', '\\btennis'],
    ['Name a cycling race', '\\b(race|tour|cycling|classic|grand tour)\\b', '\\bcycl'], ['Name a famous stadium', '\\b(stadium|arena|ballpark|ground|field|coliseum|dome)\\b'],
    ['Name a Premier League club', '\\b(football club|club|association football|soccer)\\b', '\\bpremier league\\b'],
    ['Name a football club in England', '\\b(football club|club|association football|soccer)\\b', '\\b(england|english)\\b'], ['Name a football club in Spain', '\\b(football club|club|association football|soccer)\\b', '\\b(spain|spanish)\\b'],
    ['Name a football club in Italy', '\\b(football club|club|association football|soccer)\\b', '\\bital'], ['Name a football club in Germany', '\\b(football club|club|association football|soccer)\\b', '\\bgerman'],
    ['Name a football club in France', '\\b(football club|club|association football|soccer)\\b', '\\b(france|french)\\b'], ['Name a football club in the Netherlands', '\\b(football club|club|association football|soccer)\\b', '\\b(netherlands|dutch)\\b'],
    ['Name a football club in Portugal', '\\b(football club|club|association football|soccer)\\b', '\\bportug'], ['Name a football club in Scotland', '\\b(football club|club|association football|soccer)\\b', '\\b(scotland|scottish)\\b'],
    ['Name a football club in Brazil', '\\b(football club|club|association football|soccer|futebol)\\b', '\\bbrazil'], ['Name a football club in Argentina', '\\b(football club|club|association football|soccer)\\b', '\\bargentin'],
    ['Name a football club in Mexico', '\\b(football club|club|association football|soccer)\\b', '\\bmexic'], ['Name a football club in Turkey', '\\b(football club|club|association football|soccer|sports club)\\b', '\\b(turkey|turkish|türkiye)\\b'],
    ['Name a football club in Japan', '\\b(football club|club|association football|soccer)\\b', '\\bjapan'], ['Name a national football team', '\\b(national (football|soccer) team|national team)\\b'],
    ['Name a rugby team', '\\b(rugby)\\b'], ['Name a cricket team', '\\bcricket\\b'], ['Name a sports trophy', '\\b(trophy|cup|award|prize|championship)\\b'],
    ['Name a type of bicycle or skate', '\\b(bicycle|bike|skate|skateboard|scooter|unicycle)\\b'], ['Name a fishing technique or lure', '\\b(fishing|angling|lure|fly|bait)\\b'],
    ['Name a card game you play with a standard deck', '\\bcard game\\b'], ['Name a lawn or pub game', '\\b(game|sport|pub game|lawn game|throwing game)\\b'],
    ['Name a sporting position', '\\b(position|player)\\b'], ['Name a climbing term or knot', '\\b(knot|hitch|bend|climbing|loop|lashing)\\b'], ['Name an esports game or team', '\\b(esports|e-sports|video game|team|organization)\\b']
  ].forEach(([q, t, w]) => add('sports', q, { type: t, where: w ? [w] : undefined, hint: q.replace(/^Name an? /, '') }));

  /* ---------------- GRAB BAG ---------------- */
  const BRANDS = [['Ford', '\\bford\\b'], ['Toyota', '\\btoyota'], ['Honda', '\\bhonda'], ['Chevrolet', '\\bchevrolet|chevy'], ['BMW', '\\bbmw'],
    ['Mercedes-Benz', '\\bmercedes'], ['Volkswagen', '\\bvolkswagen|\\bvw\\b'], ['Porsche', '\\bporsche'], ['Ferrari', '\\bferrari'], ['Lamborghini', '\\blamborghini'],
    ['Nissan', '\\bnissan|datsun'], ['Audi', '\\baudi\\b'], ['Jeep', '\\bjeep'], ['Dodge', '\\bdodge'], ['Volvo', '\\bvolvo'], ['Fiat', '\\bfiat'], ['Mazda', '\\bmazda'],
    ['Subaru', '\\bsubaru'], ['Hyundai', '\\bhyundai'], ['Renault', '\\brenault'], ['Peugeot', '\\bpeugeot'], ['Cadillac', '\\bcadillac'], ['Aston Martin', '\\baston martin'],
    ['Mitsubishi', '\\bmitsubishi'], ['Kia', '\\bkia\\b']];
  BRANDS.forEach(([b, w]) => add('misc', `Name a ${b} car model`, { type: '\\b(car|automobile|vehicle|suv|sedan|saloon|hatchback|coupe|coupé|truck|pickup|minivan|sports car|crossover|roadster|supercar|model|convertible|estate|wagon|grand tourer|microcar)\\b', where: [w], hint: `${b} car` }));
  [
    ['Name a currency', '\\b(currency|money|coin)\\b'], ['Name a writing system or alphabet', '\\b(script|alphabet|abugida|abjad|syllabary|writing system|logograph)\\b'],
    ['Name a punctuation mark or symbol', '\\b(punctuation|symbol|mark|sign|glyph|character)\\b'],
    ['Name a toy', '\\b(toy|toys|doll|game|plaything|action figure|puzzle)\\b'], ['Name a doll or action figure line', '\\b(doll|action figure|toy|figure|line)\\b'],
    ['Name a type of hat', '\\b(hat|cap|headwear|headgear|helmet|beret|bonnet|turban)\\b'], ['Name a type of shoe', '\\b(shoe|shoes|boot|boots|footwear|sandal|sneaker|slipper|loafer|clog|heel)\\b'],
    ['Name an item of clothing', '\\b(garment|clothing|clothes|dress|shirt|coat|jacket|trousers|skirt|sweater|apparel|wear|robe|tunic)\\b'], ['Name a fabric or textile', '\\b(fabric|textile|cloth|weave|fibre|fiber|yarn)\\b'],
    ['Name a hairstyle', '\\b(hairstyle|haircut|hair|braid|bun|cut)\\b'], ['Name a color', '\\b(colou?r|shade|hue|pigment|tint|dye)\\b'], ['Name a shape', '\\b(shape|polygon|polyhedron|figure|curve|solid|geometric)\\b'],
    ['Name a knot', '\\b(knot|hitch|bend|loop|splice|lashing)\\b'], ['Name a tool', '\\b(tool|hand tool|power tool|implement|device)\\b'], ['Name a weapon from history', '\\b(weapon|sword|spear|axe|bow|blade|dagger|polearm|mace|firearm|cannon|gun|club|shield)\\b'],
    ['Name a type of sword', '\\b(sword|sabre|saber|blade|rapier|katana|scimitar|cutlass|broadsword|longsword|claymore|falchion|gladius)\\b'], ['Name a piece of furniture', '\\b(furniture|chair|table|sofa|couch|bed|cabinet|desk|stool|bench|wardrobe|dresser|shelf|ottoman)\\b'],
    ['Name a style of architecture or house', '\\b(architecture|architectural|house|building|style|dwelling)\\b'], ['Name a type of boat', '\\b(boat|ship|vessel|canoe|kayak|yacht|dinghy|raft|barge|junk|dhow|sailboat|ferry)\\b'],
    ['Name a vehicle that isn\'t a car', '\\b(vehicle|bicycle|motorcycle|truck|bus|train|tram|boat|ship|aircraft|tractor|scooter|cart|wagon|carriage|sled|sledge)\\b'],
    ['Name a musical term', '\\b(music|musical|tempo|term|notation|dynamics|technique|interval|chord|scale|mode)\\b'], ['Name a magic trick', '\\b(trick|illusion|magic|sleight|effect)\\b'],
    ['Name a crime or legal term', '\\b(crime|offence|offense|law|legal|term|felony|tort|doctrine)\\b'], ['Name a political ideology', '\\b(ideology|political|philosophy|movement|-ism|doctrine)\\b'],
    ['Name a form of government', '\\b(government|governance|system|form of|rule|regime|state)\\b'], ['Name an international organization', '\\b(organization|organisation|alliance|union|association|agency|bloc|treaty)\\b'],
    ['Name a war', '\\b(war|conflict|insurgency|rebellion|revolution)\\b'], ['Name a battle', '\\b(battle|siege|offensive|campaign|engagement)\\b'], ['Name an empire', '\\b(empire|caliphate|dynasty|khanate|sultanate|kingdom)\\b'],
    ['Name an ancient civilization', '\\b(civilization|civilisation|culture|people|kingdom|empire|society)\\b'], ['Name a treaty', '\\b(treaty|accord|agreement|pact|convention|peace)\\b'],
    ['Name a famous speech', '\\bspeech|address|sermon\\b'], ['Name a famous painting', '\\b(painting|portrait|fresco|mural)\\b'], ['Name a famous diamond or jewel', '\\b(diamond|jewel|gem|gemstone|ruby|sapphire|emerald|pearl|crown|necklace)\\b'],
    ['Name a perfume or fragrance', '\\b(perfume|fragrance|eau de|cologne|scent)\\b'], ['Name a cosmetics or beauty brand', '\\b(cosmetics|beauty|makeup|skin care|skincare|brand|company)\\b'],
    ['Name a department store or retailer', '\\b(department store|retailer|store|chain|supermarket|shop)\\b'], ['Name a hotel chain', '\\b(hotel|hotels|hospitality|resort)\\b'],
    ['Name a theme park', '\\b(theme park|amusement park|park|resort)\\b'], ['Name a roller coaster', '\\b(roller coaster|coaster|ride)\\b'], ['Name a circus act or performer', '\\b(circus|acrobat|clown|juggler|trapeze|performer|act)\\b'],
    ['Name a famous horse', '\\b(horse|racehorse|thoroughbred|stallion|mare|gelding)\\b'], ['Name an emoji or emoticon', '\\b(emoji|emoticon|symbol|smiley)\\b'],
    ['Name a social dance from Latin America', '\\b(dance|music|genre)\\b', '\\b(latin|cuba|brazil|argentin|mexic|dominican|colombia|puerto ric)'],
    ['Name a meme or internet phenomenon', '\\b(meme|internet|viral|phenomenon|catchphrase)\\b'], ['Name a type of poem', '\\b(poem|poetry|verse|form|stanza|meter|metre)\\b'],
    ['Name a figure of speech', '\\b(figure of speech|rhetorical|device|trope|literary device)\\b'], ['Name a board game piece or chess piece', '\\b(piece|chess|token|counter|pawn|meeple)\\b'],
    ['Name a famous computer', '\\b(computer|microcomputer|mainframe|supercomputer|machine|calculator)\\b'], ['Name a famous robot', '\\b(robot|android|humanoid|automaton|rover)\\b'],
    ['Name a toy brand', '\\b(toy|toys|brand|company|manufacturer)\\b'], ['Name a fictional language', '\\b(constructed language|conlang|fictional language|language)\\b', '\\b(fictional|constructed|invented|created)\\b'],
    ['Name a famous ship that sank', '\\b(ship|liner|vessel|steamship|battleship|submarine|wreck|ferry)\\b', '\\b(sank|sunk|sinking|shipwreck|wreck|foundered|scuttled|lost)\\b'],
    ['Name a famous shipwreck or lost treasure', '\\b(ship|shipwreck|wreck|galleon|treasure|vessel)\\b'], ['Name a famous heist or robbery', '\\b(robbery|heist|theft|burglary|hijacking)\\b'],
    ['Name a scandal', '\\bscandal|affair\\b'], ['Name an ancient wonder or monument', '\\b(wonder|monument|temple|pyramid|statue|lighthouse|tomb|mausoleum|colossus|garden)\\b'],
    ['Name a famous tower', '\\btower\\b'], ['Name a famous garden', '\\b(garden|gardens|arboretum|botanical|park)\\b'], ['Name a famous square or plaza', '\\b(square|plaza|piazza|platz|place)\\b'],
    ['Name a famous prison', '\\b(prison|penitentiary|jail|gaol|gulag)\\b'], ['Name a famous mansion or palace', '\\b(mansion|palace|manor|estate|house|residence|château|villa)\\b'],
    ['Name a famous cemetery or tomb', '\\b(cemetery|tomb|mausoleum|necropolis|burial|grave|graveyard)\\b'], ['Name a lighthouse', '\\blighthouse\\b']
  ].forEach(([q, t, w]) => add('misc', q, { type: t, where: w ? [w] : undefined, hint: q.replace(/^Name an? /, '') }));


  /* ---------------- KEEP IT NORMAL ----------------
     Only everyday prompts that most people can answer several ways. */
  const DROP = new Set([
    'Name a parish in Louisiana', 'Name a borough of Alaska', 'Name a U.S. interstate highway',
    'Name a neighborhood of Los Angeles', 'Name a neighborhood of Chicago',
    'Name a strait', 'Name a bay or gulf', 'Name a canal', 'Name a peninsula', 'Name a glacier', 'Name a cave', 'Name a canyon or gorge',
    'Name a German state', 'Name a region of France', 'Name a prefecture of Japan', 'Name a state or territory of India', 'Name a state of Mexico',
    'Name a state of Brazil', 'Name a Swiss canton', 'Name a region of Italy', 'Name a province of China', 'Name a London borough or district',
    'Name a Scottish island', 'Name a Canary or Balearic island', 'Name a Pacific island nation', 'Name a World Heritage Site', 'Name a famous street',
    'Name a national park outside the U.S.', 'Name a film noir', 'Name a silent film', 'Name a stop-motion film', 'Name a documentary film',
    'Name a Godzilla or kaiju film', 'Name a Star Trek film', 'Name a K-drama', 'Name a mockumentary series', 'Name a sketch comedy show',
    'Name a Star Trek series', 'Name a character from Twin Peaks', 'Name a character from Lost',
    'Name a symphony', 'Name a ballet', 'Name an opera', 'Name a national anthem', 'Name a record label', 'Name a DJ', 'Name a grunge band',
    'Name a disco song', 'Name a one-hit wonder', 'Name a Baroque composer', 'Name a violinist', 'Name an opera singer', 'Name a pianist', 'Name a drummer',
    'Name a Sherlock Holmes story', 'Name a comic strip', 'Name a graphic novel', 'Name a Greek epic or tragedy', 'Name a playwright', 'Name a literary detective',
    'Name a Shakespeare character',
    'Name an art movement', 'Name an architectural style', 'Name a famous sculpture', 'Name a sculptor', 'Name an architect', 'Name a photographer',
    'Name a typeface', 'Name an impressionist painter', 'Name a Renaissance artist', 'Name a surrealist artist', 'Name a pop artist', 'Name a street artist', 'Name a cartoonist',
    'Name a tabletop role-playing game', 'Name a chess opening', 'Name a solitaire game', 'Name a sandbox game', 'Name an indie game', 'Name a platform game',
    'Name a beer style', 'Name a wine grape variety', 'Name a liqueur or spirit', 'Name a cooking technique', 'Name a grain or cereal crop',
    'Name a type of onion or allium', 'Name a squash or gourd', 'Name a fermented food', 'Name a kind of jam or spread', 'Name a soup from Asia',
    'Name a bread from Europe', 'Name a type of rice', 'Name a spirit-forward drink', 'Name a cocktail made with tequila', 'Name a cocktail made with rum',
    'Name a cocktail made with whiskey', 'Name a cocktail made with gin', 'Name a cocktail made with vodka', 'Name a legume', 'Name a chili pepper',
    'Name an apple variety', 'Name a dumpling', 'Name a cut of beef', 'Name a tropical fruit', 'Name a citrus fruit',
    'Name a type of ray or skate', 'Name an eel', 'Name a cephalopod', 'Name a jellyfish', 'Name a woodpecker', 'Name a hummingbird', 'Name a seabird',
    'Name a songbird', 'Name a salamander or newt', 'Name a crocodilian', 'Name a pterosaur', 'Name a prehistoric marine reptile', 'Name a prehistoric mammal',
    'Name a moth', 'Name an ant', 'Name a scorpion or arachnid', 'Name an antelope', 'Name a hoofed mammal', 'Name a cattle breed', 'Name a chicken breed',
    'Name a sheep breed', 'Name a pig breed', 'Name a goat breed', 'Name a rabbit breed', 'Name an animal native to Madagascar',
    'Name an animal native to South America', 'Name a nocturnal animal', 'Name an animal that hibernates', 'Name a coral or sea anemone',
    'Name a sea snail or slug', 'Name a terrier breed', 'Name a hound breed', 'Name a herding dog breed', 'Name a deer', 'Name a beetle', 'Name a duck',
    'Name a famous animal (real)', 'Name an aquarium fish', 'Name a bat', 'Name a primate',
    'Name a fern or moss', 'Name a palm tree', 'Name a conifer', 'Name a carnivorous plant', 'Name an orchid', 'Name a grass or bamboo',
    'Name a vine or climbing plant', 'Name a shrub', 'Name a weed', 'Name a fungus', 'Name a seaweed or alga', 'Name a rose variety or species', 'Name a lily or tulip',
    'Name a mineral', 'Name a type of rock', 'Name a star (not the Sun)', 'Name an asteroid or comet', 'Name a galaxy or nebula', 'Name a rocket',
    'Name a subatomic particle', 'Name an enzyme', 'Name a hormone', 'Name an acid', 'Name a geologic period', 'Name a disease caused by a virus', 'Name a virus',
    'Name a bacterium', 'Name a mathematical theorem', 'Name a chemist', 'Name a mathematician', 'Name an astronomer', 'Name a biologist or naturalist',
    'Name a computer scientist', 'Name a train or railway line', 'Name a medical specialty', 'Name a branch of science', 'Name a dwarf planet or moon of Jupiter',
    'Name a crater or feature on the Moon', 'Name a computer virus or malware', 'Name a logical fallacy', 'Name a cognitive bias', 'Name a psychological disorder',
    'Name a nerve or blood vessel', 'Name a tool used in a lab', 'Name a type of energy or power plant', 'Name a famous experiment', 'Name a spacecraft or space probe',
    'Name a type of cloud', 'Name a muscle', 'Name a physicist', 'Name a motorcycle maker', 'Name a camera or electronics brand', 'Name a software application',
    'Name a U.S. vice president', 'Name a First Lady of the United States', 'Name a Canadian prime minister', 'Name a Byzantine emperor', 'Name a pope',
    'Name a French king', 'Name a Russian tsar', 'Name a Chinese emperor', 'Name a Japanese emperor or shogun', 'Name a Mughal or Ottoman ruler',
    'Name a queen regnant', 'Name a dictator', 'Name a revolutionary leader', 'Name a Greek philosopher', 'Name a saint',
    'Name a Nobel Prize in Physics winner', 'Name a Nobel Prize in Literature winner', 'Name a Nobel Peace Prize winner', 'Name a cricketer',
    'Name a figure skater', 'Name a jockey or equestrian', 'Name a news anchor or journalist', 'Name a silent film star', 'Name a Transformers character',
    'Name a fictional spy', 'Name a fictional pirate', 'Name a fictional robot or AI', 'Name an X-Men character', 'Name a Looney Tunes character', 'Name a Muppet',
    'Name an Aztec or Maya god', 'Name a Celtic god or hero', 'Name a Japanese yokai or kami', 'Name a Jewish holiday', 'Name a Hindu or Buddhist festival',
    'Name a tarot card', 'Name a Hindu deity', 'Name a cryptid',
    'Name a yoga pose', 'Name a gymnastics move or apparatus', 'Name a skateboarding trick', 'Name a wrestling move', 'Name a Formula One circuit',
    'Name a horse race', 'Name a golf tournament', 'Name a tennis tournament', 'Name a cycling race', 'Name a college football program',
    'Name a rugby team', 'Name a cricket team', 'Name a type of bicycle or skate', 'Name a fishing technique or lure', 'Name a climbing term or knot',
    'Name an esports game or team', 'Name a sporting position', 'Name a Winter Olympic sport', 'Name a racket sport', 'Name a water sport', 'Name a MLS team',
    'Name an MLS team', 'Name a writing system or alphabet', 'Name a punctuation mark or symbol', 'Name a doll or action figure line', 'Name a knot',
    'Name a type of sword', 'Name a style of architecture or house', 'Name a musical term', 'Name a magic trick', 'Name a crime or legal term',
    'Name a political ideology', 'Name a form of government', 'Name a battle', 'Name a treaty', 'Name a famous speech', 'Name a famous diamond or jewel',
    'Name a perfume or fragrance', 'Name a roller coaster', 'Name a circus act or performer', 'Name a famous horse', 'Name a social dance from Latin America',
    'Name a type of poem', 'Name a figure of speech', 'Name a board game piece or chess piece', 'Name a famous computer', 'Name a famous robot',
    'Name a fictional language', 'Name a famous shipwreck or lost treasure', 'Name a famous heist or robbery', 'Name a scandal', 'Name a famous garden',
    'Name a famous square or plaza', 'Name a famous prison', 'Name a famous mansion or palace', 'Name a famous cemetery or tomb', 'Name a lighthouse',
    'Name a fabric or textile', 'Name an international organization', 'Name a hotel chain', 'Name a cosmetics or beauty brand', 'Name a lawn or pub game',
    'Name a medical drama series', 'Name a Shakespeare play'
  ]);
  const DIRS = new Set(['Steven Spielberg', 'Christopher Nolan', 'Martin Scorsese', 'Quentin Tarantino', 'Alfred Hitchcock', 'Stanley Kubrick',
    'Ridley Scott', 'James Cameron', 'Tim Burton', 'Hayao Miyazaki', 'George Lucas', 'Peter Jackson', 'Wes Anderson', 'Clint Eastwood',
    'Robert Zemeckis', 'Michael Bay', 'M. Night Shyamalan', 'Jordan Peele', 'Greta Gerwig', 'David Fincher', 'Guillermo del Toro', 'Ron Howard', 'Sam Raimi', 'Denis Villeneuve']);
  const SONGS = new Set(['Taylor Swift', 'the Beatles', 'Queen', 'Michael Jackson', 'Madonna', 'Beyoncé', 'Drake', 'Eminem', 'Rihanna', 'Adele',
    'Ed Sheeran', 'Elvis Presley', 'the Rolling Stones', 'Led Zeppelin', 'David Bowie', 'Elton John', 'ABBA', 'Nirvana', 'Coldplay', 'U2',
    'Metallica', 'AC/DC', 'Whitney Houston', 'Mariah Carey', 'Britney Spears', 'Lady Gaga', 'Katy Perry', 'Justin Bieber', 'Bruno Mars',
    'the Weeknd', 'Kanye West', 'Billie Eilish', 'Ariana Grande', 'Dua Lipa', 'Harry Styles', 'One Direction', 'Olivia Rodrigo',
    'Sabrina Carpenter', 'Bad Bunny', 'Shakira', 'Johnny Cash', 'Dolly Parton', 'Frank Sinatra', 'Stevie Wonder', 'Prince', 'Bob Marley',
    'Green Day', 'Linkin Park', 'Guns N\' Roses', 'Bon Jovi', 'Red Hot Chili Peppers', 'Imagine Dragons', 'Maroon 5', 'the Backstreet Boys',
    'the Spice Girls', 'BTS', 'Post Malone', 'Kendrick Lamar', 'Fleetwood Mac', 'Pink Floyd', 'the Beach Boys', 'Lana Del Rey', 'Chappell Roan', 'Bruce Springsteen']);
  const ALBUMS = new Set(['Taylor Swift', 'the Beatles', 'Michael Jackson', 'Pink Floyd', 'Queen', 'Beyoncé', 'Drake', 'Eminem', 'Kanye West',
    'Lady Gaga', 'Ariana Grande', 'the Rolling Stones', 'Led Zeppelin', 'Coldplay', 'Madonna']);
  const AUTH = new Set(['Stephen King', 'Agatha Christie', 'Charles Dickens', 'Jane Austen', 'Ernest Hemingway', 'Mark Twain', 'George Orwell',
    'Roald Dahl', 'J. R. R. Tolkien', 'C. S. Lewis', 'Dan Brown', 'John Grisham', 'Michael Crichton', 'Rick Riordan', 'James Patterson',
    'Jules Verne', 'Leo Tolstoy', 'John Steinbeck', 'F. Scott Fitzgerald', 'Suzanne Collins', 'George R. R. Martin', 'Judy Blume', 'Colleen Hoover', 'Oscar Wilde']);
  const FRAN = new Set(['Mario', 'The Legend of Zelda', 'Pokémon', 'Sonic the Hedgehog', 'Final Fantasy', 'Call of Duty', 'Grand Theft Auto',
    'Assassin\'s Creed', 'Halo', 'Kirby', 'Resident Evil', 'Street Fighter', 'Mortal Kombat', 'Donkey Kong', 'Star Wars', 'Fallout', 'Lego',
    'Batman', 'The Sims', 'Mario Kart', 'Animal Crossing', 'Madden NFL', 'FIFA', 'Crash Bandicoot', 'Need for Speed', 'Tomb Raider',
    'puzzle', 'horror', 'role-playing', 'strategy']);
  const CUIS = new Set(['Japanese', 'Chinese', 'Korean', 'Thai', 'Vietnamese', 'Indian', 'Mexican', 'Italian', 'French', 'Spanish', 'Greek',
    'Turkish', 'German', 'British', 'Irish', 'Filipino', 'Brazilian', 'Cajun or Creole', 'Tex-Mex', 'Southern U.S.', 'Middle Eastern', 'Hawaiian', 'Caribbean', 'Polish', 'Russian',
    'noodle', 'rice', 'potato', 'egg', 'seafood']);
  const CARS = new Set(['Ford', 'Toyota', 'Honda', 'Chevrolet', 'BMW', 'Mercedes-Benz', 'Volkswagen', 'Porsche', 'Ferrari', 'Lamborghini', 'Nissan', 'Jeep', 'Dodge', 'Audi', 'Hyundai', 'Kia', 'Subaru', 'Mazda']);
  function normal(p) {
    if (p.niche || DROP.has(p.q)) return false;
    let m;
    if (/premiered in \d{4}$/.test(p.q)) return false;
    if ((m = p.q.match(/^Name a movie released in (\d{4})$/))) return +m[1] >= 1980 && +m[1] <= 2024;
    if ((m = p.q.match(/^Name a video game released in (\d{4})$/))) return +m[1] >= 2000 && +m[1] <= 2024;
    if ((m = p.q.match(/^Name a film directed by (.+)$/))) return DIRS.has(m[1]);
    if ((m = p.q.match(/^Name a song by (.+)$/))) return SONGS.has(m[1]);
    if ((m = p.q.match(/^Name an album by (.+)$/))) return ALBUMS.has(m[1]);
    if ((m = p.q.match(/^Name a book by (.+)$/))) return AUTH.has(m[1]);
    if ((m = p.q.match(/^Name an? (.+) video game$/))) return FRAN.has(m[1]);
    if ((m = p.q.match(/^Name an? (.+) dish$/))) return CUIS.has(m[1]);
    if ((m = p.q.match(/^Name an? (.+) cheese$/))) return ['French', 'Italian', 'Swiss', 'American'].includes(m[1]);
    if ((m = p.q.match(/^Name an? (.+) car model$/))) return CARS.has(m[1]);
    if ((m = p.q.match(/^Name a dog breed from (.+)$/))) return ['Germany', 'England', 'Japan', 'France'].includes(m[1]);
    if ((m = p.q.match(/^Name an artwork by (.+)$/))) return ['Vincent van Gogh', 'Pablo Picasso', 'Leonardo da Vinci'].includes(m[1]);
    return true;
  }

  window.TUNGION_BANK = out.filter(normal);
})();
